@echo off
REM ============================================================
REM  PDF Summarizer - Piper TTS Server launcher
REM ============================================================
REM
REM  Double-click to start Piper. Close the window to stop.
REM
REM  If the window closes instantly, run this from a Command
REM  Prompt instead so you can see the error:
REM    cmd /k "C:\path\to\start-piper.bat"
REM
REM ============================================================

setlocal

REM --- EDIT THIS LINE to match your voices folder ---
set "VOICES_DIR=C:\Users\PC\piper\voices"

REM --- Port Piper listens on (must match extension popup) ---
set "PIPER_PORT=5000"

REM --- Path to piper_server.py (in this same folder as the .bat) ---
set "SCRIPT_DIR=%~dp0"
set "PIPER_SERVER=%SCRIPT_DIR%piper_server.py"

echo.
echo ====================================================
echo   PDF Summarizer - Piper TTS Server
echo ====================================================
echo   Voices folder: %VOICES_DIR%
echo   Port:          %PIPER_PORT%
echo   Server script: %PIPER_SERVER%
echo.
echo   Press Ctrl+C or close this window to stop.
echo ====================================================
echo.

REM Check voices folder
if not exist "%VOICES_DIR%" (
    echo [ERROR] Voices folder not found:
    echo   %VOICES_DIR%
    echo.
    echo Edit this .bat file and set VOICES_DIR to the folder
    echo that contains your downloaded .onnx voice files.
    echo.
    echo See piper-setup.md for download links.
    echo.
    pause
    goto :eof
)

REM Check piper_server.py exists next to this script
if not exist "%PIPER_SERVER%" (
    echo [ERROR] piper_server.py not found at:
    echo   %PIPER_SERVER%
    echo.
    echo This file should be in the same folder as start-piper.bat
    echo inside the pdf-summarizer-extension folder.
    echo.
    pause
    goto :eof
)

REM Try python from PATH first; if that fails, try the py launcher
echo Looking for Python...
where python >nul 2>nul
if %ERRORLEVEL%==0 (
    echo Found: python
    echo.
    echo Starting Piper server...
    echo.
    python "%PIPER_SERVER%" --voices-dir "%VOICES_DIR%" --port %PIPER_PORT%
    goto :done
)

where py >nul 2>nul
if %ERRORLEVEL%==0 (
    echo Found: py launcher
    echo.
    echo Starting Piper server...
    echo.
    py "%PIPER_SERVER%" --voices-dir "%VOICES_DIR%" --port %PIPER_PORT%
    goto :done
)

echo [ERROR] Python is not installed or not in PATH.
echo.
echo Tried both 'python' and 'py' commands - neither worked.
echo.
echo Install Python 3.9+ from: https://www.python.org/downloads/
echo During install, CHECK the box "Add Python to PATH".
echo Then reopen this script.
echo.
pause
goto :eof

:done
echo.
echo ====================================================
echo Piper server has stopped.
echo ====================================================
echo.
pause
endlocal
