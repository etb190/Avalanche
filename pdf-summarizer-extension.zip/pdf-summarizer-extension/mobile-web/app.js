// PDF Summarizer Mobile Remote & Reader Client
(() => {
  // State
  const DEFAULT_HOST = '10.206.178.25:38126';
  const CANDIDATE_HOSTS = [
    '10.206.178.25:38126',
    '127.0.0.1:38126',
    'localhost:38126',
    '10.0.2.2:38126'
  ];

  let serverHost = localStorage.getItem('pdf_summarizer_server_host');
  if (!serverHost || serverHost.startsWith('file:') || serverHost === 'null' || serverHost === 'undefined' || serverHost.includes('192.168.1.5')) {
    serverHost = (window.location.host && !window.location.host.startsWith('file')) ? window.location.host : DEFAULT_HOST;
    localStorage.setItem('pdf_summarizer_server_host', serverHost);
  }

  let eventSource = null;
  let currentState = {};
  let wakeLock = null;
  let readerFontSize = parseInt(localStorage.getItem('pdf_reader_font_size') || '15', 10);

  // DOM Elements
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const bookTitleEl = document.getElementById('bookTitle');
  const genreTagEl = document.getElementById('genreTag');
  const currentPageEl = document.getElementById('currentPage');
  const totalPagesEl = document.getElementById('totalPages');
  const progressFill = document.getElementById('progressFill');
  const percentLabel = document.getElementById('percentLabel');
  const pagesLeftLabel = document.getElementById('pagesLeftLabel');
  const btnPrev = document.getElementById('btnPrev');
  const btnNext = document.getElementById('btnNext');
  const btnStart = document.getElementById('btnStart');
  const btnReset = document.getElementById('btnReset');
  const btnBookmark = document.getElementById('btnBookmark');
  const btnRecap = document.getElementById('btnRecap');
  const bookmarkBanner = document.getElementById('bookmarkBanner');
  const bookmarkBannerText = document.getElementById('bookmarkBannerText');
  const btnJumpBookmark = document.getElementById('btnJumpBookmark');
  const btnClearBookmark = document.getElementById('btnClearBookmark');
  const recapBanner = document.getElementById('recapBanner');
  const recapBannerTitle = document.getElementById('recapBannerTitle');
  const recapBannerBody = document.getElementById('recapBannerBody');
  const btnCloseRecapBanner = document.getElementById('btnCloseRecapBanner');
  const selectGenre = document.getElementById('selectGenre');
  const selectLanguage = document.getElementById('selectLanguage');
  const selectLength = document.getElementById('selectLength');
  const checkOriginal = document.getElementById('checkOriginal');
  const checkRecap = document.getElementById('checkRecap');
  const summaryContent = document.getElementById('summaryContent');
  const readingContainer = document.getElementById('readingContainer');
  const footerStats = document.getElementById('footerStats');
  const contextChips = document.getElementById('contextChips');

  // Settings & Modal Elements
  const btnSettings = document.getElementById('btnSettings');
  const settingsModal = document.getElementById('settingsModal');
  const inputServerIp = document.getElementById('inputServerIp');
  const btnCloseModal = document.getElementById('btnCloseModal');
  const btnSaveIp = document.getElementById('btnSaveIp');

  // Jump Modal Elements
  const pageJumpTrigger = document.getElementById('pageJumpTrigger');
  const jumpModal = document.getElementById('jumpModal');
  const inputJumpPage = document.getElementById('inputJumpPage');
  const btnCloseJump = document.getElementById('btnCloseJump');
  const btnConfirmJump = document.getElementById('btnConfirmJump');

  // Recap Modal Elements
  const recapModal = document.getElementById('recapModal');
  const recapModalTitle = document.getElementById('recapModalTitle');
  const recapModalBody = document.getElementById('recapModalBody');
  const btnCloseRecapModal = document.getElementById('btnCloseRecapModal');
  const btnPrevRecap = document.getElementById('btnPrevRecap');
  const btnNextRecap = document.getElementById('btnNextRecap');
  const btnDoneRecap = document.getElementById('btnDoneRecap');

  // Additional Toggles
  const btnWakeLock = document.getElementById('btnWakeLock');
  const btnNightMode = document.getElementById('btnNightMode');
  const btnFontDec = document.getElementById('btnFontDec');
  const btnFontInc = document.getElementById('btnFontInc');
  const btnSyncNow = document.getElementById('btnSyncNow');
  const toggleMoreSettings = document.getElementById('toggleMoreSettings');
  const moreSettingsContent = document.getElementById('moreSettingsContent');
  const settingsArrow = document.getElementById('settingsArrow');

  // ===== BOOKMARK & POSITION HELPERS =====
  function getBookmarkKey(title) {
    return 'pdf_remote_bookmark_' + encodeURIComponent((title || 'default').trim());
  }

  function getPositionKey(title) {
    return 'pdf_remote_pos_' + encodeURIComponent((title || 'default').trim());
  }

  function getSavedBookmark(title) {
    try {
      const raw = localStorage.getItem(getBookmarkKey(title));
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function saveBookmark(title, page) {
    try {
      const bm = { page: Number(page), title, time: Date.now() };
      localStorage.setItem(getBookmarkKey(title), JSON.stringify(bm));
      return bm;
    } catch (e) {
      return null;
    }
  }

  function clearBookmark(title) {
    try {
      localStorage.removeItem(getBookmarkKey(title));
    } catch (e) {}
  }

  function getSavedPosition(title) {
    try {
      const raw = localStorage.getItem(getPositionKey(title));
      return raw ? parseInt(raw, 10) : null;
    } catch (e) {
      return null;
    }
  }

  function saveReadingPosition(title, page) {
    if (!title || !page) return;
    try {
      localStorage.setItem(getPositionKey(title), String(page));
    } catch (e) {}
  }

  function updateBookmarkUI(title, curPage) {
    const bm = getSavedBookmark(title);
    if (bm && bm.page) {
      btnBookmark.classList.add('active');
      if (curPage === bm.page) {
        btnBookmark.textContent = 'Bookmarked';
      } else {
        btnBookmark.textContent = `Bookmark (p. ${bm.page})`;
      }
      bookmarkBannerText.textContent = `Bookmarked: Page ${bm.page}`;
      bookmarkBanner.style.display = 'flex';
    } else {
      btnBookmark.classList.remove('active');
      btnBookmark.textContent = 'Bookmark';
      bookmarkBanner.style.display = 'none';
    }
  }

  // ===== RECAP HELPERS =====
  const pageSummaries = {};
  const pageRecaps = {};
  let recapMode = localStorage.getItem('pdf_recap_mode') === 'true';
  let currentRecapPage = 1;

  function showRecapModal(pageNum) {
    currentRecapPage = pageNum || currentState.currentPage || 1;
    recapModalTitle.textContent = `Recap — Page ${currentRecapPage}`;
    recapModalBody.setAttribute('lang', (currentState.language === 'Arabic') ? 'ar' : 'en');

    const recap = pageRecaps[currentRecapPage];
    if (recap && recap.trim()) {
      recapModalBody.innerHTML = renderMarkdown(recap);
    } else {
      recapModalBody.innerHTML = `
        <div style="text-align: center; padding: 24px 12px; color: var(--text-muted);">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="spin-icon" style="margin-bottom: 8px;"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>
          <p style="font-size: 13px;">Condensing summary…</p>
        </div>
      `;
      sendCommand('requestRecap', { page: currentRecapPage });
    }
    recapModal.classList.add('open');
  }

  function getBaseUrl() {
    let host = serverHost.trim();
    if (!host.startsWith('http://') && !host.startsWith('https://')) {
      host = 'http://' + host;
    }
    return host.replace(/\/+$/, '');
  }

  let isProbing = false;
  async function probeCandidates() {
    if (isProbing) return;
    isProbing = true;
    for (const cand of CANDIDATE_HOSTS) {
      if (cand === serverHost) continue;
      try {
        const testUrl = (cand.startsWith('http') ? cand : `http://${cand}`) + '/api/state';
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 1200);
        const res = await fetch(testUrl, { signal: controller.signal, cache: 'no-store' });
        clearTimeout(tid);
        if (res.ok) {
          const data = await res.json();
          if (data && typeof data === 'object') {
            console.log('[Remote] Auto-discovered reachable server:', cand);
            serverHost = cand;
            localStorage.setItem('pdf_summarizer_server_host', cand);
            isProbing = false;
            connectToServer();
            return;
          }
        }
      } catch (e) {}
    }
    isProbing = false;
  }

  // ===== CONNECTION & SSE =====
  function connectToServer() {
    if (eventSource) {
      eventSource.close();
      eventSource = null;
    }

    const baseUrl = getBaseUrl();
    updateStatus(false, 'Connecting...');

    // First fetch initial state
    fetch(`${baseUrl}/api/state`, { cache: 'no-store' })
      .then(r => r.json())
      .then(data => {
        applyState(data);
        updateStatus(true, 'Connected to PC');
      })
      .catch(() => {
        updateStatus(false, 'Waiting for PC...');
        probeCandidates();
      });

    try {
      eventSource = new EventSource(`${baseUrl}/api/events`);
      eventSource.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          applyState(data);
          updateStatus(true, 'Connected to PC');
        } catch (err) {}
      };
      eventSource.onerror = () => {
        updateStatus(false, 'Reconnecting...');
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }
        probeCandidates();
        setTimeout(connectToServer, 3500);
      };
    } catch (e) {
      updateStatus(false, 'Connection error');
      probeCandidates();
    }
  }

  function updateStatus(connected, text) {
    if (connected) {
      statusDot.className = 'pulse-dot connected';
      statusText.textContent = text || 'Connected to PC';
    } else {
      statusDot.className = 'pulse-dot disconnected';
      statusText.textContent = `${text || 'Disconnected'} (${serverHost})`;
    }
  }

  function sendCommand(action, params = {}) {
    const baseUrl = getBaseUrl();
    fetch(`${baseUrl}/api/command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...params })
    }).catch(err => {
      console.error('Failed to send command:', err);
    });
  }

  // ===== APPLY STATE =====
  let lastPage = null;

  function applyState(data) {
    if (!data) return;
    const isNewPage = data.currentPage !== lastPage;
    currentState = data;

    // Header & Meta
    bookTitleEl.textContent = data.bookTitle || 'Untitled Book';
    bookTitleEl.title = data.pdfName || '';
    genreTagEl.textContent = formatGenreLabel(data.genre);

    // Navigation
    currentPageEl.textContent = data.currentPage || 1;
    totalPagesEl.textContent = data.totalPages ? data.totalPages : '—';
    btnPrev.disabled = (data.currentPage || 1) <= 1;
    btnNext.disabled = data.totalPages ? data.currentPage >= data.totalPages : false;

    // Progress
    const total = data.totalPages || 1;
    const cur = data.currentPage || 1;
    const pct = Math.min(100, Math.round((cur / total) * 100));
    progressFill.style.width = `${pct}%`;
    percentLabel.textContent = `${pct}%`;
    const left = Math.max(0, total - cur);
    pagesLeftLabel.textContent = `${left} page${left === 1 ? '' : 's'} left`;

    // Save current reading position for Continue
    if (data.bookTitle && data.currentPage) {
      saveReadingPosition(data.bookTitle, data.currentPage);
    }

    // Action Buttons (Start / Continue / Pause) - pure text only
    const savedPos = data.bookTitle ? getSavedPosition(data.bookTitle) : null;
    if (data.started) {
      btnStart.textContent = 'Pause';
      btnStart.classList.add('running');
    } else if (savedPos && savedPos > 1 && savedPos !== data.currentPage) {
      btnStart.textContent = `Continue (p. ${savedPos})`;
      btnStart.classList.remove('running');
    } else if (savedPos && savedPos > 1) {
      btnStart.textContent = 'Continue';
      btnStart.classList.remove('running');
    } else {
      btnStart.textContent = 'Start';
      btnStart.classList.remove('running');
    }

    // Bookmark Banner and Button handling
    updateBookmarkUI(data.bookTitle, data.currentPage);

    // Record recaps & summaries from PC
    if (data.recaps && typeof data.recaps === 'object') {
      Object.assign(pageRecaps, data.recaps);
    }
    if (data.currentRecap) {
      pageRecaps[data.currentPage] = data.currentRecap;
    }
    if (data.prevRecap && data.currentPage > 1) {
      pageRecaps[data.currentPage - 1] = data.prevRecap;
    }
    if (data.currentPage && data.summary && data.summary.trim()) {
      pageSummaries[data.currentPage] = data.summary;
    }

    // Live update open recap modal if current page recap just arrived
    if (recapModal && recapModal.classList.contains('open') && pageRecaps[currentRecapPage]) {
      recapModalBody.innerHTML = renderMarkdown(pageRecaps[currentRecapPage]);
    }

    // Live update recap banner if visible
    if (recapBanner && recapBanner.style.display !== 'none' && lastPage && pageRecaps[lastPage]) {
      recapBannerBody.innerHTML = renderMarkdown(pageRecaps[lastPage]);
    }

    // Sync Recap Mode
    if (data.recapMode !== undefined) {
      recapMode = !!data.recapMode;
      if (checkRecap) checkRecap.checked = recapMode;
    }

    // Settings Dropdowns & Context Chips
    if (data.genre) selectGenre.value = data.genre;
    if (data.language) selectLanguage.value = data.language;
    if (data.summaryLength) selectLength.value = String(data.summaryLength);
    if (data.originalMode !== undefined) checkOriginal.checked = !!data.originalMode;

    // Highlight active context chip
    const curContext = data.contextCount || 1;
    const chips = contextChips.querySelectorAll('.chip');
    chips.forEach(ch => {
      if (parseInt(ch.dataset.context, 10) === curContext) {
        ch.classList.add('active');
      } else {
        ch.classList.remove('active');
      }
    });

    // Summary Content Display
    if (data.summary && data.summary.trim()) {
      summaryContent.innerHTML = renderMarkdown(data.summary);
      if (data.language === 'Arabic') {
        summaryContent.style.direction = 'rtl';
        summaryContent.setAttribute('lang', 'ar');
      } else {
        summaryContent.style.direction = 'ltr';
        summaryContent.setAttribute('lang', 'en');
      }
      summaryContent.style.textAlign = 'justify';

      // Update word & char stats
      const words = data.summary.trim().split(/\s+/).filter(Boolean).length;
      const chars = data.summary.length;
      footerStats.textContent = `${words} words / ${chars} chars`;
    } else if (data.started) {
      summaryContent.innerHTML = `
        <div class="idle-state">
          <div class="idle-icon">
            <svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="spin-icon"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>
          </div>
          <h2>Summarizing...</h2>
          <p>Page ${cur} is being generated by Ollama on your PC.</p>
        </div>
      `;
      footerStats.textContent = 'Generating...';
    } else {
      summaryContent.innerHTML = `
        <div class="idle-state">
          <div class="idle-icon">
            <svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
          </div>
          <h2>Ready to Read</h2>
          <p>Tap <strong>Start</strong> or flip pages to generate summaries.</p>
        </div>
      `;
      footerStats.textContent = 'Idle';
    }

    // Reset scroll to top on page flip & show Recap banner if enabled
    if (isNewPage) {
      readingContainer.scrollTo({ top: 0, behavior: 'smooth' });
      if (recapMode && lastPage) {
        const recap = pageRecaps[lastPage] || (lastPage === data.currentPage - 1 ? data.prevRecap : null);
        recapBannerTitle.textContent = `Recap — Page ${lastPage}`;
        recapBannerBody.setAttribute('lang', (data.language === 'Arabic') ? 'ar' : 'en');
        if (recap && recap.trim()) {
          recapBannerBody.innerHTML = renderMarkdown(recap);
        } else {
          recapBannerBody.innerHTML = '<span style="color:var(--text-muted);font-style:italic;">Condensing summary…</span>';
          sendCommand('requestRecap', { page: lastPage });
        }
        recapBanner.style.display = 'flex';
      }
      lastPage = data.currentPage;
    }
  }

  function formatGenreLabel(genre) {
    if (!genre) return 'CLASSIC';
    return genre.replace(/_/g, ' ').toUpperCase();
  }

  function formatTime(secs) {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  }

  function sanitizeTypography(s) {
    if (!s) return '';
    return s
      .replace(/[\u00A0\u1680\u2000-\u200B\u202F\u205F\u3000\uFEFF]/g, ' ')
      .replace(/[\u2010\u2011\u2012]/g, '-')
      .replace(/[ \t\f\v]+/g, ' ');
  }

  function escapeHtml(s) {
    if (!s) return '';
    return s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function inlineFormat(s) {
    if (!s) return '';
    return s
      .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*([^*\n]+?)\*/g, '<em>$1</em>')
      .replace(/`([^`\n]+?)`/g, '<code>$1</code>');
  }

  // ===== RICH MARKDOWN RENDERER (Clean separate header lines) =====
  function renderMarkdown(md) {
    if (!md) return '';
    md = sanitizeTypography(md);

    const lines = escapeHtml(md).split(/\r?\n/);
    const out = [];
    let pendingParagraph = [];
    let inList = false;

    const flushParagraph = () => {
      if (pendingParagraph.length > 0) {
        out.push(`<p>${inlineFormat(pendingParagraph.join(' '))}</p>`);
        pendingParagraph = [];
      }
    };

    const closeList = () => {
      if (inList) {
        out.push('</ul>');
        inList = false;
      }
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();

      // Blank line -> flush paragraph
      if (!trimmed) {
        flushParagraph();
        closeList();
        continue;
      }

      // Markdown Headers: # through ######
      if (/^#{1,6}\s+/.test(trimmed)) {
        flushParagraph();
        closeList();
        const headerText = trimmed.replace(/^#+\s+/, '');
        out.push(`<h3 class="reader-heading">${inlineFormat(headerText)}</h3>`);
        continue;
      }

      // Lead bold headers at start of line:
      // e.g. **1. Header Name:** Text... or **Header Name**: Text... or **Header Name**
      const boldLeadMatch = trimmed.match(/^(\*{2}|_{2})(.*?)\1(?::|\s*[-–—]\s*)?\s*(.*)$/);
      if (boldLeadMatch && boldLeadMatch[2].length <= 85 && (!boldLeadMatch[2].includes('.') || boldLeadMatch[2].length <= 50)) {
        const titleText = boldLeadMatch[2].trim();
        const remainingText = boldLeadMatch[3] ? boldLeadMatch[3].trim() : '';

        flushParagraph();
        closeList();
        out.push(`<h4 class="reader-section-header">${inlineFormat(titleText)}</h4>`);

        if (remainingText) {
          pendingParagraph.push(remainingText);
        }
        continue;
      }

      // Bullet lists
      if (/^\s*[-*•]\s+/.test(line)) {
        flushParagraph();
        if (!inList) {
          out.push('<ul>');
          inList = true;
        }
        const bulletText = line.replace(/^\s*[-*•]\s+/, '');
        out.push(`<li>${inlineFormat(bulletText)}</li>`);
        continue;
      }

      // Blockquotes
      if (trimmed.startsWith('&gt;') || trimmed.startsWith('>')) {
        flushParagraph();
        closeList();
        const quoteText = trimmed.replace(/^(&gt;|>)\s*/, '');
        out.push(`<blockquote>${inlineFormat(quoteText)}</blockquote>`);
        continue;
      }

      // Regular line: accumulates into current paragraph
      closeList();
      pendingParagraph.push(trimmed);
    }

    flushParagraph();
    closeList();

    return out.join('');
  }

  // ===== EVENT LISTENERS =====
  btnPrev.addEventListener('click', () => sendCommand('prevPage'));
  btnNext.addEventListener('click', () => sendCommand('nextPage'));
  
  btnStart.addEventListener('click', () => {
    if (!currentState.started) {
      const savedPos = currentState.bookTitle ? getSavedPosition(currentState.bookTitle) : null;
      if (savedPos && savedPos > 1 && savedPos !== currentState.currentPage) {
        sendCommand('goToPage', { page: savedPos });
      }
    }
    sendCommand('start');
  });

  btnReset.addEventListener('click', () => {
    if (confirm('Clear and reset summaries on PC?')) {
      sendCommand('reset');
    }
  });

  btnBookmark.addEventListener('click', () => {
    const title = currentState.bookTitle;
    const curPage = currentState.currentPage || 1;
    const bm = getSavedBookmark(title);

    if (bm && bm.page) {
      if (curPage !== bm.page) {
        // Jump to bookmark
        sendCommand('goToPage', { page: bm.page });
      } else {
        // Already on bookmarked page -> clear bookmark
        clearBookmark(title);
        updateBookmarkUI(title, curPage);
      }
    } else {
      // Save new bookmark
      saveBookmark(title, curPage);
      updateBookmarkUI(title, curPage);
    }
  });

  btnJumpBookmark.addEventListener('click', () => {
    const bm = getSavedBookmark(currentState.bookTitle);
    if (bm && bm.page) {
      sendCommand('goToPage', { page: bm.page });
    }
  });

  btnClearBookmark.addEventListener('click', () => {
    clearBookmark(currentState.bookTitle);
    updateBookmarkUI(currentState.bookTitle, currentState.currentPage);
  });

  // ===== RECAP EVENT LISTENERS =====
  btnRecap.addEventListener('click', () => {
    const target = currentState.currentPage || 1;
    showRecapModal(target);
  });

  if (checkRecap) {
    checkRecap.checked = recapMode;
    checkRecap.addEventListener('change', () => {
      recapMode = checkRecap.checked;
      localStorage.setItem('pdf_recap_mode', String(recapMode));
      sendCommand('setRecapMode', { enabled: recapMode });
    });
  }

  if (btnCloseRecapBanner) {
    btnCloseRecapBanner.addEventListener('click', () => {
      recapBanner.style.display = 'none';
    });
  }

  if (btnCloseRecapModal) {
    btnCloseRecapModal.addEventListener('click', () => {
      recapModal.classList.remove('open');
    });
  }

  if (btnDoneRecap) {
    btnDoneRecap.addEventListener('click', () => {
      recapModal.classList.remove('open');
    });
  }

  if (btnPrevRecap) {
    btnPrevRecap.addEventListener('click', () => {
      if (currentRecapPage > 1) {
        showRecapModal(currentRecapPage - 1);
      }
    });
  }

  if (btnNextRecap) {
    btnNextRecap.addEventListener('click', () => {
      if (currentRecapPage < (currentState.totalPages || 9999)) {
        showRecapModal(currentRecapPage + 1);
      }
    });
  }

  selectGenre.addEventListener('change', () => {
    sendCommand('setGenre', { genre: selectGenre.value });
  });

  selectLanguage.addEventListener('change', () => {
    sendCommand('setLanguage', { language: selectLanguage.value });
  });

  selectLength.addEventListener('change', () => {
    sendCommand('setSummaryLength', { length: selectLength.value });
  });

  checkOriginal.addEventListener('change', () => {
    sendCommand('toggleOriginal');
  });

  // Context Chips
  contextChips.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    const count = parseInt(chip.dataset.context, 10);
    sendCommand('setContext', { context: count });
  });

  // Accordion toggle
  toggleMoreSettings.addEventListener('click', () => {
    const isOpen = moreSettingsContent.classList.toggle('open');
    settingsArrow.classList.toggle('open', isOpen);
  });

  // Page Jump Trigger
  pageJumpTrigger.addEventListener('click', () => {
    inputJumpPage.value = currentState.currentPage || 1;
    inputJumpPage.max = currentState.totalPages || 9999;
    jumpModal.classList.add('open');
    inputJumpPage.focus();
  });

  btnCloseJump.addEventListener('click', () => jumpModal.classList.remove('open'));
  btnConfirmJump.addEventListener('click', () => {
    const p = parseInt(inputJumpPage.value, 10);
    if (p && p >= 1) {
      sendCommand('goToPage', { page: p });
    }
    jumpModal.classList.remove('open');
  });

  // IP Settings Modal
  statusIndicator.addEventListener('click', () => {
    btnSettings.click();
  });

  btnSettings.addEventListener('click', () => {
    inputServerIp.value = serverHost;
    settingsModal.classList.add('open');
    inputServerIp.focus();
  });

  btnCloseModal.addEventListener('click', () => settingsModal.classList.remove('open'));
  btnSaveIp.addEventListener('click', () => {
    const newIp = inputServerIp.value.trim();
    if (newIp) {
      serverHost = newIp;
      localStorage.setItem('pdf_summarizer_server_host', newIp);
      settingsModal.classList.remove('open');
      connectToServer();
    }
  });

  // Wake Lock API (Keep Phone Screen On While Reading)
  btnWakeLock.addEventListener('click', async () => {
    if ('wakeLock' in navigator) {
      if (wakeLock) {
        wakeLock.release().then(() => {
          wakeLock = null;
          btnWakeLock.classList.remove('active');
          btnWakeLock.title = 'Keep Screen Awake (OFF)';
        });
      } else {
        try {
          wakeLock = await navigator.wakeLock.request('screen');
          btnWakeLock.classList.add('active');
          btnWakeLock.title = 'Screen Kept Awake (ON)';
          wakeLock.addEventListener('release', () => {
            btnWakeLock.classList.remove('active');
            wakeLock = null;
          });
        } catch (e) {}
      }
    } else {
      alert('Screen Wake Lock not supported by this browser.');
    }
  });

  // Font Size Buttons
  function applyFontSize() {
    document.documentElement.style.setProperty('--reader-font-size', `${readerFontSize}px`);
    localStorage.setItem('pdf_reader_font_size', String(readerFontSize));
  }

  btnFontDec.addEventListener('click', () => {
    if (readerFontSize > 11) {
      readerFontSize -= 1;
      applyFontSize();
    }
  });

  btnFontInc.addEventListener('click', () => {
    if (readerFontSize < 28) {
      readerFontSize += 1;
      applyFontSize();
    }
  });
  applyFontSize();

  // Night Mode Toggle (Sync with PC)
  btnNightMode.addEventListener('click', () => {
    sendCommand('toggleNightMode');
  });

  // Sync Now button
  btnSyncNow.addEventListener('click', () => {
    connectToServer();
  });

  // Start connection
  connectToServer();
})();
