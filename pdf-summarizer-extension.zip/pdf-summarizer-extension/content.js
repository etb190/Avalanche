// PDF Summarizer — Content Script
// Injects a floating panel onto Chrome's built-in PDF viewer.
// Detects pages, sends text to Ollama for summarization, speaks via Web Speech API.

(function () {
  'use strict';

  // ===== EARLY EXIT: Only activate on PDF pages =====
  const isPDF =
    document.contentType === 'application/pdf' ||
    location.pathname.toLowerCase().endsWith('.pdf');

  if (!isPDF) return;

  // ===== STATE =====
  let totalPages = 0;
  let currentPage = 1;
  let summaries = {};
  let summarizing = new Set();
  let prefetchQueue = [];       // ordered list of page numbers to summarize next
  let activePrefetches = 0;     // how many concurrent summarize calls are in-flight
  const MAX_CONCURRENT = 1;     // serialize Ollama calls (cloud models only allow 1 slot)
  const PREFETCH_AHEAD = 1;     // buffer strictly 1 page set ahead (after current finishes)
  let currentFontSize = 13;
  let ollamaUrl = 'http://localhost:11434';
  let ollamaModel = 'nemotron-3-ultra:cloud';
  let pdfUrl = location.href;

  // Canonicalize a PDF URL to ensure a single unique identifier per document.
  // Strips hash anchors (#page=...), query parameters (?zoom=...), decodes URI components,
  // and normalizes file:// paths so that case differences, query params, or hashes never produce
  // multiple duplicate keys or overlapping saved positions for the same PDF.
  function canonicalizePdfUrl(rawUrl) {
    if (!rawUrl) return '';
    try {
      let clean = String(rawUrl).split('#')[0].split('?')[0].replace(/\/+$/, '');
      try {
        clean = decodeURIComponent(clean);
      } catch (e) {}
      if (clean.toLowerCase().startsWith('file:')) {
        clean = clean.toLowerCase();
      }
      return clean.trim();
    } catch (e) {
      return String(rawUrl || '').split('#')[0].split('?')[0].trim();
    }
  }

  // ===== MIDDLE HOVERING BAR (Ctrl + Q TOGGLE) =====
  let panelVisible = true;

  function toggleMiddlePanel() {
    const host = (shadow && shadow.host) || document.getElementById('pdf-summarizer-host');
    if (!host) return;
    const isHidden = host.style.display === 'none' || (panel && panel.style.display === 'none');
    if (isHidden) {
      panelVisible = true;
      host.style.display = '';
      if (panel) panel.style.display = '';
    } else {
      panelVisible = false;
      host.style.display = 'none';
      if (panel) panel.style.display = 'none';
      if (typeof dismissRecapPopup === 'function') dismissRecapPopup();
    }
  }

  // Global capture listener: Ctrl + Q makes middle hovering bar disappear / reappear
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key && e.key.toLowerCase() === 'q') {
      e.preventDefault();
      e.stopImmediatePropagation();
      toggleMiddlePanel();
    }
  }, true);

  let pdfReady = false;
  let started = false;
  let panelCollapsed = false;
  let panelOpacity = 1.0;
  let nightMode = true;
  let contextCount = 1; // 1, 2, 3, 4, 5, 6, or 10
  let summaryLength = 1000; // max words for summary (user-controlled via dropdown)
  let bookGenre = 'nonfiction_classic'; // 'nonfiction_classic', 'law_books', 'law_statutes', 'research_papers', 'fiction', 'philosophical_fiction'
  let language = 'English';

  // TTS state
  let ttsEnabled = true;            // MASTER TOGGLE: when false, no TTS API calls (saves credits)
  let originalMode = false;         // when true, main panel shows raw book text instead of AI summaries
  let recapMode = false;            // when true, a recap popup appears on navigation showing a condensed summary of the previous pages
  let recapFontSize = 13;           // font size for the recap popup body (persisted)
  let recapPopupBounds = null;      // {left, top, width, height} — persisted popup position/size
  let ttsAutoAdvance = true;        // when true, audio auto-advances to next page when it ends
  let ttsPlaying = false;
  let ttsPaused = false;            // true when audio is paused with a saved position
  let ttsLoading = false;
  let ttsAudioBuffer = null;        // Blob URL string for the current page's audio
  let currentPageForAudio = null;   // which page the currently-loaded audio belongs to
  let currentPageForScroll = null;  // which page we last reset scroll for (used to reset scroll when summary arrives for a new page)
  let ttsAudioElement = null;       // HTMLAudioElement used for pitch-preserving playback
  let ttsSpeed = 1.0;
  let ttsAudioDuration = 0;
  let ttsProgressInterval = null;
  let pageResumePositions = {};     // pageNum -> playback position (seconds) saved on pause/navigation
  let autoAdvanceTarget = null;     // pageNum that should auto-start playing (set by handleAudioFinished or goToPage)
  let ttsIntentActive = false;      // true when user wants TTS playing (set by play, cleared by pause/disable). Drives auto-start on manual navigation.

  // Chat state
  let chatHistory = [];   // { role: 'user'|'assistant', content: string }[]
  let chatWaiting = false;
  // Chat context selector state
  let chatContextMode = 'current'; // 'current' | 'next5' | 'next10' | 'area5' | 'area10' | 'area20' | 'range' | 'custom'
  let getChatContextPages = () => []; // populated by createChatPanel
  let chatVisible = true; // Open by default
  
  // Quiz state
  let generatedQuizzes = {}; // chunkIndex -> { status: 'locked'|'generating'|'ready'|'grading'|'graded', questions: '', grading: '' }
  let activeQuizChunk = null;
  let customQuizKeys = []; // tracks keys like 'c_55_80' for custom range quizzes

  // Word highlight mode state
  // ALWAYS-ON: word highlight mode is the default. Users can click any word
  // to look up its definition, search, or fact-check it. No more Shift toggle.
  let wordHighlightActive = true;
  let activeWordPopup = null; // reference to current popup element
  let popupAudioEl = null;    // shared HTMLAudioElement for the popup "Aloud" button (one at a time)

  // Shadow DOM refs — summarizer
  let shadow, panel, summaryTextEl, pageInput, pageTotalEl;
  let statusDot, statusLabel, modelLabel, startBtn;
  let progressFill, percentLabel, pagesLeftLabel;

  // Bookmark state (one bookmark per PDF, saved to chrome.storage.local)
  let currentBookmark = null; // { url, startPage, endPage, pageRangeText, summary, recap, word, wordOccurrence, wordSpanIndex, savedAt }
  let isSelectingBookmarkWord = false;
  let bookmarkBannerTimeout = null;
  let bookmarkBtnEl = null;
  let bookmarkBannerEl = null;

  // Reading position state (persisted per PDF for up to 10 days)
  let positionEnabled = true;
  let savedPdfPosition = null; // { page: number, lastOpenedAt: number }
  let savePositionTimer = null;
  const TEN_DAYS_MS = 10 * 24 * 60 * 60 * 1000;

  // Shadow DOM refs — chat
  let chatShadow, chatPanel, chatMessagesEl, chatInputEl, chatSendBtn, chatToggleBtn;

  // Shadow DOM refs — left bar
  let lbShadow, lbPanel, lbListEl, lbFromInput, lbToInput, lbConceptInput, lbToggleBtn;
  let lbQuestionInput, lbRelevanceBtn, lbRelevanceProgressEl, lbRelevanceResultEl;
  let lbVisible = true; // Open by default
  let lbWaiting = false;
  let lbRelevanceWaiting = false; // separate flag so relevance checks don't block range/concept

  // ===== DISCORD RICH PRESENCE (via Axo bridge) =====
  const AXO_BRIDGE_URL = 'http://127.0.0.1:38120';
  let discordThrottleTimer = null;
  let discordHeartbeatInterval = null;
  let discordRpcEnabled = true;

  function getDiscordPdfDetails() {
    let rawName = '';
    try {
      const cleanUrl = canonicalizePdfUrl(location.href || pdfUrl || '');
      const parts = cleanUrl.split('/');
      rawName = decodeURIComponent(parts[parts.length - 1] || '');
    } catch (e) {
      rawName = '';
    }
    if (!rawName || !rawName.toLowerCase().endsWith('.pdf')) {
      if (document.title && document.title.toLowerCase().endsWith('.pdf')) {
        rawName = document.title;
      } else {
        rawName = 'Document.pdf';
      }
    }

    // Clean book title — remove .pdf and normalize
    let bookTitle = rawName.replace(/\.pdf$/i, '').trim();
    bookTitle = bookTitle.replace(/[-_]+/g, ' ').trim();
    if (bookTitle === bookTitle.toLowerCase()) {
      bookTitle = bookTitle.replace(/(?<!['’])\b[a-z]/g, (c) => c.toUpperCase());
    }

    if (
      document.title &&
      document.title.trim() &&
      !document.title.toLowerCase().endsWith('.pdf') &&
      document.title !== location.href
    ) {
      bookTitle = document.title.trim().replace(/\.pdf$/i, '');
    }

    // Ensure contractions and possessive suffixes after apostrophes remain lowercase (e.g. "Israel'S" -> "Israel's")
    bookTitle = bookTitle.replace(/(['’])([A-Z]+)\b/g, (m, quote, letters) => quote + letters.toLowerCase());

    return {
      pdfName: rawName,
      bookTitle: bookTitle,
    };
  }

  function startDiscordHeartbeat() {
    stopDiscordHeartbeat();
    if (!discordRpcEnabled || !started) return;
    // Send a pulse every 10 seconds to keep Discord presence alive for the active reading session
    discordHeartbeatInterval = setInterval(() => {
      if (discordRpcEnabled && started && pdfReady) {
        sendDiscordPresence(false);
      } else {
        stopDiscordHeartbeat();
      }
    }, 10000);
  }

  function stopDiscordHeartbeat() {
    if (discordHeartbeatInterval) {
      clearInterval(discordHeartbeatInterval);
      discordHeartbeatInterval = null;
    }
  }

  let discordSessionStartTime = null;

  function syncDiscordSessionState(callback) {
    try {
      chrome.runtime.sendMessage({ type: 'DISCORD_READING_ACTIVE' }, (res) => {
        if (!chrome.runtime.lastError && res && res.sessionStartTime) {
          discordSessionStartTime = res.sessionStartTime;
        }
        if (typeof callback === 'function') callback(discordSessionStartTime);
      });
    } catch (e) {
      if (typeof callback === 'function') callback(discordSessionStartTime);
    }
  }

  function sendDiscordPresence(immediate = false, resetSession = false) {
    if (!discordRpcEnabled || !started) return;
    if (!pdfReady && !immediate) return;

    if (discordThrottleTimer) {
      clearTimeout(discordThrottleTimer);
    }

    discordThrottleTimer = setTimeout(() => {
      discordThrottleTimer = null;
      if (!discordRpcEnabled || !started) return;
      try {
        const { pdfName, bookTitle } = getDiscordPdfDetails();
        syncDiscordSessionState((startTime) => {
          fetch(`${AXO_BRIDGE_URL}/presence`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              bookTitle,
              pdfName,
              currentPage,
              totalPages: totalPages || 1,
              url: canonicalizePdfUrl(location.href || pdfUrl || ''),
              resetSession: !!resetSession,
              startTime: startTime || undefined,
            }),
          })
            .then((res) => res.json())
            .then((data) => {
              if (data && data.ignored) {
                // Another tab has taken over as the active Discord reading session
                stopDiscordHeartbeat();
              }
            })
            .catch(() => {
              // Axo may not be running; fail quietly
            });
        });
      } catch (err) {}
    }, immediate ? 50 : 600);
  }

  function clearDiscordPresence() {
    stopDiscordHeartbeat();
    try {
      const payload = JSON.stringify({ url: canonicalizePdfUrl(location.href || pdfUrl || '') });
      fetch(`${AXO_BRIDGE_URL}/clear`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: payload,
        keepalive: true,
      }).catch(() => {});
    } catch (err) {}
  }

  window.addEventListener('beforeunload', () => {
    flushSavedPosition();
    // Do NOT clear Discord presence on unload/pagehide:
    // Navigating to a new book in the browser preserves the elapsed reading time.
    // Rich presence is only reset to 0 when the tab is closed entirely (handled via chrome.tabs.onRemoved in background.js).
  });
  window.addEventListener('pagehide', () => {
    flushSavedPosition();
  });

  // Keepalive when tab becomes visible or focused again after being idle
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && started && discordRpcEnabled && pdfReady) {
      sendDiscordPresence(true, false);
      startDiscordHeartbeat();
    }
  });
  window.addEventListener('focus', () => {
    if (started && discordRpcEnabled && pdfReady) {
      sendDiscordPresence(true, false);
    }
  });

  // ===== ANDROID REMOTE BRIDGE =====
  const REMOTE_BRIDGE_URL = 'http://127.0.0.1:38126';
  let remoteSyncTimer = null;
  let remoteEventSource = null;

  function pushRemoteState(immediate = false) {
    if (remoteSyncTimer) clearTimeout(remoteSyncTimer);
    const delay = immediate ? 20 : 400;

    remoteSyncTimer = setTimeout(() => {
      remoteSyncTimer = null;
      if (!pdfReady) return;
      try {
        const { pdfName, bookTitle } = getDiscordPdfDetails();
        const currentSummary = sanitizeTypography(summaries[currentPage] || '');
        const currentRecap = sanitizeTypography(recapCache[currentPage] || '');
        const prevRecap = sanitizeTypography(recapCache[currentPage - 1] || '');
        const cleanRecaps = {};
        for (const [k, v] of Object.entries(recapCache)) {
          if (v) cleanRecaps[k] = sanitizeTypography(v);
        }
        const payload = {
          bookTitle,
          pdfName,
          currentPage,
          totalPages,
          summary: currentSummary,
          currentRecap,
          prevRecap,
          recaps: cleanRecaps,
          started,
          ttsPlaying: !!ttsPlaying,
          ttsAudioCurrentTime: Math.floor(ttsAudioElement ? ttsAudioElement.currentTime : (pageResumePositions[currentPage] || 0)),
          ttsAudioDuration: Math.floor(ttsAudioDuration || 0),
          ttsSpeed,
          ttsAutoAdvance: !!ttsAutoAdvance,
          ttsEnabled: !!ttsEnabled,
          originalMode: !!originalMode,
          recapMode: !!recapMode,
          nightMode: !!panel?.classList.contains('night-mode'),
          fontSize: currentFontSize,
          genre: bookGenre,
          language,
          contextCount,
          summaryLength
        };
        fetch(`${REMOTE_BRIDGE_URL}/api/state`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).catch(() => {});
      } catch (e) {}
    }, delay);
  }

  function startRemoteCommandListener() {
    if (remoteEventSource) {
      remoteEventSource.close();
      remoteEventSource = null;
    }
    try {
      remoteEventSource = new EventSource(`${REMOTE_BRIDGE_URL}/api/commands`);
      remoteEventSource.onmessage = (e) => {
        try {
          const cmd = JSON.parse(e.data);
          handleRemoteCommand(cmd);
        } catch (err) {}
      };
      remoteEventSource.onerror = () => {
        if (remoteEventSource) {
          remoteEventSource.close();
          remoteEventSource = null;
        }
        setTimeout(startRemoteCommandListener, 6000);
      };
    } catch (e) {}
  }

  function handleRemoteCommand(cmd) {
    if (!cmd || !cmd.action) return;
    switch (cmd.action) {
      case 'nextPage':
        goToPage(Math.min(currentPage + (contextCount || 1), totalPages));
        break;
      case 'prevPage':
        goToPage(Math.max(currentPage - (contextCount || 1), 1));
        break;
      case 'goToPage':
        if (cmd.page && Number(cmd.page) >= 1 && Number(cmd.page) <= totalPages) {
          goToPage(Number(cmd.page));
        }
        break;
      case 'start':
        const startBtn = shadow?.getElementById('pnStart');
        if (startBtn && !started) startBtn.click();
        break;
      case 'reset':
        const resetBtn = shadow?.getElementById('pnReset');
        if (resetBtn) resetBtn.click();
        break;
      case 'toggleTTS':
        const ttsBtn = shadow?.getElementById('pnTTS');
        if (ttsBtn && !ttsBtn.disabled) ttsBtn.click();
        break;
      case 'setSpeed':
        if (cmd.speed) changeTTSSpeed(parseFloat(cmd.speed));
        break;
      case 'setAutoAdvance':
        const autoAdvCheckbox = shadow?.getElementById('pnAutoAdvance');
        if (autoAdvCheckbox) {
          autoAdvCheckbox.checked = !!cmd.value;
          ttsAutoAdvance = !!cmd.value;
          pushRemoteState(true);
        }
        break;
      case 'setGenre':
        if (cmd.genre) {
          const genreSelect = shadow?.getElementById('pnGenre');
          if (genreSelect) {
            genreSelect.value = cmd.genre;
            genreSelect.dispatchEvent(new Event('change'));
          }
        }
        break;
      case 'setLanguage':
        if (cmd.language) {
          const langSelect = shadow?.getElementById('pnLang');
          if (langSelect) {
            langSelect.value = cmd.language;
            langSelect.dispatchEvent(new Event('change'));
          }
        }
        break;
      case 'setContext':
        if (cmd.context) {
          const btn = shadow?.querySelector(`.pn-context-btn[data-count="${cmd.context}"]`);
          if (btn) btn.click();
        }
        break;
      case 'setSummaryLength':
        if (cmd.length) {
          const lenSelect = shadow?.getElementById('pnLengthSelect');
          if (lenSelect) {
            lenSelect.value = cmd.length;
            lenSelect.dispatchEvent(new Event('change'));
          }
        }
        break;
      case 'toggleOriginal':
        const origCheckbox = shadow?.getElementById('pnOriginalEnabled');
        if (origCheckbox) {
          origCheckbox.checked = !origCheckbox.checked;
          origCheckbox.dispatchEvent(new Event('change'));
        }
        break;
      case 'toggleNightMode':
        const nightBtn = shadow?.getElementById('pnNightMode');
        if (nightBtn) nightBtn.click();
        break;
      case 'fontInc':
        const incBtn = shadow?.getElementById('pnFontInc');
        if (incBtn) incBtn.click();
        break;
      case 'fontDec':
        const decBtn = shadow?.getElementById('pnFontDec');
        if (decBtn) decBtn.click();
        break;
      case 'setRecapMode':
        recapMode = !!cmd.enabled;
        const recapCheckbox = shadow?.getElementById('pnRecapEnabled');
        if (recapCheckbox) {
          recapCheckbox.checked = recapMode;
          chrome.storage.local.set({ recapMode });
        }
        break;
      case 'requestRecap':
        const reqPage = Number(cmd.page) || currentPage;
        const pageSum = summaries[reqPage];
        if (pageSum) {
          fetchRecap(pageSum).then((res) => {
            if (res && res.success) {
              pushRemoteState(true);
            }
          });
        }
        break;
    }
    pushRemoteState(true);
  }


  // ===== LOAD SETTINGS =====
  chrome.storage.local.get(['ollamaUrl', 'ollamaModel', 'fontSize', 'panelLeft', 'panelTop', 'panelWidth', 'panelHeight', 'lbWidth', 'chWidth', 'panelOpacity', 'nightMode', 'bookGenre', 'language', 'contextCount', 'recapFontSize', 'recapPopupBounds', 'recapMode', 'summaryLength', 'discordRpcEnabled', 'positionEnabled'], (data) => {
    if (data.discordRpcEnabled !== undefined) {
      discordRpcEnabled = data.discordRpcEnabled;
    }
    if (data.positionEnabled !== undefined) {
      positionEnabled = data.positionEnabled;
    }
    if (data.ollamaUrl)  ollamaUrl       = data.ollamaUrl;
    if (data.ollamaModel) {
      if (data.ollamaModel === 'gpt-oss:120b-cloud') {
        ollamaModel = 'nemotron-3-ultra:cloud';
        chrome.storage.local.set({ ollamaModel: 'nemotron-3-ultra:cloud' });
      } else {
        ollamaModel = data.ollamaModel;
      }
    }
    if (data.fontSize)   currentFontSize = parseInt(data.fontSize);
    if (data.panelOpacity) panelOpacity = data.panelOpacity;
    if (data.nightMode !== undefined) nightMode = data.nightMode;
    if (data.contextCount) contextCount = data.contextCount;
    if (data.summaryLength) summaryLength = parseInt(data.summaryLength);
    if (data.recapFontSize) recapFontSize = parseInt(data.recapFontSize);
    if (data.recapPopupBounds) recapPopupBounds = data.recapPopupBounds;
    if (data.recapMode !== undefined) {
      recapMode = data.recapMode;
      // Sync the checkbox state (the checkbox is created later in createPanel,
      // so we need to apply the saved state after it exists)
      // We'll handle this in createPanel by reading recapMode
    }
    if (data.bookGenre) {
      if (data.bookGenre === 'nonfiction') {
        bookGenre = 'nonfiction_classic';
        chrome.storage.local.set({ bookGenre: 'nonfiction_classic' });
      } else {
        bookGenre = data.bookGenre;
      }
    }
    if (data.language) language = data.language;
    createPanel(data);
  });

  // ===== CREATE FLOATING PANEL =====
  function createPanel(savedData = {}) {
    const host = document.createElement('div');
    host.id = 'pdf-summarizer-host';
    shadow = host.attachShadow({ mode: 'closed' });

    // Load CSS
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('content.css');
    shadow.appendChild(link);

    // Build panel HTML
    panel = document.createElement('div');
    panel.className = 'pn-panel';
    panel.innerHTML = `
      <!-- Header -->
      <div class="pn-header" id="pnHeader">
        <div class="pn-header-left">
          <input type="range" class="pn-opacity-slider" id="pnOpacity" min="0.2" max="1" step="0.01" value="1" title="Adjust Window Opacity">
        </div>
        <div class="pn-header-center">
          <label class="pn-header-toggle" id="pnTtsToggleWrap" title="Enable/disable Text-to-Speech.">
            <input type="checkbox" id="pnTtsEnabled" checked>
            <span class="pn-header-toggle-label">TTS</span>
          </label>
          <label class="pn-header-toggle" id="pnOriginalToggleWrap" title="Show the book's original text instead of AI summaries.">
            <input type="checkbox" id="pnOriginalEnabled">
            <span class="pn-header-toggle-label">Original</span>
          </label>
          <label class="pn-header-toggle" id="pnRecapToggleWrap" title="Show a quick recap popup of the previous pages on navigation.">
            <input type="checkbox" id="pnRecapEnabled">
            <span class="pn-header-toggle-label">Recap</span>
          </label>
          <label class="pn-header-toggle" id="pnDiscordToggleWrap" title="Broadcast reading activity to Discord Rich Presence.">
            <input type="checkbox" id="pnDiscordEnabled" checked>
            <span class="pn-header-toggle-label">Discord</span>
          </label>
          <label class="pn-header-toggle" id="pnPositionToggleWrap" title="Remember reading position for this PDF (up to 10 days).">
            <input type="checkbox" id="pnPositionEnabled" checked>
            <span class="pn-header-toggle-label">Position</span>
          </label>
        </div>
        <div class="pn-header-right">
          <button class="pn-icon-btn" id="pnRefreshTTS" title="Refresh TTS — re-fetch voices from Piper if you forgot to start the server before opening the PDF">⟳</button>
          <button class="pn-icon-btn" id="pnNightMode" title="Toggle Night Mode">◑</button>
          <button class="pn-icon-btn" id="pnFontDec" title="Decrease Font Size" style="font-weight: 600;">A-</button>
          <button class="pn-icon-btn" id="pnFontInc" title="Increase Font Size" style="font-weight: 600;">A+</button>
          <button class="pn-icon-btn" id="pnCollapse" title="Collapse (or press Ctrl+Q to hide/show)">—</button>
        </div>
      </div>

      <div class="pn-body">
        <!-- Page Navigation -->
        <div class="pn-page-nav-section" style="border-bottom: 1px solid rgba(255, 255, 255, 0.06); flex-shrink: 0;">
          <div class="pn-page-nav" style="border-bottom: none;">
            <button class="pn-page-btn" id="pnPrev" title="Previous page">◄</button>
            <input type="text" class="pn-page-input" id="pnPageInput" value="1">
            <span class="pn-page-total" id="pnPageTotal">/ —</span>
            <button class="pn-page-btn" id="pnNext" title="Next page">►</button>
          </div>
          <div class="pn-progress-container">
            <div class="pn-progress-outer">
              <div class="pn-progress-fill" id="pnProgressFill"></div>
            </div>
            <div class="pn-progress-text">
              <span id="pnPercent">0%</span>
              <span id="pnPagesLeft">— pages left</span>
            </div>
          </div>
        </div>

        <!-- Action Bar -->
        <div class="pn-action-bar">
          <button class="pn-action-btn start" id="pnStart" title="Start summarizing">▶ Start</button>
          <button class="pn-action-btn reset" id="pnReset" title="Clear all summaries">⟲ Reset</button>
          <button class="pn-action-btn tts" id="pnTTS" title="Play / Pause TTS" disabled>▶ Play</button>
        </div>

        <!-- Audio controls panel -->
        <div class="pn-audio-controls" id="pnAudioControls" style="display: none;">
          <div class="pn-audio-scrubber-row">
            <span class="pn-audio-time" id="pnAudioCurrentTime">0:00</span>
            <input type="range" class="pn-audio-scrubber" id="pnAudioScrubber" min="0" max="100" value="0">
            <span class="pn-audio-time" id="pnAudioDuration">0:00</span>
          </div>
          <div class="pn-audio-toolbar">
            <div class="pn-audio-speed-group">
              <span class="pn-audio-label">Speed:</span>
              <select class="pn-audio-speed" id="pnAudioSpeed">
                <option value="1.0" selected>1.0x</option>
                <option value="1.2">1.2x</option>
                <option value="1.5">1.5x</option>
                <option value="1.7">1.7x</option>
                <option value="1.8">1.8x</option>
                <option value="2.0">2.0x</option>
              </select>
            </div>
            <label class="pn-audio-toggle" title="Auto-advance to the next page when audio ends">
              <input type="checkbox" id="pnAutoAdvance" checked>
              <span class="pn-toggle-label">Auto-advance</span>
            </label>
          </div>
        </div>

        <!-- Settings Bar -->
        <div class="pn-settings-bar">
          <div class="pn-settings-group">
            <select class="pn-genre-select" id="pnGenre">
              <optgroup label="Non-Fiction">
                <option value="nonfiction_classic">Non-Fiction Classic</option>
                <option value="nonfiction_headers">Non-Fiction (With Headers)</option>
                <option value="law_books">Law Books</option>
                <option value="law_statutes">Law Statutes</option>
                <option value="research_papers">Research Papers</option>
                <option value="self_help">Self Help Books</option>
              </optgroup>
              <optgroup label="Fiction">
                <option value="fiction">Fiction (General)</option>
                <option value="philosophical_fiction">Philosophical Fiction</option>
              </optgroup>
            </select>
          </div>
          <div class="pn-settings-group">
            <select class="pn-genre-select" id="pnLang">
              <option value="English">English</option>
              <option value="Arabic">Arabic</option>
              <option value="French">French</option>
              <option value="Italian">Italian</option>
              <option value="Spanish">Spanish</option>
            </select>
          </div>
          <div class="pn-settings-group">
            <div class="pn-context-options">
              <button class="pn-context-btn" data-count="1">1p</button>
              <button class="pn-context-btn" data-count="2">2p</button>
              <button class="pn-context-btn" data-count="5">5p</button>
              <button class="pn-context-btn" data-count="10">10p</button>
              <button class="pn-context-btn" data-count="20">20p</button>
              <button class="pn-context-btn" data-count="30">30p</button>
              <button class="pn-context-btn" data-count="40">40p</button>
              <button class="pn-context-btn" data-count="50">50p</button>
              <button class="pn-context-btn" data-count="60">60p</button>
            </div>
          </div>
          <div class="pn-settings-group">
            <div class="pn-range-bar" style="display:flex; align-items:center; gap:4px;">
              <input type="number" id="pnRangeInput" placeholder="Page" style="height: 24px; width: 50px; font-size: 11px; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 4px; padding: 0 4px; background: rgba(0,0,0,0.2); color: #fff; box-sizing: border-box;" min="1">
              <button id="pnRangeStart" style="height: 24px; font-size: 11px; padding: 0 8px; background: rgba(99, 102, 241, 0.2); color: #818cf8; border: 1px solid rgba(99, 102, 241, 0.4); border-radius: 4px; cursor: pointer; font-weight: 500; box-sizing: border-box; display: flex; align-items: center; justify-content: center;">Start Range</button>
            </div>
          </div>
          <div class="pn-settings-group">
            <select class="pn-genre-select" id="pnLengthSelect" title="Maximum word count for the summary" style="width: 62px; min-width: 62px;">
              <option value="50">50</option>
              <option value="200">200</option>
              <option value="500">500</option>
              <option value="750">750</option>
              <option value="1000" selected>1000</option>
              <option value="1500">1500</option>
              <option value="2000">2000</option>
            </select>
          </div>
          <div class="pn-settings-group">
            <select class="pn-genre-select pn-voice-select" id="pnVoice" title="Voice (from Piper server)">
              <option value="">— Piper offline —</option>
            </select>
          </div>
          <div class="pn-settings-group" style="padding: 0 4px;">
            <button class="pn-icon-btn pn-bookmark-btn" id="pnBookmarkBtn" title="Bookmark current summary">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
              </svg>
            </button>
          </div>
        </div>
        <span class="pn-genre-badge nonfiction" id="pnGenreBadge" style="display:none;">NON-FICTION CLASSIC</span>

        <!-- Summary Text -->
        <div class="pn-summary">
          <div class="pn-bookmark-banner" id="pnBookmarkBanner" style="display:none;"></div>
          <div class="pn-summary-text idle" id="pnSummary">
            Press <strong>Start</strong> to summarize this page.
          </div>
        </div>

        <!-- Status -->
        <div class="pn-status" id="pnStatus">
          <div class="pn-status-left">
            <span class="pn-dot disconnected" id="pnDot"></span>
            <span id="pnStatusLabel">Checking...</span>
            <span id="pnSummaryStats" style="color:#71717a; font-size:10px; margin-left:8px;"></span>
          </div>
          <span id="pnModelLabel">—</span>
        </div>
      </div>

      <!-- Resize Handles -->
      <div class="pn-resize-handle left" data-dir="l"></div>
      <div class="pn-resize-handle right" data-dir="r"></div>
      <div class="pn-resize-handle top" data-dir="t"></div>
      <div class="pn-resize-handle bottom" data-dir="b"></div>
      <div class="pn-resize-handle top-left" data-dir="tl"></div>
      <div class="pn-resize-handle top-right" data-dir="tr"></div>
      <div class="pn-resize-handle bottom-left" data-dir="bl"></div>
      <div class="pn-resize-handle bottom-right" data-dir="br"></div>
    `;

    shadow.appendChild(panel);
    document.documentElement.appendChild(host);

    // Apply saved position / size
    if (savedData.panelWidth)  panel.style.width  = savedData.panelWidth  + 'px';
    if (savedData.panelHeight) panel.style.height = savedData.panelHeight + 'px';
    if (savedData.panelLeft != null) {
      panel.style.right = 'auto';
      panel.style.left  = savedData.panelLeft + 'px';
    }
    if (savedData.panelTop  != null) panel.style.top = savedData.panelTop + 'px';
    if (savedData.panelOpacity != null) {
      panelOpacity = savedData.panelOpacity;
      panel.style.opacity = panelOpacity;
    }

    // Cache DOM refs
    summaryTextEl = shadow.getElementById('pnSummary');
    pageInput     = shadow.getElementById('pnPageInput');
    pageTotalEl   = shadow.getElementById('pnPageTotal');
    statusDot     = shadow.getElementById('pnDot');
    statusLabel   = shadow.getElementById('pnStatusLabel');
    modelLabel    = shadow.getElementById('pnModelLabel');
    startBtn      = shadow.getElementById('pnStart');
    progressFill  = shadow.getElementById('pnProgressFill');
    percentLabel  = shadow.getElementById('pnPercent');
    pagesLeftLabel = shadow.getElementById('pnPagesLeft');

    // Apply saved font size
    summaryTextEl.style.fontSize = currentFontSize + 'px';

    // Sync opacity slider
    const opSlider = shadow.getElementById('pnOpacity');
    opSlider.value = panelOpacity;

    // ===== WIRE UP EVENTS =====

    // Collapse / expand
    shadow.getElementById('pnCollapse').addEventListener('click', (e) => {
      e.stopPropagation();
      panelCollapsed = true;
      panel.classList.add('collapsed');
    });

    panel.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key && e.key.toLowerCase() === 'q') {
        e.preventDefault();
        e.stopImmediatePropagation();
        toggleMiddlePanel();
      }
    }, true);

    // Refresh TTS button — re-fetches voices from the Piper server without
    // reloading the page. Useful when you forgot to start Piper before
    // opening the PDF, or when you've added new voices mid-session.
    shadow.getElementById('pnRefreshTTS').addEventListener('click', async (e) => {
      e.stopPropagation();
      const btn = shadow.getElementById('pnRefreshTTS');
      const originalText = btn.textContent;
      btn.textContent = '...';
      btn.disabled = true;

      // Clear the cached voice list so refreshPanelVoiceDropdown re-fetches
      cachedPanelVoices = [];

      // Re-fetch voices from the Piper server
      await new Promise(resolve => {
        chrome.storage.local.get(['piperUrl'], (data) => {
          const url = (data.piperUrl || 'http://localhost:5000').replace(/\/+$/, '');
          chrome.runtime.sendMessage(
            { type: 'CHECK_PIPER_VOICES', url },
            (res) => {
              if (chrome.runtime.lastError || !res || !res.success) {
                // Show a brief error in the button tooltip
                btn.textContent = '❌';
                btn.title = 'Cannot reach Piper. Make sure start-piper.bat is running.';
                setTimeout(() => {
                  btn.textContent = originalText;
                  btn.disabled = false;
                  btn.title = 'Refresh TTS — re-fetch voices from Piper if you forgot to start the server before opening the PDF';
                }, 2000);
                resolve();
                return;
              }
              // Cache and populate the dropdown
              cachedPanelVoices = normalizeVoices(res.voices || []);
              refreshPanelVoiceDropdown();
              btn.textContent = 'Done';
              const count = cachedPanelVoices.length;
              btn.title = `Refreshed — ${count} voice(s) loaded`;
              setTimeout(() => {
                btn.textContent = originalText;
                btn.disabled = false;
                btn.title = 'Refresh TTS — re-fetch voices from Piper if you forgot to start the server before opening the PDF';
              }, 1500);
              resolve();
            }
          );
        });
      });
    });

    // Font size controls
    shadow.getElementById('pnFontDec').addEventListener('click', (e) => {
      e.stopPropagation();
      currentFontSize = Math.max(10, currentFontSize - 1);
      summaryTextEl.style.fontSize = currentFontSize + 'px';
      chrome.storage.local.set({ fontSize: currentFontSize });
    });
    shadow.getElementById('pnFontInc').addEventListener('click', (e) => {
      e.stopPropagation();
      currentFontSize = Math.min(36, currentFontSize + 1);
      summaryTextEl.style.fontSize = currentFontSize + 'px';
      chrome.storage.local.set({ fontSize: currentFontSize });
    });

    panel.addEventListener('click', () => {
      if (panelCollapsed) {
        panelCollapsed = false;
        panel.classList.remove('collapsed');
      }
    });

    // Night Mode toggle
    shadow.getElementById('pnNightMode').addEventListener('click', (e) => {
      e.stopPropagation();
      nightMode = !nightMode;
      applyPDFInversion();
      chrome.storage.local.set({ nightMode: nightMode });
    });

    // Page navigation
    shadow.getElementById('pnPrev').addEventListener('click', () => goToPage(Math.max(currentPage - contextCount, 1)));
    shadow.getElementById('pnNext').addEventListener('click', () => goToPage(Math.min(currentPage + contextCount, totalPages)));

    // Page number input
    const commitPage = () => {
      // Parse the input — the user types a plain page number (e.g., "80")
      // even though the display shows a range (e.g., "80-139")
      const val = parseInt(pageInput.value, 10);
      if (!isNaN(val) && val >= 1 && val <= totalPages) goToPage(val);
      else {
        // Restore the range display for the current page
        const endPage = Math.min(currentPage + contextCount - 1, totalPages);
        pageInput.value = (endPage > currentPage) ? currentPage + '-' + endPage : currentPage;
      }
    };
    
    // Click to select all text for easy replacement
    pageInput.addEventListener('click', () => {
      // When editing starts, show just the page number (not the range)
      pageInput.value = currentPage;
      pageInput.select();
    });

    // On blur, restore the range display
    pageInput.addEventListener('blur', () => {
      const endPage = Math.min(currentPage + contextCount - 1, totalPages);
      pageInput.value = (endPage > currentPage) ? currentPage + '-' + endPage : currentPage;
    });

    // Because Chrome's PDF viewer blocks native typing even if we stop propagation,
    // we manually intercept keystrokes at the window capture level and update the value.
    window.addEventListener('keydown', (e) => {
      if (shadow && shadow.activeElement === pageInput) {
        if (e.key === 'Tab') return;
        e.stopImmediatePropagation();
        e.preventDefault();

        const s = pageInput.selectionStart;
        const en = pageInput.selectionEnd;
        
        if (e.key === 'Enter') {
          commitPage();
          pageInput.blur();
        } else if (e.key === 'Escape') {
          // Restore the range display on cancel
          const endPage = Math.min(currentPage + contextCount - 1, totalPages);
          pageInput.value = (endPage > currentPage) ? currentPage + '-' + endPage : currentPage;
          pageInput.blur();
        } else if (e.key === 'Backspace') {
          document.execCommand('delete', false);
        } else if (e.key === 'Delete') {
          document.execCommand('forwardDelete', false);
        } else if (e.key === 'ArrowLeft') {
          const pos = Math.max(0, s - 1);
          pageInput.setSelectionRange(pos, pos);
        } else if (e.key === 'ArrowRight') {
          const pos = Math.min(pageInput.value.length, en + 1);
          pageInput.setSelectionRange(pos, pos);
        } else if (/^[0-9]$/.test(e.key)) {
          document.execCommand('insertText', false, e.key);
        }
      }
    }, true);

    ['keyup', 'keypress'].forEach(evt => {
      window.addEventListener(evt, (e) => {
        if (shadow && shadow.activeElement === pageInput) {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
      }, true);
    });

    // Commit when clicking away
    pageInput.addEventListener('blur', commitPage);

    // Start / Continue button
    shadow.getElementById('pnStart').addEventListener('click', (e) => {
      e.stopPropagation();
      if (!pdfReady) return;

      const isContinuing = !started && savedPdfPosition && savedPdfPosition.page && positionEnabled;
      const targetPage = isContinuing ? savedPdfPosition.page : currentPage;

      started = true;
      startBtn.disabled = true;

      // If continuing to a saved position on another page, navigate there
      if (isContinuing && targetPage !== currentPage) {
        goToPage(targetPage);
      }

      // Start Discord Rich Presence for this active book
      if (discordRpcEnabled) {
        sendDiscordPresence(true, true);
        startDiscordHeartbeat();
      }

      // Summarize the target page + buffer one ahead
      if (!summaries[targetPage] && !summarizing.has(targetPage)) {
        summarizePage(targetPage);
      }
      schedulePrefetch(targetPage);

      // Save position
      if (positionEnabled) {
        saveCurrentPosition(targetPage);
      }
    });

    // Right-click Start/Continue button: clear saved position if not started yet
    shadow.getElementById('pnStart').addEventListener('contextmenu', (e) => {
      if (!started && savedPdfPosition) {
        e.preventDefault();
        e.stopPropagation();
        clearSavedPosition();
        updateStartButtonUI(false);
      }
    });

    // Reset button
    shadow.getElementById('pnReset').addEventListener('click', (e) => {
      e.stopPropagation();
      started = false;
      stopDiscordHeartbeat();
      clearDiscordPresence();
      clearSavedPosition();
      updateStartButtonUI(false);
      summaries = {};
      summarizing.clear();
      recapCache = {};
      recapInFlight.clear();
      startBtn.disabled = false;
      summaryTextEl.className = 'pn-summary-text idle';
      summaryTextEl.innerHTML = 'Press <strong>Start</strong> to summarize this page.';
      
      // Stop and clear TTS audio + per-page resume positions
      stopAudio(true);
      if (ttsAudioBuffer) {
        URL.revokeObjectURL(ttsAudioBuffer);
        ttsAudioBuffer = null;
      }
      currentPageForAudio = null;
      currentPageForScroll = null;
      pageResumePositions = {};
      autoAdvanceTarget = null;
      ttsIntentActive = false;
      const controls = shadow.getElementById('pnAudioControls');
      if (controls) controls.style.display = 'none';
      updateTTSButtonLabel();
      chrome.runtime.sendMessage({ type: 'CLEAR_AUDIO_CACHE', url: pdfUrl });
    });

    // TTS button
    shadow.getElementById('pnTTS').addEventListener('click', (e) => {
      e.stopPropagation();
      handleTTSButtonClick();
    });

    // Scrubber event listeners
    const scrubber = shadow.getElementById('pnAudioScrubber');
    const curTimeLabel = shadow.getElementById('pnAudioCurrentTime');
    
    scrubber.addEventListener('input', () => {
      if (curTimeLabel) {
        curTimeLabel.textContent = formatTime(scrubber.value);
      }
    });

    scrubber.addEventListener('change', () => {
      const seekTime = parseFloat(scrubber.value);
      if (ttsAudioBuffer) {
        playFromOffset(seekTime);
      }
    });

    // Speed selector listener
    const speedSelect = shadow.getElementById('pnAudioSpeed');
    speedSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      changeTTSSpeed(speedSelect.value);
    });

    // Auto-advance toggle listener
    const autoAdvanceCheckbox = shadow.getElementById('pnAutoAdvance');
    if (autoAdvanceCheckbox) {
      autoAdvanceCheckbox.addEventListener('change', (e) => {
        e.stopPropagation();
        ttsAutoAdvance = autoAdvanceCheckbox.checked;
      });
    }

    // TTS master enable/disable toggle listener (now in header center)
    const ttsEnabledCheckbox = shadow.getElementById('pnTtsEnabled');
    if (ttsEnabledCheckbox) {
      ttsEnabledCheckbox.addEventListener('change', (e) => {
        e.stopPropagation();
        ttsEnabled = ttsEnabledCheckbox.checked;
        if (!ttsEnabled) {
          // Stop everything, clear intent, hide controls
          ttsIntentActive = false;
          autoAdvanceTarget = null;
          stopAudio(true);
          const controls = shadow.getElementById('pnAudioControls');
          if (controls) controls.style.display = 'none';
        }
        // When re-enabled, don't auto-start — let user click Play.
        // But update the button label so it shows Play/Resume.
        updateTTSButtonLabel();
      });
    }

    // "Original" mode toggle — when ON, the main panel shows the raw book
    // text for the current context pages instead of AI summaries. This is
    // a completely independent display mode; it doesn't touch the summary
    // cache, TTS, prefetch, or any other existing logic. When toggled OFF,
    // the panel reverts to showing the cached summary for the current page.
    const originalCheckbox = shadow.getElementById('pnOriginalEnabled');
    if (originalCheckbox) {
      originalCheckbox.addEventListener('change', (e) => {
        e.stopPropagation();
        originalMode = originalCheckbox.checked;
        if (originalMode) {
          // Immediately load original text for the current page set
          loadOriginalText();
        } else {
          // Revert to normal summary display
          if (pdfReady) goToPage(currentPage);
        }
      });
    }

    // "Recap" mode toggle — when ON, navigating to a new page triggers a
    // popup overlay showing a condensed 3-4 sentence recap of the summary
    // for the page(s) you just left. The popup stays open until closed
    // manually (✕ button, click outside, or 'f' keypress). This is purely
    // additive — it doesn't modify any existing navigation or summary logic.
    // The toggle state is persisted to chrome.storage so it's remembered
    // across sessions.
    const recapCheckbox = shadow.getElementById('pnRecapEnabled');
    if (recapCheckbox) {
      // Sync the checkbox to the loaded recapMode state
      recapCheckbox.checked = recapMode;
      recapCheckbox.addEventListener('change', (e) => {
        e.stopPropagation();
        recapMode = recapCheckbox.checked;
        // Persist the toggle state
        chrome.storage.local.set({ recapMode });
        // If turning OFF, dismiss any open recap popup
        if (!recapMode) dismissRecapPopup();
      });
    }

    // Discord Rich Presence toggle
    const discordCheckbox = shadow.getElementById('pnDiscordEnabled');
    if (discordCheckbox) {
      discordCheckbox.checked = discordRpcEnabled;
      discordCheckbox.addEventListener('change', (e) => {
        e.stopPropagation();
        discordRpcEnabled = discordCheckbox.checked;
        chrome.storage.local.set({ discordRpcEnabled });
        if (discordRpcEnabled && started) {
          sendDiscordPresence(true, false);
          startDiscordHeartbeat();
        } else if (!discordRpcEnabled) {
          stopDiscordHeartbeat();
          clearDiscordPresence();
        }
      });
    }

    // Position toggle (decides whether to save reading position for up to 10 days)
    const positionCheckbox = shadow.getElementById('pnPositionEnabled');
    if (positionCheckbox) {
      positionCheckbox.checked = positionEnabled;
      positionCheckbox.addEventListener('change', (e) => {
        e.stopPropagation();
        positionEnabled = positionCheckbox.checked;
        chrome.storage.local.set({ positionEnabled });
        if (!positionEnabled) {
          if (!started) {
            updateStartButtonUI(false);
          }
        } else {
          if (!started && savedPdfPosition && savedPdfPosition.page) {
            updateStartButtonUI(true, savedPdfPosition.page);
          }
        }
      });
    }

    // Genre selector
    const genreSelect = shadow.getElementById('pnGenre');
    const genreBadge = shadow.getElementById('pnGenreBadge');
    genreSelect.value = bookGenre;
    updateGenreBadge();

    genreSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      bookGenre = genreSelect.value;
      chrome.storage.local.set({ bookGenre });
      updateGenreBadge();

      // Clear cache and re-summarize if started
      summaries = {};
      summarizing.clear();
      recapCache = {};
      recapInFlight.clear();
      if (started && pdfReady) {
        summarizePage(currentPage);
      }
    });

    // Language selector
    const langSelect = shadow.getElementById('pnLang');
    langSelect.value = language;

    langSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      language = langSelect.value;
      chrome.storage.local.set({ language });

      // Clear cache and re-summarize if started
      summaries = {};
      summarizing.clear();
      recapCache = {};
      recapInFlight.clear();
      if (started && pdfReady) {
        summarizePage(currentPage);
      }
      applyTextDirection();

      // Refresh the voice dropdown to show voices for the new language
      refreshPanelVoiceDropdown();
    });

    // ===== PANEL VOICE DROPDOWN =====
    // Live dropdown that fetches voices from the running Piper server,
    // filters them to match the currently-selected language, and saves
    // the user's choice per-language (using the same storage keys the
    // popup uses: piperVoiceEn / piperVoiceAr / piperVoiceFr / etc.)
    let cachedPanelVoices = [];          // last fetched voice list from server
    let piperVoiceUrl = 'http://localhost:5000';

    // Helper: get the storage key for the current panel language
    function getVoiceStorageKey(lang) {
      const map = {
        English: 'piperVoiceEn',
        Arabic:  'piperVoiceAr',
        French:  'piperVoiceFr',
        Italian: 'piperVoiceIt',
        Spanish: 'piperVoiceEs'
      };
      return map[lang] || map.English;
    }

    // Helper: check if a voice matches the current language
    function voiceMatchesLanguage(voice, lang) {
      // Normalize for comparison
      const vLang = (voice.language || '').toLowerCase();
      const vCode = (voice.language_code || '').toLowerCase();
      const target = lang.toLowerCase();
      // English voices have language "English" or code "en_US"/"en_GB"
      // We match by checking if the language name OR the 2-letter code prefix matches
      const langCodeMap = {
        english: ['en'],
        arabic:  ['ar'],
        french:  ['fr'],
        italian: ['it'],
        spanish: ['es']
      };
      const codes = langCodeMap[target] || [];
      return vLang === target || codes.some(c => vCode.startsWith(c));
    }

    // Refresh the voice dropdown in the panel:
    // 1. Fetch voices from server (cached if recently fetched)
    // 2. Filter to voices matching the current language
    // 3. Pre-select the saved voice for that language
    function refreshPanelVoiceDropdown() {
      const voiceSelect = shadow.getElementById('pnVoice');
      if (!voiceSelect) return;

      voiceSelect.innerHTML = '<option value="">— Loading voices —</option>';

      // Read the Piper URL from storage first (user may have changed it in popup)
      chrome.storage.local.get(['piperUrl', getVoiceStorageKey(language)], (data) => {
        if (data.piperUrl) piperVoiceUrl = data.piperUrl;
        const savedVoice = data[getVoiceStorageKey(language)];

        // If we have cached voices, use them — no need to hit the server every time
        if (cachedPanelVoices.length > 0) {
          populatePanelVoices(cachedPanelVoices, savedVoice);
          return;
        }

        // Fetch from server via background script (bypasses CORS)
        chrome.runtime.sendMessage(
          { type: 'CHECK_PIPER_VOICES', url: piperVoiceUrl },
          (res) => {
            if (chrome.runtime.lastError || !res || !res.success) {
              voiceSelect.innerHTML = '<option value="">— Piper offline —</option>';
              voiceSelect.title = 'Cannot reach Piper server. Make sure it is running.';
              return;
            }
            // Normalize the voice list — old Piper servers return strings,
            // new ones return objects. We normalize to objects.
            cachedPanelVoices = normalizeVoices(res.voices || []);
            populatePanelVoices(cachedPanelVoices, savedVoice);
          }
        );
      });
    }

    // Normalize voice list — accepts either:
    //   ["en_US-joe-medium", ...]                       (old server format)
    //   [{name, language, quality, ...}, ...]           (new server format)
    // Returns a list of {name, language, language_code, quality} objects.
    function normalizeVoices(rawVoices) {
      const langMap = {
        en_US: 'English', en_GB: 'English (UK)', en_IE: 'English (Irish)',
        en_ZA: 'English (South African)', en_IN: 'English (Indian)',
        ar_JO: 'Arabic', es_ES: 'Spanish', es_MX: 'Spanish (Mexico)',
        fr_FR: 'French', fr_BE: 'French (Belgian)',
        it_IT: 'Italian', de_DE: 'German', nl_NL: 'Dutch',
        pl_PL: 'Polish', pt_BR: 'Portuguese (Brazil)', pt_PT: 'Portuguese',
        ru_RU: 'Russian', zh_CN: 'Chinese', vi_VN: 'Vietnamese',
        cs_CZ: 'Czech', cy_GB: 'Welsh', tr_TR: 'Turkish',
        kk_KZ: 'Kazakh', ca_ES: 'Catalan',
      };
      return rawVoices.map(v => {
        if (typeof v === 'string') {
          const prefix = v.split('-')[0];
          const parts = v.split('-');
          const quality = parts.length >= 3 ? parts[parts.length - 1] : '';
          return {
            name: v,
            language: langMap[prefix] || prefix,
            language_code: prefix,
            quality: quality
          };
        } else if (v && typeof v === 'object') {
          return {
            name: v.name || v.voice || String(v),
            language: v.language || v.lang || '',
            language_code: v.language_code || v.code || '',
            quality: v.quality || ''
          };
        }
        return { name: String(v), language: '', language_code: '', quality: '' };
      });
    }

    // Populate the dropdown with voices filtered to the current language.
    // If no voices match the current language, show ALL voices (so the user
    // can still pick something rather than seeing an empty list).
    function populatePanelVoices(allVoices, savedVoice) {
      const voiceSelect = shadow.getElementById('pnVoice');
      if (!voiceSelect) return;

      // Try to match voices to the current language
      let filtered = allVoices.filter(v => voiceMatchesLanguage(v, language));

      // If no matches, fall back to all voices
      if (filtered.length === 0) {
        filtered = allVoices;
      }

      // Build options HTML
      let html = '';
      if (filtered.length === 0) {
        html = '<option value="">— No voices loaded —</option>';
        voiceSelect.title = 'No voices found. Download .onnx + .onnx.json files into your Piper voices folder.';
      } else {
        filtered.forEach(v => {
          const sel = v.name === savedVoice ? ' selected' : '';
          const quality = v.quality ? ` (${v.quality})` : '';
          html += `<option value="${v.name}"${sel}>${v.name}${quality}</option>`;
        });
        voiceSelect.title = `${filtered.length} voice(s) available`;
      }
      voiceSelect.innerHTML = html;

      // If we have a saved voice for this language and it's in the list,
      // the selected attribute already takes care of it. If we don't have
      // a saved voice OR the saved voice isn't in the list, save the first
      // available voice as the default for this language.
      const currentValue = voiceSelect.value;
      if (currentValue && currentValue !== savedVoice) {
        // Either no saved voice, or saved voice wasn't in the list — save current
        const key = getVoiceStorageKey(language);
        chrome.storage.local.set({ [key]: currentValue });
      }
    }

    // Voice dropdown change — save the selection for the current language
    const voiceSelectEl = shadow.getElementById('pnVoice');
    if (voiceSelectEl) {
      voiceSelectEl.addEventListener('change', (e) => {
        e.stopPropagation();
        const selected = voiceSelectEl.value;
        if (!selected) return;
        const key = getVoiceStorageKey(language);
        chrome.storage.local.set({ [key]: selected });

        // Clear audio cache so next Play uses the new voice
        if (ttsAudioBuffer) {
          URL.revokeObjectURL(ttsAudioBuffer);
          ttsAudioBuffer = null;
        }
        currentPageForAudio = null;
        currentPageForScroll = null;
        pageResumePositions = {};
        const controls = shadow.getElementById('pnAudioControls');
        if (controls) controls.style.display = 'none';
        stopAudio(true);
        chrome.runtime.sendMessage({ type: 'CLEAR_AUDIO_CACHE', url: pdfUrl });
      });

      // Stop keyboard events from propagating to the PDF viewer
      ['keydown', 'keyup', 'keypress'].forEach(evt => {
        voiceSelectEl.addEventListener(evt, (e) => e.stopPropagation());
      });
    }

    // Initial population of the voice dropdown (will fetch from server)
    refreshPanelVoiceDropdown();

    function updateGenreBadge() {
      if (bookGenre === 'philosophical_fiction') {
        genreBadge.textContent = 'PHILOSOPHICAL';
        genreBadge.className = 'pn-genre-badge philosophical';
      } else if (bookGenre === 'fiction') {
        genreBadge.textContent = 'FICTION';
        genreBadge.className = 'pn-genre-badge fiction';
      } else if (bookGenre === 'law_books') {
        genreBadge.textContent = 'LAW BOOKS';
        genreBadge.className = 'pn-genre-badge law';
      } else if (bookGenre === 'law_statutes') {
        genreBadge.textContent = 'LAW STATUTES';
        genreBadge.className = 'pn-genre-badge statutes';
      } else if (bookGenre === 'research_papers') {
        genreBadge.textContent = 'RESEARCH PAPERS';
        genreBadge.className = 'pn-genre-badge research';
      } else if (bookGenre === 'self_help') {
        genreBadge.textContent = 'SELF HELP';
        genreBadge.className = 'pn-genre-badge selfhelp';
      } else if (bookGenre === 'nonfiction_headers') {
        genreBadge.textContent = 'NON-FICTION (HEADERS)';
        genreBadge.className = 'pn-genre-badge nonfiction';
      } else {
        genreBadge.textContent = 'NON-FICTION CLASSIC';
        genreBadge.className = 'pn-genre-badge nonfiction';
      }
    }

    // ===== RTL / LTR DIRECTION =====
    function applyTextDirection() {
      const isRTL = language === 'Arabic';
      const dir = isRTL ? 'rtl' : 'ltr';
      const align = isRTL ? 'right' : 'justify';

      // Main summary panel
      if (summaryTextEl) {
        summaryTextEl.style.direction = dir;
        summaryTextEl.setAttribute('lang', isRTL ? 'ar' : 'en');
        summaryTextEl.style.textAlign = align;
      }

      // Chat bubbles (existing + future handled in appendChatMessage)
      if (chatMessagesEl) {
        chatMessagesEl.querySelectorAll('.ch-bubble').forEach(b => {
          b.style.direction = dir;
          b.style.textAlign = align;
        });
      }

      // Left bar summary items
      if (lbListEl) {
        lbListEl.querySelectorAll('.lb-item-content').forEach(el => {
          el.style.direction = dir;
          el.style.textAlign = align;
        });
      }

      // Quiz & purpose content areas
      if (chatShadow) {
        ['qzContent', 'qzResult', 'prQuestions'].forEach(id => {
          const el = chatShadow.getElementById(id);
          if (el) {
            el.style.direction = dir;
            el.style.textAlign = align;
          }
        });
      }
    }

    // Apply on initial load
    applyTextDirection();

    // Opacity control
    shadow.getElementById('pnOpacity').addEventListener('input', (e) => {
      panelOpacity = e.target.value;
      panel.style.opacity = panelOpacity;
      chrome.storage.local.set({ panelOpacity: panelOpacity });
    });

    // Context Mode control
    const contextBtns = shadow.querySelectorAll('.pn-context-btn');
    contextBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const count = parseInt(btn.dataset.count, 10);
        contextCount = count;
        chrome.storage.local.set({ contextCount: contextCount });
        
        contextBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Update the page input display to reflect the new range
        if (pdfReady && totalPages) {
          const endPage = Math.min(currentPage + contextCount - 1, totalPages);
          pageInput.value = (endPage > currentPage) ? currentPage + '-' + endPage : currentPage;
          updateProgressBar();
        }

        // Clear cache and re-summarize if started
        summaries = {};
        summarizing.clear();
        recapCache = {};
        recapInFlight.clear();

        if (started && pdfReady) {
          summarizePage(currentPage);
        }
      });
    });

    contextBtns.forEach(btn => {
      if (parseInt(btn.dataset.count, 10) === contextCount) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    const rangeStartBtn = shadow.getElementById('pnRangeStart');
    const rangeInput = shadow.getElementById('pnRangeInput');
    if (rangeStartBtn && rangeInput) {
      rangeStartBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const numPages = parseInt(rangeInput.value, 10);
        if (!numPages || numPages < 1) return;
        const endPage = Math.min(currentPage + numPages - 1, totalPages);
        summarizeHoverRange(currentPage, endPage);
      });
    }

    // Summary Length control (Short / Medium / Long)
    const lengthSelect = shadow.getElementById('pnLengthSelect');
    if (lengthSelect) {
      lengthSelect.value = summaryLength;
      lengthSelect.addEventListener('change', (e) => {
        e.stopPropagation();
        summaryLength = parseInt(e.target.value);
        chrome.storage.local.set({ summaryLength: summaryLength });

        // Clear cache and re-summarize if started
        summaries = {};
        summarizing.clear();
        recapCache = {};
        recapInFlight.clear();

        if (started && pdfReady) {
          summarizePage(currentPage);
        }
      });
    }

    // Drag to reposition — can grab by the header OR by the status bar
    // (the thin bar that shows "Ollama connected" + word count)
    makeDraggable(shadow.getElementById('pnHeader'), panel);
    makeDraggable(shadow.getElementById('pnStatus'), panel);

    // Resize panel
    makeResizable();

    // ===== KICK OFF =====
    checkOllama();
    parsePDF();

    // Create the AI chat panel
    createChatPanel(savedData);

    // Create the Notes & Summaries left bar
    createLeftBar(savedData);

    // Apply PDF inversion (Night Mode)
    applyPDFInversion();

    // Setup popup dismiss handler for word highlight mode
    setupPopupDismiss();

    // Initialize bookmark functionality
    initBookmarkFeature();

    // Initialize reading position functionality (10-day expiration)
    initPositionFeature();

    // Start listening for Android mobile remote commands
    startRemoteCommandListener();

    // Slow down mouse wheel scrolling in the summary panel by 50%.
    // Uses smooth scrolling to avoid the "jumping" that happens with
    // instant scroll. The default wheel speed is too fast for reading.
    const summaryContainer = summaryTextEl.parentElement;
    if (summaryContainer) {
      summaryContainer.addEventListener('wheel', (e) => {
        e.preventDefault();
        summaryContainer.scrollBy({ top: e.deltaY * 0.5, behavior: 'smooth' });
      }, { passive: false });
    }

    // Custom grabbable scrollbar. The native scrollbar is hidden via CSS.
    // The thumb is appended to the PANEL (not the scroll container) so it
    // stays fixed relative to the visible viewport — if we appended it
    // inside .pn-summary (the scroll container), it would scroll WITH the
    // content and disappear off-screen.
    if (summaryContainer) {
      const scrollThumb = document.createElement('div');
      scrollThumb.className = 'pn-scroll-thumb';
      panel.appendChild(scrollThumb);

      // Update thumb position + size on scroll and resize.
      // Position is relative to the PANEL, calculated from the scroll
      // container's bounding rect so the thumb overlays the summary area.
      const updateThumb = () => {
        const el = summaryContainer;
        const maxScroll = el.scrollHeight - el.clientHeight;
        if (maxScroll <= 0) {
          scrollThumb.style.display = 'none';
          return;
        }
        scrollThumb.style.display = 'block';

        const containerRect = el.getBoundingClientRect();
        const panelRect = panel.getBoundingClientRect();

        // Thumb height = proportion of visible content
        const thumbHeight = Math.max(30, (el.clientHeight / el.scrollHeight) * el.clientHeight);

        // Thumb top (relative to panel) = container top + scroll proportion
        const scrollTop = el.scrollTop;
        const thumbOffsetWithinContainer = (scrollTop / maxScroll) * (el.clientHeight - thumbHeight);
        const thumbTopRelativeToPanel = (containerRect.top - panelRect.top) + thumbOffsetWithinContainer;

        scrollThumb.style.height = thumbHeight + 'px';
        scrollThumb.style.top = thumbTopRelativeToPanel + 'px';
        // Position horizontally INSIDE the summary container (not at the
        // very edge) to avoid conflicting with the panel's resize handles.
        const thumbLeftRelativeToPanel = (containerRect.right - panelRect.left) - 18;
        scrollThumb.style.left = thumbLeftRelativeToPanel + 'px';
      };

      summaryContainer.addEventListener('scroll', updateThumb);
      // Re-check when content changes (summaries load, font size changes, etc.)
      const thumbObserver = new MutationObserver(() => updateThumb());
      thumbObserver.observe(summaryTextEl, { childList: true, subtree: true, characterData: true });
      // Also update on window resize (panel may have been resized)
      window.addEventListener('resize', updateThumb);

      // Drag the thumb to scroll
      let dragging = false;
      let dragStartY = 0;
      let dragStartScroll = 0;

      scrollThumb.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        scrollThumb.setPointerCapture(e.pointerId);
        dragging = true;
        dragStartY = e.clientY;
        dragStartScroll = summaryContainer.scrollTop;
        scrollThumb.classList.add('dragging');
      });

      scrollThumb.addEventListener('pointermove', (e) => {
        if (!dragging) return;
        const el = summaryContainer;
        const maxScroll = el.scrollHeight - el.clientHeight;
        const thumbHeight = parseFloat(scrollThumb.style.height) || 30;
        const trackHeight = el.clientHeight - thumbHeight;
        const dy = e.clientY - dragStartY;
        // Convert pixel movement to scroll position
        const scrollDelta = (dy / trackHeight) * maxScroll;
        el.scrollTop = dragStartScroll + scrollDelta;
        // Update the thumb position IMMEDIATELY
        updateThumb();
      });

      scrollThumb.addEventListener('pointerup', (e) => {
        if (!dragging) return;
        scrollThumb.releasePointerCapture(e.pointerId);
        dragging = false;
        scrollThumb.classList.remove('dragging');
      });

      scrollThumb.addEventListener('pointercancel', () => {
        dragging = false;
        scrollThumb.classList.remove('dragging');
      });

      // Initial position
      setTimeout(updateThumb, 100);
    }

    // Setup mouseup event listener on summary text for Ctrl+select phrase highlight
    summaryTextEl.addEventListener('mouseup', onSummaryMouseUp);

    // Track mouse coordinates over summaryTextEl for accurate popup positioning
    summaryTextEl.addEventListener('mousemove', (e) => {
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
    });
  }

  // ===== AI CHAT PANEL =====
  function createChatPanel(savedData = {}) {
    const chatHost = document.createElement('div');
    chatHost.id = 'pdf-chat-host';
    chatShadow = chatHost.attachShadow({ mode: 'closed' });

    // Inject CSS
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('content.css');
    chatShadow.appendChild(link);

    // Build chat panel HTML
    chatPanel = document.createElement('div');
    chatPanel.className = chatVisible ? 'ch-panel' : 'ch-panel ch-hidden';
    if (savedData.chWidth) chatPanel.style.width = savedData.chWidth + 'px';
    chatPanel.innerHTML = `
      <div class="ch-header" id="chHeader">
        <div class="ch-header-left">
          <div class="ch-logo">?</div>
          <span class="ch-title">Chat</span>
        </div>
        <div class="ch-header-right">
          <button class="ch-icon-btn" id="chClear" title="Clear chat">⟲</button>
          <button class="ch-icon-btn" id="chClose" title="Hide chat panel">✕</button>
        </div>
      </div>

      <div class="ch-tabs" id="chTabs">
        <div class="ch-tab active" data-tab="quiz">Quiz</div>
        <div class="ch-tab" data-tab="chat">Chat</div>
        <div class="ch-tab" data-tab="purpose">Purpose</div>
      </div>

      <!-- QUIZ TAB -->
      <div class="ch-tab-content ch-tab-quiz active" id="tabQuiz">
        <div class="qz-list" id="qzList">
          <div class="qz-empty">Loading quizzes...</div>
        </div>
        <div class="qz-view" id="qzView" style="display:none; flex-direction:column; padding: 16px; flex:1; overflow-y:auto; gap: 12px;">
          <div style="display:flex; align-items:center; gap:8px;">
            <button id="qzBack" class="ch-icon-btn">←</button>
            <span id="qzViewTitle" style="font-weight:600;"></span>
          </div>
          <div id="qzContent" class="qz-content" style="max-width:100%;"></div>
          <button id="qzSubmit" class="ch-send-btn" style="width:100%; border-radius:8px;">Submit Answers</button>
          <div id="qzResult" class="qz-content" style="display:none; max-width:100%;"></div>
        </div>
      </div>

      <!-- CHAT TAB -->
      <div class="ch-tab-content ch-tab-chat" id="tabChat" style="display:none;">
        <!-- Context Selector -->
        <div class="ch-context-bar">
          <div class="ch-context-label">Context:</div>
          <div class="ch-context-modes">
            <button class="ch-ctx-btn active" data-ctx="current">Current</button>
            <button class="ch-ctx-btn" data-ctx="next5">Next 5</button>
            <button class="ch-ctx-btn" data-ctx="next10">Next 10</button>
            <button class="ch-ctx-btn" data-ctx="area5">Area 5</button>
            <button class="ch-ctx-btn" data-ctx="area10">Area 10</button>
            <button class="ch-ctx-btn" data-ctx="area20">Area 20</button>
            <button class="ch-ctx-btn" data-ctx="range">Range…</button>
            <button class="ch-ctx-btn" data-ctx="custom">Custom…</button>
            <button class="ch-ctx-btn" data-ctx="all">All</button>
          </div>
          <div class="ch-context-range-row" id="chRangeRow" style="display:none;">
            <input type="number" class="ch-ctx-input" id="chRangeFrom" placeholder="From" min="1">
            <span>–</span>
            <input type="number" class="ch-ctx-input" id="chRangeTo" placeholder="To" min="1">
          </div>
          <div class="ch-context-custom-row" id="chCustomRow" style="display:none;">
            <input type="text" class="ch-ctx-input ch-ctx-custom" id="chCustomPages" placeholder="e.g. 1, 4, 6, 12">
          </div>
          <div class="ch-context-summary" id="chCtxSummary">Page 1</div>
        </div>

        <!-- Messages -->
        <div class="ch-messages" id="chMessages">
          <div class="ch-welcome">
            <div class="ch-welcome-icon">AI</div>
            <p>Select the context pages above, then ask any question about that section.</p>
          </div>
        </div>
        <div class="ch-input-area">
          <textarea class="ch-input" id="chInput" placeholder="Ask about the selected pages…" rows="1"></textarea>
          <button class="ch-send-btn" id="chSend" title="Send">➤</button>
        </div>
      </div>

      <!-- PURPOSE TAB -->
      <div class="ch-tab-content ch-tab-purpose" id="tabPurpose" style="display:none; flex-direction:column; padding: 20px; gap: 16px; overflow-y: auto;">
        <div class="pr-welcome" id="prWelcome" style="text-align: center; color: #a1a1aa; margin-top: 20px;">
          <div style="font-size: 32px; margin-bottom: 12px;">?</div>
          <p style="font-size: 14px; line-height: 1.6;">Read with intention. Let AI analyze the document and provide 3 encompassing questions to guide your focus.</p>
          <button class="ch-send-btn" id="prGenerate" style="width: 100%; margin-top: 24px; border-radius: 12px;">Generate Purpose Questions</button>
        </div>
        <div id="prContent" style="display:none; flex-direction:column; gap: 16px;">
          <div id="prQuestions" style="display:flex; flex-direction:column; gap: 12px;"></div>
          <button class="ch-icon-btn" id="prRefresh" title="Refresh Questions" style="align-self: flex-end; width: auto; padding: 0 12px; gap: 6px; font-size: 12px; color: #818cf8;">⟲ Regenerate</button>
        </div>
      </div>

      <div class="ch-resize-handle" id="chResize"></div>
    `;

    chatShadow.appendChild(chatPanel);
    document.documentElement.appendChild(chatHost);

    // Cache refs
    chatMessagesEl = chatShadow.getElementById('chMessages');
    chatInputEl    = chatShadow.getElementById('chInput');
    chatSendBtn    = chatShadow.getElementById('chSend');

    // Wire up — clear
    chatShadow.getElementById('chClear').addEventListener('click', () => {
      chatHistory = [];
      chatMessagesEl.innerHTML = `
        <div class="ch-welcome">
          <div class="ch-welcome-icon">AI</div>
          <p>Select the context pages above, then ask any question about that section.</p>
        </div>`;
    });

    // Wire up — close
    chatShadow.getElementById('chClose').addEventListener('click', () => {
      chatPanel.classList.add('ch-hidden');
      chatVisible = false;
      if (chatToggleBtn) chatToggleBtn.title = 'Open AI Chat';
    });

    // ===== CONTEXT SELECTOR WIRING =====
    const chRangeRow = chatShadow.getElementById('chRangeRow');
    const chCustomRow = chatShadow.getElementById('chCustomRow');
    const chCtxSummary = chatShadow.getElementById('chCtxSummary');
    const chRangeFrom = chatShadow.getElementById('chRangeFrom');
    const chRangeTo = chatShadow.getElementById('chRangeTo');
    const chCustomPages = chatShadow.getElementById('chCustomPages');

    // Compute which pages are in context based on the current mode
    // (assigned to module-scope getChatContextPages so sendChatMessage can use it)
    getChatContextPages = function() {
      if (!pdfReady || !totalPages) return [];
      const cur = currentPage;
      switch (chatContextMode) {
        case 'current':
          return [cur];
        case 'next5':
          return rangeArr(cur, cur + 4); // current + next 4 = 5 pages
        case 'next10':
          return rangeArr(cur, cur + 9); // current + next 9 = 10 pages
        case 'area5': {
          // 5 pages centered on current (current ± 2)
          const half = 2;
          const from = Math.max(1, cur - half);
          const to = Math.min(totalPages, cur + half);
          return rangeArr(from, to);
        }
        case 'area10': {
          // 10 pages centered on current (current ± 5)
          const half = 5;
          const from = Math.max(1, cur - half);
          const to = Math.min(totalPages, cur + half);
          return rangeArr(from, to);
        }
        case 'area20': {
          // 20 pages centered on current (current ± 10)
          const half = 10;
          const from = Math.max(1, cur - half);
          const to = Math.min(totalPages, cur + half);
          return rangeArr(from, to);
        }
        case 'range': {
          const from = parseInt(chRangeFrom.value) || 1;
          const to = parseInt(chRangeTo.value) || totalPages;
          return rangeArr(Math.max(1, from), Math.min(totalPages, to));
        }
        case 'custom': {
          // Parse comma-separated page numbers: "1, 4, 6, 12"
          const raw = chCustomPages.value.trim();
          if (!raw) return [];
          return raw.split(/[,;\s]+/)
            .map(s => parseInt(s))
            .filter(n => !isNaN(n) && n >= 1 && n <= totalPages)
            .sort((a, b) => a - b);
        }
        case 'all': {
          // All pages from 1 to totalPages. The backend caps at 60k chars,
          // so for small books this sends the whole thing; for large books
          // it sends as much as the model can handle (truncated from page 1
          // onward, so the beginning of the book is always included).
          return rangeArr(1, totalPages);
        }
        default:
          return [cur];
      }
    }

    function rangeArr(from, to) {
      const arr = [];
      for (let i = from; i <= to; i++) arr.push(i);
      return arr;
    }

    // Update the summary text showing which pages are selected
    function updateContextSummary() {
      const pages = getChatContextPages();
      if (pages.length === 0) {
        chCtxSummary.textContent = 'No pages selected';
        chCtxSummary.classList.add('empty');
        return;
      }
      chCtxSummary.classList.remove('empty');
      if (pages.length === 1) {
        chCtxSummary.textContent = `Page ${pages[0]}`;
      } else if (pages.length <= 5) {
        chCtxSummary.textContent = `Pages ${pages.join(', ')}`;
      } else {
        chCtxSummary.textContent = `Pages ${pages[0]}–${pages[pages.length - 1]} (${pages.length} pages)`;
      }
    }

    // Mode button click handler
    chatShadow.querySelectorAll('.ch-ctx-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        chatShadow.querySelectorAll('.ch-ctx-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        chatContextMode = e.target.dataset.ctx;
        // Show/hide the range or custom input rows
        chRangeRow.style.display = (chatContextMode === 'range') ? 'flex' : 'none';
        chCustomRow.style.display = (chatContextMode === 'custom') ? 'flex' : 'none';
        updateContextSummary();
      });
    });

    // Update summary when range inputs change
    [chRangeFrom, chRangeTo].forEach(el => {
      el.addEventListener('input', updateContextSummary);
    });
    chCustomPages.addEventListener('input', updateContextSummary);

    // Update context when the main panel navigates to a new page
    // (currentPage changes — the summary should reflect the new page)
    const origGoToPage = window._origGoToPage;
    // We'll just poll currentPage for changes and update the summary
    let lastCtxPage = currentPage;
    setInterval(() => {
      if (currentPage !== lastCtxPage) {
        lastCtxPage = currentPage;
        updateContextSummary();
      }
    }, 300);

    // Tab Switching
    chatShadow.querySelectorAll('.ch-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        chatShadow.querySelectorAll('.ch-tab').forEach(t => t.classList.remove('active'));
        chatShadow.querySelectorAll('.ch-tab-content').forEach(c => c.style.display = 'none');
        
        e.target.classList.add('active');
        const targetMap = {
          'quiz': 'tabQuiz',
          'chat': 'tabChat',
          'purpose': 'tabPurpose'
        };
        const targetId = targetMap[e.target.dataset.tab];
        chatShadow.getElementById(targetId).style.display = 'flex';
        
        if (e.target.dataset.tab === 'quiz') renderQuizList();
        if (e.target.dataset.tab === 'purpose') loadPurpose();
      });
    });

    // Purpose UI
    chatShadow.getElementById('prGenerate').addEventListener('click', () => runPurposeGeneration());
    chatShadow.getElementById('prRefresh').addEventListener('click', () => runPurposeGeneration());

    // Quiz UI
    chatShadow.getElementById('qzBack').addEventListener('click', () => {
      chatShadow.getElementById('qzView').style.display = 'none';
      chatShadow.getElementById('qzList').style.display = 'flex';
      activeQuizChunk = null;
    });

    chatShadow.getElementById('qzSubmit').addEventListener('click', () => {
      if (activeQuizChunk === null) return;
      const q = generatedQuizzes[activeQuizChunk];
      
      if (!Array.isArray(q.questions)) return;

      const answers = [];
      let allAnswered = true;
      let score = 0;
      
      q.questions.forEach((question, index) => {
        const selected = chatShadow.querySelector(`input[name="q${index}"]:checked`);
        if (selected) {
          const uAns = question.options[parseInt(selected.value)];
          const isCorrect = uAns === question.answer;
          if (isCorrect) score++;
          answers.push({
            question: question.question,
            userAnswer: uAns,
            correctAnswer: question.answer,
            explanation: question.explanation,
            isCorrect: isCorrect
          });
        } else {
          allAnswered = false;
        }
      });

      if (!allAnswered) {
        alert("Please answer all questions before submitting.");
        return;
      }

      q.status = 'graded';
      
      let gradingHtml = `<h3 style="margin-bottom: 12px;">Score: ${score} / ${q.questions.length}</h3>`;
      answers.forEach((ans, i) => {
        const color = ans.isCorrect ? '#10b981' : '#ef4444';
        const icon = ans.isCorrect ? '✓' : '✗';
        gradingHtml += `
          <div style="margin-bottom: 12px; padding: 12px; border-radius: 8px; background: rgba(255,255,255,0.03); border-left: 3px solid ${color};">
            <div style="font-weight: 600; margin-bottom: 6px; font-size:14px;">${i + 1}. ${ans.question}</div>
            <div style="margin-bottom: 4px; font-size:13px;"><strong>Your Answer:</strong> <span style="color:${color}">${icon} ${ans.userAnswer}</span></div>
            ${!ans.isCorrect ? `<div style="margin-bottom: 4px; font-size:13px;"><strong>Correct Answer:</strong> ${ans.correctAnswer}</div>` : ''}
            <div style="font-size: 12px; color: #a1a1aa; margin-top: 8px; line-height: 1.5;"><em>Explanation:</em> ${ans.explanation}</div>
          </div>
        `;
      });
      q.grading = gradingHtml;
      
      openQuizView(activeQuizChunk);
      renderQuizList();
    });

    // Wire up — send on button click
    chatSendBtn.addEventListener('click', () => sendChatMessage());

    // Auto-resize textarea (triggered manually via dispatchEvent below)
    chatInputEl.addEventListener('input', () => {
      chatInputEl.style.height = 'auto';
      chatInputEl.style.height = Math.min(chatInputEl.scrollHeight, 200) + 'px';
    });

    // ── Manual keystroke handling ──────────────────────────────────────────
    // Chrome's built-in PDF viewer hooks window at capture phase BEFORE our
    // content script runs, so stopImmediatePropagation alone is too late.
    // Solution: intercept at window capture, fully preventDefault, then
    // manually write the character into the textarea (same trick used for
    // the page-number input above).
    window.addEventListener('keydown', (e) => {
      if (!chatShadow || chatShadow.activeElement !== chatInputEl) return;
      if (e.key === 'Tab') return;

      e.stopImmediatePropagation();
      e.preventDefault();

      const ta = chatInputEl;
      const s  = ta.selectionStart;
      const en = ta.selectionEnd;

      const insert = (ch) => {
        ta.value = ta.value.slice(0, s) + ch + ta.value.slice(en);
        ta.selectionStart = ta.selectionEnd = s + ch.length;
        ta.dispatchEvent(new Event('input'));
      };

      if (e.key === 'Enter' && !e.shiftKey) {
        sendChatMessage();
      } else if (e.key === 'Enter' && e.shiftKey) {
        insert('\n');
      } else if (e.key === 'Backspace') {
        if (s !== en) {
          ta.value = ta.value.slice(0, s) + ta.value.slice(en);
          ta.selectionStart = ta.selectionEnd = s;
        } else if (s > 0) {
          ta.value = ta.value.slice(0, s - 1) + ta.value.slice(s);
          ta.selectionStart = ta.selectionEnd = s - 1;
        }
        ta.dispatchEvent(new Event('input'));
      } else if (e.key === 'Delete') {
        if (s !== en) {
          ta.value = ta.value.slice(0, s) + ta.value.slice(en);
          ta.selectionStart = ta.selectionEnd = s;
        } else if (s < ta.value.length) {
          ta.value = ta.value.slice(0, s) + ta.value.slice(s + 1);
          ta.selectionStart = ta.selectionEnd = s;
        }
        ta.dispatchEvent(new Event('input'));
      } else if (e.key === 'ArrowLeft') {
        ta.selectionStart = ta.selectionEnd = Math.max(0, s - 1);
      } else if (e.key === 'ArrowRight') {
        ta.selectionStart = ta.selectionEnd = Math.min(ta.value.length, en + 1);
      } else if (e.key === 'Home') {
        ta.selectionStart = ta.selectionEnd = 0;
      } else if (e.key === 'End') {
        ta.selectionStart = ta.selectionEnd = ta.value.length;
      } else if (e.key === 'a' && (e.ctrlKey || e.metaKey)) {
        ta.selectionStart = 0;
        ta.selectionEnd   = ta.value.length;
      } else if (e.key === 'v' && (e.ctrlKey || e.metaKey)) {
        navigator.clipboard.readText().then(txt => {
          ta.value = ta.value.slice(0, s) + txt + ta.value.slice(en);
          ta.selectionStart = ta.selectionEnd = s + txt.length;
          ta.dispatchEvent(new Event('input'));
        }).catch(() => {});
      } else if (e.key === 'c' && (e.ctrlKey || e.metaKey)) {
        if (s !== en) navigator.clipboard.writeText(ta.value.slice(s, en)).catch(() => {});
      } else if (e.key === 'x' && (e.ctrlKey || e.metaKey)) {
        if (s !== en) {
          navigator.clipboard.writeText(ta.value.slice(s, en)).catch(() => {});
          ta.value = ta.value.slice(0, s) + ta.value.slice(en);
          ta.selectionStart = ta.selectionEnd = s;
          ta.dispatchEvent(new Event('input'));
        }
      } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        insert(e.key);
      }
    }, true);

    // Suppress keyup/keypress too so PDF viewer doesn't react
    ['keyup', 'keypress'].forEach(evtType => {
      window.addEventListener(evtType, (e) => {
        if (chatShadow && chatShadow.activeElement === chatInputEl) {
          e.stopImmediatePropagation();
          e.preventDefault();
        }
      }, true);
    });

    // Add a toggle button to the main summarizer header (wired after chatPanel exists)
    addChatToggleButton();
    addLeftBarToggleButton();

    // Resize sidebar
    makeSidebarResizable(chatShadow.getElementById('chResize'), chatPanel, 'right');
  }

  function addChatToggleButton() {
    const headerRight = shadow.querySelector('.pn-header-right');
    if (!headerRight) return;

    chatToggleBtn = document.createElement('button');
    chatToggleBtn.className = 'pn-icon-btn';
    chatToggleBtn.id = 'pnChatToggle';
    chatToggleBtn.title = chatVisible ? 'Close AI Chat' : 'Open AI Chat';
    chatToggleBtn.textContent = '?';
    chatToggleBtn.style.cssText = 'color:#818cf8;font-size:15px;';

    // Insert before first child (font dec button)
    headerRight.insertBefore(chatToggleBtn, headerRight.firstChild);

    chatToggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      chatVisible = !chatVisible;
      if (chatVisible) {
        chatPanel.classList.remove('ch-hidden');
        chatToggleBtn.title = 'Close AI Chat';
        chatInputEl.focus();
      } else {
        chatPanel.classList.add('ch-hidden');
        chatToggleBtn.title = 'Open AI Chat';
      }
    });
  }

  function addLeftBarToggleButton() {
    const headerLeft = shadow.querySelector('.pn-header-left');
    if (!headerLeft) return;

    lbToggleBtn = document.createElement('button');
    lbToggleBtn.className = 'pn-icon-btn';
    lbToggleBtn.id = 'pnLeftBarToggle';
    lbToggleBtn.title = lbVisible ? 'Hide Notes & Summaries' : 'Show Notes & Summaries';
    lbToggleBtn.textContent = '☰';
    lbToggleBtn.style.cssText = 'color:#10b981;font-size:15px;margin-right:4px;';

    // Insert as first child of header-left (before the opacity slider)
    headerLeft.insertBefore(lbToggleBtn, headerLeft.firstChild);

    lbToggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      lbVisible = !lbVisible;
      if (lbVisible) {
        lbPanel.classList.remove('lb-hidden');
        lbToggleBtn.title = 'Hide Notes & Summaries';
      } else {
        lbPanel.classList.add('lb-hidden');
        lbToggleBtn.title = 'Show Notes & Summaries';
      }
    });
  }

  // ===== LEFT BAR (NOTES & SUMMARIES) =====
  function createLeftBar(savedData = {}) {
    const lbHost = document.createElement('div');
    lbHost.id = 'pdf-leftbar-host';
    lbShadow = lbHost.attachShadow({ mode: 'closed' });

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('content.css');
    lbShadow.appendChild(link);

    lbPanel = document.createElement('div');
    lbPanel.className = lbVisible ? 'lb-panel' : 'lb-panel lb-hidden';
    if (savedData.lbWidth) lbPanel.style.width = savedData.lbWidth + 'px';
    lbPanel.innerHTML = `
      <div class="lb-header">
        <div class="lb-header-left">
          <div class="lb-logo">☰</div>
          <span class="lb-title">Notes & Summaries</span>
        </div>
        <button class="ch-icon-btn" id="lbClose">✕</button>
      </div>

      <div class="lb-tabs">
        <div class="lb-tab active" data-tab="notes">Notes</div>
        <div class="lb-tab" data-tab="relevance">Relevance</div>
      </div>

      <div class="lb-body">
        <!-- ===== TAB 1: NOTES (default) ===== -->
        <div class="lb-tab-content active" id="lbTabNotes">
          <!-- Range Summary Tool -->
          <div class="lb-section">
            <div class="lb-section-title">Summarize Pages (Range)</div>
            <div class="lb-input-group">
              <input type="number" class="lb-input" id="lbFrom" placeholder="From (1)" min="1">
              <span style="color:#a1a1aa; font-size: 11px;">to</span>
              <input type="number" class="lb-input" id="lbTo" placeholder="To (All)" min="1">
            </div>
            <button class="lb-btn" id="lbRangeGo" style="width: 100%; margin-top: 4px;">Generate Range Summary</button>
          </div>

          <!-- Concept Summary Tool -->
          <div class="lb-section">
            <div class="lb-section-title">Concept Summary (Whole Book)</div>
            <div class="lb-input-group">
              <input type="text" class="lb-input" id="lbConcept" placeholder="e.g. Photosynthesis, Market Trends...">
              <button class="lb-btn" id="lbConceptGo">Ask</button>
            </div>
          </div>

          <div class="lb-list" id="lbList">
            <div class="lb-empty">No summaries yet. Use the tools above to generate some.</div>
          </div>
        </div>

        <!-- ===== TAB 2: RELEVANCE CHECK ===== -->
        <div class="lb-tab-content" id="lbTabRelevance">
          <div class="lb-section">
            <div class="lb-section-title">What do you want to know?</div>
            <textarea class="lb-input lb-textarea" id="lbQuestion" placeholder="e.g. I want to know about the evolution of homo sapiens, or: how to stop procrastinating..." rows="1"></textarea>
            <button class="lb-btn" id="lbRelevanceGo" style="width: 100%; margin-top: 6px;">Check Relevance</button>
            <div class="lb-help">Before reading the book — get a verdict on whether it will actually answer your question. The whole book is summarized in 20-page isolated chunks, then analyzed against your question.</div>
          </div>

          <div class="lb-relevance-progress" id="lbRelevanceProgress" style="display:none;"></div>
          <div class="lb-relevance-result" id="lbRelevanceResult" style="display:none;"></div>
        </div>
      </div>
      <div class="lb-resize-handle" id="lbResize"></div>
    `;

    lbShadow.appendChild(lbPanel);
    document.documentElement.appendChild(lbHost);

    // Refs
    lbListEl      = lbShadow.getElementById('lbList');
    lbFromInput   = lbShadow.getElementById('lbFrom');
    lbToInput     = lbShadow.getElementById('lbTo');
    lbConceptInput = lbShadow.getElementById('lbConcept');
    lbQuestionInput = lbShadow.getElementById('lbQuestion');
    lbRelevanceBtn  = lbShadow.getElementById('lbRelevanceGo');
    lbRelevanceProgressEl = lbShadow.getElementById('lbRelevanceProgress');
    lbRelevanceResultEl   = lbShadow.getElementById('lbRelevanceResult');
    const rangeBtn = lbShadow.getElementById('lbRangeGo');
    const conceptBtn = lbShadow.getElementById('lbConceptGo');

    // Wire up
    lbShadow.getElementById('lbClose').addEventListener('click', () => {
      lbPanel.classList.add('lb-hidden');
      lbVisible = false;
    });

    rangeBtn.addEventListener('click', () => runRangeSummary());
    conceptBtn.addEventListener('click', () => runConceptSummary());
    lbRelevanceBtn.addEventListener('click', () => runRelevanceCheck());

    // Tab switching
    lbShadow.querySelectorAll('.lb-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        lbShadow.querySelectorAll('.lb-tab').forEach(t => t.classList.remove('active'));
        lbShadow.querySelectorAll('.lb-tab-content').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        const targetId = 'lbTab' + e.target.dataset.tab.charAt(0).toUpperCase() + e.target.dataset.tab.slice(1);
        const target = lbShadow.getElementById(targetId);
        if (target) target.classList.add('active');
      });
    });

    // Intercept keys for inputs
    [lbFromInput, lbToInput, lbConceptInput].forEach(el => {
      window.addEventListener('keydown', (e) => {
        if (!lbShadow || lbShadow.activeElement !== el) return;
        if (e.key === 'Tab') return;
        e.stopImmediatePropagation();
        e.preventDefault();

        const s = el.selectionStart;
        const en = el.selectionEnd;

        if (e.key === 'Enter') {
          if (el === lbConceptInput) runConceptSummary();
          else runRangeSummary();
          el.blur();
        } else if (e.key === 'Backspace') {
          document.execCommand('delete', false);
        } else if (e.key === 'Delete') {
          document.execCommand('forwardDelete', false);
        } else if (e.key === 'ArrowLeft') {
          const pos = Math.max(0, s - 1);
          el.setSelectionRange(pos, pos);
        } else if (e.key === 'ArrowRight') {
          const pos = Math.min(el.value.length, en + 1);
          el.setSelectionRange(pos, pos);
        } else if (e.key === 'Home') {
          el.setSelectionRange(0, 0);
        } else if (e.key === 'End') {
          const len = el.value.length;
          el.setSelectionRange(len, len);
        } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
          document.execCommand('insertText', false, e.key);
        }
      }, true);
    });

    // Auto-expanding textarea for the relevance question.
    // - Plain Enter inserts a newline (native textarea behavior — the question
    //   is often multi-line, so we don't want Enter to submit).
    // - Ctrl/Cmd+Enter submits.
    // - Height grows with content up to a max, then scrolls.
    const autoResizeQuestion = () => {
      lbQuestionInput.style.height = 'auto';
      lbQuestionInput.style.height = Math.min(lbQuestionInput.scrollHeight, 200) + 'px';
    };
    lbQuestionInput.addEventListener('input', autoResizeQuestion);
    // Stop the global a/d/arrows navigation handler from firing while typing
    lbQuestionInput.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        runRelevanceCheck();
      }
    });

    // Resize sidebar
    makeSidebarResizable(lbShadow.getElementById('lbResize'), lbPanel, 'left');
  }

  function applyPDFInversion() {
    const existing = document.getElementById('pdf-invert-style');
    if (existing) existing.remove();

    // Update button icon
    const btn = shadow?.getElementById('pnNightMode');
    if (btn) {
      btn.textContent = nightMode ? '☀' : '◑';
      btn.title = nightMode ? 'Switch to Light Mode' : 'Switch to Night Mode';
      btn.style.color = nightMode ? '#fbbf24' : '#71717a';
    }

    if (!nightMode) return;

    const style = document.createElement('style');
    style.id = 'pdf-invert-style';
    style.textContent = `
      html {
        background-color: #0a0a0a !important; /* Base background stays dark */
        margin: 0 !important;
        padding: 0 !important;
      }
      body {
        filter: invert(1) hue-rotate(180deg) brightness(1.05) !important;
        background-color: #fff !important; /* Inverts to black */
        margin: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        overflow: hidden !important; /* Prevent double scrollbars */
        display: block !important;
      }
      /* Ensure the PDF viewer fills the body */
      embed, iframe, object, [name="viewer"] {
        width: 100% !important;
        height: 100% !important;
        display: block !important;
      }
      
      /* Since our hosts are siblings of body, they are totally unaffected 
         by the body's filter and stacking context. No re-inversion needed! */
    `;
    document.documentElement.appendChild(style);
  }

  function makeSidebarResizable(handle, panel, side) {
    let rs = { active: false, sw: 0, sx: 0 };

    handle.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handle.setPointerCapture(e.pointerId);
      rs = { active: true, sw: panel.offsetWidth, sx: e.clientX };
      panel.classList.add('resizing');
    });

    handle.addEventListener('pointermove', (e) => {
      if (!rs.active) return;
      let dx = e.clientX - rs.sx;
      if (side === 'right') dx = -dx;
      panel.style.width = Math.max(300, Math.min(window.innerWidth * 0.7, rs.sw + dx)) + 'px';
    });

    handle.addEventListener('pointerup', (e) => {
      if (!rs.active) return;
      handle.releasePointerCapture(e.pointerId);
      rs.active = false;
      panel.classList.remove('resizing');
      
      // Save width
      const key = side === 'left' ? 'lbWidth' : 'chWidth';
      chrome.storage.local.set({ [key]: panel.offsetWidth });
    });

    handle.addEventListener('pointercancel', () => {
      rs.active = false;
      panel.classList.remove('resizing');
    });
  }

  async function runRangeSummary() {
    let from = parseInt(lbFromInput.value);
    let to = parseInt(lbToInput.value);

    // Default to whole PDF if inputs are empty
    if (isNaN(from) && lbFromInput.value.trim() === '') from = 1;
    if (isNaN(to) && lbToInput.value.trim() === '') to = totalPages || 9999;

    if (isNaN(from) || isNaN(to) || from < 1 || to < from || lbWaiting) return;

    // Cap to actual page count
    const cappedTo = totalPages ? Math.min(to, totalPages) : to;
    const numChunks = Math.ceil((cappedTo - from + 1) / 20);

    lbWaiting = true;
    const loadingMsg = numChunks > 1
      ? `<span class="pn-spinner"></span> Summarizing ${numChunks} chunks (20 pages each)… This may take a few minutes.`
      : '<span class="pn-spinner"></span> Summarizing...';
    const item = appendSummaryItem('Pages ' + from + '-' + cappedTo, loadingMsg);
    
    chrome.runtime.sendMessage({
      type: 'SUMMARIZE_RANGE',
      url: pdfUrl,
      startPage: from,
      endPage: cappedTo,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language
    }, (res) => {
      lbWaiting = false;
      if (chrome.runtime.lastError || !res || !res.success) {
        item.querySelector('.lb-item-content').textContent = '! Error: ' + (res?.error || 'Connection lost');
        return;
      }
      const contentEl = item.querySelector('.lb-item-content');
      contentEl.innerHTML = markdownToHTML(res.summary);
      contentEl.dataset.raw = res.summary;
    });
  }

  async function runConceptSummary() {
    const concept = lbConceptInput.value.trim();
    if (!concept || lbWaiting) return;

    lbWaiting = true;
    const item = appendSummaryItem('Concept: ' + concept, 'Analyzing book context...');
    lbConceptInput.value = '';

    chrome.runtime.sendMessage({
      type: 'SUMMARIZE_CONCEPT',
      url: pdfUrl,
      concept,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language
    }, (res) => {
      lbWaiting = false;
      if (chrome.runtime.lastError || !res || !res.success) {
        item.querySelector('.lb-item-content').textContent = '! Error: ' + (res?.error || 'Connection lost');
        return;
      }
      const contentEl = item.querySelector('.lb-item-content');
      contentEl.innerHTML = markdownToHTML(res.summary);
      contentEl.dataset.raw = res.summary;
      // Apply RTL for Arabic
      const isRTL = language === 'Arabic';
      contentEl.style.direction = isRTL ? 'rtl' : 'ltr';
      contentEl.style.textAlign = isRTL ? 'right' : 'left';
    });
  }

  // ===== RELEVANCE ANSWER RENDERER =====
  // Parses the AI's structured answer and wraps each section in a colored
  // container. The AI produces:
  //   **RELEVANCE: 85%**
  //   (clarifying line)
  //   **What the book is about (generally):**
  //   (2-3 sentences)
  //   **Will this book be useful for your aim?**
  //   (3-5 sentences, verdict starts with Yes / Partially / No)
  // We extract the percentage and verdict to drive the color coding.
  function renderRelevanceAnswer(rawAnswer) {
    // Escape the raw answer so we can safely process it
    const esc = rawAnswer
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Extract the percentage from the first **RELEVANCE: X%** line
    const pctMatch = rawAnswer.match(/\*?\*?\s*RELEVANCE:\s*(\d{1,3})\s*%\s*\*?\*?/i);
    const pct = pctMatch ? parseInt(pctMatch[1], 10) : null;

    // Determine the relevance color band:
    //   0-30%  → red (not relevant)
    //   31-60% → amber (partially relevant)
    //   61-100%→ green (relevant)
    let pctClass = 'lb-rel-pct-unknown';
    let pctEmoji = '';
    if (pct !== null) {
      if (pct <= 30) { pctClass = 'lb-rel-pct-low'; pctEmoji = ''; }
      else if (pct <= 60) { pctClass = 'lb-rel-pct-mid'; pctEmoji = '!'; }
      else { pctClass = 'lb-rel-pct-high'; pctEmoji = ''; }
    }

    // Split the answer into sections by the **bold headings**
    // We look for the three section markers.
    const sections = { relevance: null, about: null, useful: null };

    // Match: **RELEVANCE: X%** line + any following text until next ** heading
    const relevanceBlock = rawAnswer.match(/\*?\*?\s*RELEVANCE:\s*\d{1,3}\s*%\s*\*?\*?\s*\n([\s\S]*?)(?=\*?\*?\s*(?:What the book is about|Will this book))/i);
    if (relevanceBlock) {
      // The percentage line itself + the clarifying text after it
      const pctLine = pctMatch ? pctMatch[0] : '';
      const clarifying = relevanceBlock[1].trim();
      sections.relevance = { pctLine, clarifying };
    }

    // Match: **What the book is about (generally):** heading + body until next ** heading
    const aboutBlock = rawAnswer.match(/\*?\*?\s*What the book is about[^:*]*:\s*\*?\*?\s*\n([\s\S]*?)(?=\*?\*?\s*Will this book)/i);
    if (aboutBlock) {
      sections.about = aboutBlock[1].trim();
    }

    // Match: **Will this book be useful for your aim?** heading + body until end
    const usefulBlock = rawAnswer.match(/\*?\*?\s*Will this book be useful[^:*]*\??\s*\*?\*?\s*\n([\s\S]*?)$/i);
    if (usefulBlock) {
      sections.useful = usefulBlock[1].trim();
    }

    // Determine the verdict color from the "useful" section text
    let verdictClass = 'lb-rel-verdict-neutral';
    let verdictLabel = '';
    if (sections.useful) {
      const firstLine = sections.useful.split('\n')[0].toLowerCase();
      if (/\b(yes|will be useful|highly useful|definitely|strongly)\b/.test(firstLine)) {
        verdictClass = 'lb-rel-verdict-yes';
        verdictLabel = 'YES — USEFUL';
      } else if (/\b(partially|somewhat|in part|partly|mixed)\b/.test(firstLine)) {
        verdictClass = 'lb-rel-verdict-partial';
        verdictLabel = 'PARTIALLY USEFUL';
      } else if (/\b(no|not useful|won't|would not|not worth|not recommended)\b/.test(firstLine)) {
        verdictClass = 'lb-rel-verdict-no';
        verdictLabel = 'NOT USEFUL';
      }
    }

    // Build the HTML
    let html = '';

    // 1. Relevance percentage badge — big, colored
    if (sections.relevance) {
      html += `<div class="lb-rel-pct-badge ${pctClass}">`;
      html += `<div class="lb-rel-pct-number">${pctEmoji} ${pct !== null ? pct + '%' : '??'}</div>`;
      html += `<div class="lb-rel-pct-label">RELEVANCE TO YOUR QUESTION</div>`;
      html += `</div>`;
      if (sections.relevance.clarifying) {
        html += `<div class="lb-rel-pct-clarify">${inlineFormat(escapeHtml(sections.relevance.clarify))}</div>`;
      }
    }

    // 2. "What the book is about" — neutral card
    if (sections.about) {
      html += `<div class="lb-rel-section lb-rel-about">`;
      html += `<div class="lb-rel-section-title">PDF What the book is about</div>`;
      html += `<div class="lb-rel-section-body">${markdownToHTML(sections.about)}</div>`;
      html += `</div>`;
    }

    // 3. "Will this book be useful" — colored verdict card
    if (sections.useful) {
      html += `<div class="lb-rel-section lb-rel-useful ${verdictClass}">`;
      if (verdictLabel) {
        html += `<div class="lb-rel-verdict-label">${verdictLabel}</div>`;
      }
      html += `<div class="lb-rel-section-title">Will this book be useful for your aim?</div>`;
      html += `<div class="lb-rel-section-body">${markdownToHTML(sections.useful)}</div>`;
      html += `</div>`;
    }

    // Fallback: if parsing failed, just dump the rendered answer
    if (!html) {
      html = `<div class="lb-rel-answer-body">${markdownToHTML(rawAnswer)}</div>`;
    }

    return html;
  }

  function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // ===== RELEVANCE CHECK (pre-reading "is this book for me?" verdict) =====
  // Pipeline:
  //   1. Compute all 20-page chunks across the entire book.
  //   2. For each chunk, call RELEVANCE_SUMMARIZE_CHUNK (isolated context per
  //      chunk — no conversation history, so chunks don't bleed into each
  //      other and we stay well within the model's context limit).
  //   3. Once all chunk summaries are collected, call RELEVANCE_ANSWER with
  //      just the chunk summaries + the reader's question. The original page
  //      text is deliberately NOT sent on this final call — the summaries ARE
  //      the context now. This keeps even very long books within budget.
  //   4. Render the structured answer (percentage + general + specific +
  //      usefulness) in the Relevance tab.
  async function runRelevanceCheck() {
    const question = lbQuestionInput.value.trim();
    if (!question || lbRelevanceWaiting) return;
    if (!pdfReady || !totalPages) {
      lbRelevanceResultEl.style.display = 'block';
      lbRelevanceResultEl.innerHTML = '<div class="lb-relevance-error">! PDF is still loading. Please wait a moment.</div>';
      return;
    }

    lbRelevanceWaiting = true;
    lbRelevanceBtn.disabled = true;
    lbRelevanceBtn.textContent = 'Working…';
    lbQuestionInput.value = '';
    lbQuestionInput.style.height = 'auto';

    // Hide any previous result, show the progress panel
    lbRelevanceResultEl.style.display = 'none';
    lbRelevanceResultEl.innerHTML = '';
    lbRelevanceProgressEl.style.display = 'block';

    // Compute chunks (20 pages each, matching the rest of the extension)
    const CHUNK_SIZE = 20;
    const chunks = [];
    for (let from = 1; from <= totalPages; from += CHUNK_SIZE) {
      const to = Math.min(from + CHUNK_SIZE - 1, totalPages);
      chunks.push({ from, to });
    }

    const chunkSummaries = [];
    let failedChunk = null;

    // Render initial progress UI
    const renderProgress = (currentIdx, statusText) => {
      const pct = Math.round((currentIdx / chunks.length) * 100);
      const doneRows = chunkSummaries.map((s, i) =>
        `<div class="lb-rel-chunk-row done">✓ Chunk ${i + 1} (pages ${chunks[i].from}-${chunks[i].to})</div>`
      ).join('');
      const currentRow = currentIdx < chunks.length
        ? `<div class="lb-rel-chunk-row current"><span class="pn-spinner"></span> Chunk ${currentIdx + 1} (pages ${chunks[currentIdx].from}-${chunks[currentIdx].to}) — ${statusText}</div>`
        : '';
      const pendingRows = [];
      for (let i = currentIdx + 1; i < chunks.length; i++) {
        pendingRows.push(`<div class="lb-rel-chunk-row pending">Chunk ${i + 1} (pages ${chunks[i].from}-${chunks[i].to})</div>`);
      }
      lbRelevanceProgressEl.innerHTML = `
        <div class="lb-rel-question">Question: "${question}"</div>
        <div class="lb-rel-progress-bar">
          <div class="lb-rel-progress-fill" style="width: ${pct}%;"></div>
        </div>
        <div class="lb-rel-progress-text">${currentIdx} / ${chunks.length} chunks summarized · ${pct}%</div>
        <div class="lb-rel-chunk-list">
          ${doneRows}
          ${currentRow}
          ${pendingRows.join('')}
        </div>
      `;
    };

    renderProgress(0, 'Starting…');

    // Phase 1: summarize each chunk in isolation
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      renderProgress(i, 'Summarizing…');

      try {
        const res = await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            type: 'RELEVANCE_SUMMARIZE_CHUNK',
            url: pdfUrl,
            fromPage: chunk.from,
            toPage: chunk.to,
            ollamaUrl,
            model: ollamaModel,
            genre: bookGenre,
            language
          }, resolve);
        });

        if (chrome.runtime.lastError || !res || !res.success) {
          failedChunk = { idx: i, error: res?.error || chrome.runtime.lastError?.message || 'Connection lost' };
          break;
        }

        chunkSummaries.push({ from: chunk.from, to: chunk.to, summary: res.summary });
      } catch (err) {
        failedChunk = { idx: i, error: err.message };
        break;
      }
    }

    if (failedChunk) {
      lbRelevanceWaiting = false;
      lbRelevanceBtn.disabled = false;
      lbRelevanceBtn.textContent = 'Check';
      lbRelevanceProgressEl.innerHTML = `
        <div class="lb-rel-question">Question: "${question}"</div>
        <div class="lb-relevance-error">! Failed on chunk ${failedChunk.idx + 1} (pages ${chunks[failedChunk.idx].from}-${chunks[failedChunk.idx].to}): ${failedChunk.error}</div>
      `;
      return;
    }

    // Phase 2: ask the final relevance question with ALL chunk summaries as context
    renderProgress(chunks.length, 'Analyzing all summaries against your question…');

    try {
      const res = await new Promise((resolve) => {
        chrome.runtime.sendMessage({
          type: 'RELEVANCE_ANSWER',
          url: pdfUrl,
          question,
          chunkSummaries,
          ollamaUrl,
          model: ollamaModel,
          genre: bookGenre,
          language
        }, resolve);
      });

      lbRelevanceWaiting = false;
      lbRelevanceBtn.disabled = false;
      lbRelevanceBtn.textContent = 'Check';

      if (chrome.runtime.lastError || !res || !res.success) {
        lbRelevanceProgressEl.innerHTML = `
          <div class="lb-rel-question">Question: "${question}"</div>
          <div class="lb-relevance-error">! All chunks summarized, but the final analysis failed: ${res?.error || chrome.runtime.lastError?.message || 'Connection lost'}</div>
        `;
        return;
      }

      // Hide progress, show the final structured answer
      lbRelevanceProgressEl.style.display = 'none';
      lbRelevanceResultEl.style.display = 'block';
      // Store raw markdown for copy
      lbRelevanceResultEl.dataset.raw = res.answer;

      // Parse the structured answer to extract:
      //   1. The RELEVANCE percentage (for colored badge)
      //   2. The "Will this book be useful" verdict (Yes/Partially/No → colored box)
      //   3. The "What the book is about" section (neutral styling)
      // The answer format from the AI is:
      //   **RELEVANCE: 85%**
      //   (explanation line)
      //   **What the book is about (generally):**
      //   (2-3 sentences)
      //   **Will this book be useful for your aim?**
      //   (3-5 sentences with Yes/Partially/No verdict)
      const answerHtml = renderRelevanceAnswer(res.answer);

      lbRelevanceResultEl.innerHTML = `
        <div class="lb-rel-question-display">Your question: "${question}"</div>
        ${answerHtml}
        <button class="lb-copy-btn lb-rel-copy" title="Copy to clipboard">⧉</button>
      `;
      // Wire up copy
      const copyBtn = lbRelevanceResultEl.querySelector('.lb-rel-copy');
      copyBtn.addEventListener('click', () => {
        const textToCopy = lbRelevanceResultEl.dataset.raw || lbRelevanceResultEl.innerText;
        navigator.clipboard.writeText(textToCopy).then(() => {
          copyBtn.textContent = '✓ Copied';
          setTimeout(() => { copyBtn.textContent = '⧉'; }, 1500);
        }).catch(err => console.error('Copy failed', err));
      });
      // Apply RTL for Arabic
      const isRTL = language === 'Arabic';
      lbRelevanceResultEl.style.direction = isRTL ? 'rtl' : 'ltr';
      lbRelevanceResultEl.style.textAlign = isRTL ? 'right' : 'justify';
    } catch (err) {
      lbRelevanceWaiting = false;
      lbRelevanceBtn.disabled = false;
      lbRelevanceBtn.textContent = 'Check';
      lbRelevanceProgressEl.innerHTML = `
        <div class="lb-rel-question">Question: "${question}"</div>
        <div class="lb-relevance-error">! ${err.message}</div>
      `;
    }
  }

  function appendSummaryItem(tag, content) {
    const empty = lbListEl.querySelector('.lb-empty');
    if (empty) empty.remove();

    const item = document.createElement('div');
    item.className = 'lb-item';
    item.innerHTML = `
      <div class="lb-item-header">
        <span class="lb-item-tag">${tag}</span>
        <button class="lb-copy-btn" title="Copy to clipboard">⧉</button>
      </div>
      <div class="lb-item-content">${content}</div>
    `;

    const copyBtn = item.querySelector('.lb-copy-btn');
    copyBtn.addEventListener('click', () => {
      const contentEl = item.querySelector('.lb-item-content');
      // Use the raw markdown if available to preserve paragraph spacing correctly
      const textToCopy = contentEl.dataset.raw || contentEl.innerText;
      navigator.clipboard.writeText(textToCopy).then(() => {
        copyBtn.textContent = '✓';
        setTimeout(() => { copyBtn.textContent = '⧉'; }, 1500);
      }).catch(err => console.error('Copy failed', err));
    });

    lbListEl.insertBefore(item, lbListEl.firstChild);
    lbListEl.scrollTop = 0;
    return item;
  }

  async function sendChatMessage() {
    const text = chatInputEl.value.trim();
    if (!text || chatWaiting) return;

    if (!pdfReady) {
      appendChatMessage('assistant', '! PDF is still loading. Please wait a moment.');
      return;
    }

    // Add user message
    chatHistory.push({ role: 'user', content: text });
    appendChatMessage('user', text);
    chatInputEl.value = '';
    chatInputEl.style.height = 'auto';

    // Show thinking indicator
    chatWaiting = true;
    chatSendBtn.disabled = true;
    const thinkingEl = appendChatMessage('assistant', null, true);

    // ── 60-Page Chunking & Amalgamation: for "All" or "Range.." exceeding 60 pages ──
    let shouldUseChunking = false;
    let chunkStart = 1;
    let chunkEnd = totalPages;

    if (chatContextMode === 'all') {
      shouldUseChunking = true;
      chunkStart = 1;
      chunkEnd = totalPages;
    } else if (chatContextMode === 'range') {
      const from = Math.max(1, parseInt(chRangeFrom.value) || 1);
      const to = Math.min(totalPages, parseInt(chRangeTo.value) || totalPages);
      if ((to - from + 1) > 60) {
        shouldUseChunking = true;
        chunkStart = from;
        chunkEnd = to;
      }
    }

    if (shouldUseChunking) {
      const CHUNK_SIZE = 60;
      const chunks = [];
      for (let from = chunkStart; from <= chunkEnd; from += CHUNK_SIZE) {
        const to = Math.min(from + CHUNK_SIZE - 1, chunkEnd);
        chunks.push({ from, to });
      }

      const updateThinkingStatus = (statusMsg) => {
        if (thinkingEl) {
          thinkingEl.innerHTML = `<span class="ch-thinking"><span></span><span></span><span></span></span> <span style="font-size: 11.5px; color: #a1a1aa; margin-left: 6px;">${statusMsg}</span>`;
        }
      };

      const chunkAnswers = [];
      let failedError = null;

      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        updateThinkingStatus(`Analyzing pages ${chunk.from}–${chunk.to} (chunk ${i + 1}/${chunks.length})…`);

        try {
          const res = await new Promise((resolve) => {
            chrome.runtime.sendMessage({
              type: 'CHAT_CHUNK_QUESTION',
              url: pdfUrl,
              fromPage: chunk.from,
              toPage: chunk.to,
              question: text,
              ollamaUrl,
              model: ollamaModel,
              genre: bookGenre,
              language
            }, resolve);
          });

          if (chrome.runtime.lastError || !res || !res.success) {
            failedError = (res && res.error) || chrome.runtime.lastError?.message || 'Connection lost.';
            break;
          }

          chunkAnswers.push({ from: chunk.from, to: chunk.to, answer: res.answer });
        } catch (err) {
          failedError = err.message;
          break;
        }
      }

      if (failedError) {
        chatWaiting = false;
        chatSendBtn.disabled = false;
        thinkingEl.remove();
        appendChatMessage('assistant', '! ' + failedError);
        chatHistory.push({ role: 'assistant', content: '! ' + failedError });
        return;
      }

      updateThinkingStatus(`Synthesizing final answer from all ${chunks.length} chunk${chunks.length > 1 ? 's' : ''}…`);

      try {
        const res = await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            type: 'CHAT_AMALGAMATE_ANSWERS',
            url: pdfUrl,
            question: text,
            chunkAnswers,
            ollamaUrl,
            model: ollamaModel,
            genre: bookGenre,
            language
          }, resolve);
        });

        chatWaiting = false;
        chatSendBtn.disabled = false;
        thinkingEl.remove();

        if (chrome.runtime.lastError || !res || !res.success) {
          const err = (res && res.error) || chrome.runtime.lastError?.message || 'Connection lost.';
          appendChatMessage('assistant', '! ' + err);
          chatHistory.push({ role: 'assistant', content: '! ' + err });
          return;
        }

        appendChatMessage('assistant', res.reply);
        chatHistory.push({ role: 'assistant', content: res.reply });
      } catch (err) {
        chatWaiting = false;
        chatSendBtn.disabled = false;
        thinkingEl.remove();
        appendChatMessage('assistant', '! ' + err.message);
        chatHistory.push({ role: 'assistant', content: '! ' + err.message });
      }
      return;
    }

    // Get the selected context pages
    const contextPages = getChatContextPages();

    // Send to background
    chrome.runtime.sendMessage({
      type: 'CHAT_PDF',
      url: pdfUrl,
      history: chatHistory,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language,
      pages: contextPages
    }, (res) => {
      chatWaiting = false;
      chatSendBtn.disabled = false;
      thinkingEl.remove();

      if (chrome.runtime.lastError || !res || !res.success) {
        const err = (res && res.error) || 'Connection lost.';
        appendChatMessage('assistant', '! ' + err);
        chatHistory.push({ role: 'assistant', content: '! ' + err });
        return;
      }

      appendChatMessage('assistant', res.reply);
      chatHistory.push({ role: 'assistant', content: res.reply });
    });
  }

  function appendChatMessage(role, text, isThinking = false) {
    // Remove welcome message on first real message
    const welcome = chatMessagesEl.querySelector('.ch-welcome');
    if (welcome) welcome.remove();

    const bubble = document.createElement('div');
    bubble.className = `ch-bubble ch-bubble-${role}`;

    // Apply RTL for Arabic
    const isRTL = language === 'Arabic';
    bubble.style.direction = isRTL ? 'rtl' : 'ltr';
    bubble.style.textAlign = isRTL ? 'right' : (role === 'assistant' ? 'justify' : 'left');

    if (isThinking) {
      bubble.innerHTML = '<span class="ch-thinking"><span></span><span></span><span></span></span>';
    } else {
      bubble.innerHTML = markdownToHTML(text);

      const copyBtn = document.createElement('button');
      copyBtn.className = 'ch-copy-btn';
      copyBtn.title = 'Copy message';
      copyBtn.textContent = '⧉';
      copyBtn.addEventListener('click', () => {
        // Use the raw text passed into the function to preserve original formatting
        navigator.clipboard.writeText(text).then(() => {
          copyBtn.textContent = '✓';
          setTimeout(() => { copyBtn.textContent = '⧉'; }, 1500);
        }).catch(err => console.error('Copy failed', err));
      });
      bubble.appendChild(copyBtn);
    }

    chatMessagesEl.appendChild(bubble);
    chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
    return bubble;
  }

  // ===== LIGHTWEIGHT MARKDOWN RENDERER =====
  // ===== LATEX SANITIZER =====
  // Strips LaTeX math notation from AI output before rendering.
  // Some models (especially when writing about frameworks, processes, or
  // progressions) default to LaTeX arrow notation ($\to$, $\rightarrow$)
  // instead of plain text. This function converts known LaTeX commands to
  // their Unicode equivalents and strips any remaining dollar signs.
  // This is a BELT-AND-SUSPENDERS fix — the prompt also bans LaTeX, but
  // models don't always obey. This sanitizer catches whatever slips through.
  function sanitizeLatex(text) {
    if (!text || typeof text !== 'string') return text;

    let result = text;

    // Step 1: Replace known $\command$ patterns with Unicode equivalents
    const latexMap = {
      '\\to': '→', '\\rightarrow': '→', '\\Rightarrow': '⇒',
      '\\leftarrow': '←', '\\Leftarrow': '⇐',
      '\\leftrightarrow': '↔', '\\Leftrightarrow': '⇔',
      '\\mapsto': '↦',
      '\\leq': '≤', '\\geq': '≥', '\\neq': '≠', '\\ne': '≠',
      '\\approx': '≈', '\\equiv': '≡', '\\sim': '∼', '\\propto': '∝',
      '\\in': '∈', '\\notin': '∉', '\\not\\in': '∉',
      '\\subset': '⊂', '\\supset': '⊃', '\\subseteq': '⊆', '\\supseteq': '⊇',
      '\\cup': '∪', '\\cap': '∩', '\\emptyset': '∅', '\\varnothing': '∅',
      '\\times': '×', '\\div': '÷', '\\pm': '±', '\\mp': '∓',
      '\\cdot': '·', '\\ldots': '…', '\\cdots': '⋯', '\\dots': '…',
      '\\sum': '∑', '\\prod': '∏', '\\int': '∫', '\\oint': '∮',
      '\\infty': '∞', '\\partial': '∂', '\\nabla': '∇',
      '\\forall': '∀', '\\exists': '∃', '\\neg': '¬',
      '\\alpha': 'α', '\\beta': 'β', '\\gamma': 'γ', '\\delta': 'δ',
      '\\epsilon': 'ε', '\\varepsilon': 'ε', '\\theta': 'θ', '\\vartheta': 'ϑ',
      '\\lambda': 'λ', '\\mu': 'μ', '\\nu': 'ν', '\\xi': 'ξ',
      '\\pi': 'π', '\\rho': 'ρ', '\\sigma': 'σ', '\\tau': 'τ',
      '\\phi': 'φ', '\\chi': 'χ', '\\psi': 'ψ', '\\omega': 'ω',
      '\\Delta': 'Δ', '\\Gamma': 'Γ', '\\Sigma': 'Σ', '\\Omega': 'Ω',
      '\\Phi': 'Φ', '\\Psi': 'Ψ', '\\Theta': 'Θ', '\\Lambda': 'Λ',
    };

    for (const [cmd, unicode] of Object.entries(latexMap)) {
      // Match $\command$ (with word boundary after command)
      const escaped = cmd.replace(/\\/g, '\\\\');
      result = result.replace(new RegExp('\\$' + escaped + '\\$', 'g'), unicode);
    }

    // Step 2: Handle fractions $\frac{X}{Y}$ → X/Y
    result = result.replace(/\$\\frac\{([^}]+)\}\{([^}]+)\}\$/g, '$1/$2');

    // Step 3: Handle square roots $\sqrt{X}$ → √X
    result = result.replace(/\$\\sqrt\{([^}]+)\}\$/g, '√$1');

    // Step 4: Handle superscripts $X^{2}$ → X², $X^{3}$ → X³
    result = result.replace(/\$\s*([^$]+?)\s*\^\{2\}\s*\$/g, '$1²');
    result = result.replace(/\$\s*([^$]+?)\s*\^\{3\}\s*\$/g, '$1³');

    // Step 5: Handle bare LaTeX commands (without dollar signs) as fallback
    // This catches cases where the model wrote \to without $ wrappers
    for (const [cmd, unicode] of Object.entries(latexMap)) {
      const escaped = cmd.replace(/\\/g, '\\\\');
      result = result.replace(new RegExp(escaped + '(?![a-zA-Z])', 'g'), unicode);
    }

    // Step 6: Handle bare \frac{X}{Y} and \sqrt{X} (without dollar signs)
    result = result.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1/$2');
    result = result.replace(/\\sqrt\{([^}]+)\}/g, '√$1');

    // Step 7: Handle bare superscripts X^{2} → X²
    result = result.replace(/\^\{2\}/g, '²');
    result = result.replace(/\^\{3\}/g, '³');

    // Step 8: Strip any remaining $\...$ patterns (unrecognized LaTeX commands)
    // Remove the dollar signs and leave the bare command (better than showing garbage)
    result = result.replace(/\$\\[a-zA-Z]+\$/g, '');

    // Step 9: Strip leftover double dollar signs ($$)
    result = result.replace(/\$\$/g, '');

    return result;
  }

  function sanitizeTypography(s) {
    if (!s) return '';
    return s
      .replace(/[\u00A0\u1680\u2000-\u200B\u202F\u205F\u3000\uFEFF]/g, ' ')
      .replace(/[\u2010\u2011\u2012]/g, '-')
      .replace(/[ \t\f\v]+/g, ' ');
  }

  function markdownToHTML(md) {
    if (!md) return '';
    // Clean non-breaking thin spaces, non-breaking hyphens, and irregular Unicode spacing
    md = sanitizeTypography(md);

    // Sanitize LaTeX notation BEFORE any processing
    md = sanitizeLatex(md);

    // For Non-Fiction (With Headers), use the full marked.js library
    // (same approach as the wiki-summarizer-extension) to get proper
    // rich-text rendering with real h1-h6 headers, bold, lists, etc.
    if (bookGenre === 'nonfiction_headers' && typeof marked !== 'undefined') {
      let formatted = marked.parse(md);
      return `<div class="wiki-markdown-content">${formatted}</div>`;
    }

    // Escape raw HTML first to prevent injection
    const esc = md
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    const lines = esc.split('\n');
    const out = [];
    let inCode = false;
    let inUL = false;
    let inOL = false;
    let inNarrativeBlock = false;
    let inMeaningBlock = false;
    // Accumulate consecutive non-blank lines into a single <p> so the summary
    // reads as dense flowing text, not a stack of widely-spaced single-line
    // paragraphs. Blank lines act as paragraph separators (no extra <br>).
    let pendingParagraph = [];

    const flushParagraph = () => {
      if (pendingParagraph.length > 0) {
        out.push(`<p>${inlineFormat(pendingParagraph.join(' '))}</p>`);
        pendingParagraph = [];
      }
    };

    const closeList = () => {
      if (inUL) { out.push('</ul>'); inUL = false; }
      if (inOL) { out.push('</ol>'); inOL = false; }
    };

    const closeSectionBlocks = () => {
      flushParagraph();
      closeList();
      if (inNarrativeBlock) { out.push('</div></div>'); inNarrativeBlock = false; }
      if (inMeaningBlock) { out.push('</div></div>'); inMeaningBlock = false; }
    };

    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      let trimmed = line.trim();

      // Fenced code block toggle
      if (trimmed.startsWith('```')) {
        if (inCode) {
          out.push('</code></pre>');
          inCode = false;
        } else {
          closeSectionBlocks();
          out.push('<pre><code>');
          inCode = true;
        }
        continue;
      }
      if (inCode) { out.push(line + '\n'); continue; }

      // Detect Narrative sections
      // Matches "**NARRATIVE**:", "NARRATIVE:", "1. NARRATIVE (50%):", "1. NARRATIVE:", etc.
      if (/^(?:\d+\.\s+)?\*\*(?:NARRATIVE|NARRATION)\*\*|^(?:NARRATIVE|NARRATION):/i.test(trimmed)) {
        closeSectionBlocks();
        out.push('<div class="pn-summary-block narrative-block">');
        out.push('<div class="pn-block-header"><span class="pn-block-icon">N</span> Narrative</div>');
        out.push('<div class="pn-block-content">');
        inNarrativeBlock = true;

        let content = trimmed.replace(/^(?:\d+\.\s+)?\*\*(?:NARRATIVE|NARRATION)\*\*:\s*|^(?:NARRATIVE|NARRATION):\s*/i, '');
        if (content.trim()) {
          pendingParagraph.push(content);
        }
        continue;
      }

      // Detect Meaning & Reflection / Philosophical sections
      // Matches "**MEANING & REFLECTION**:", "MEANING & REFLECTION:", "2. MEANING & REFLECTION (50%):", etc.
      if (/^(?:\d+\.\s+)?\*\*(?:MEANING|PHILOSOPHICAL|REFLECTION)/i.test(trimmed) || /^(?:MEANING & REFLECTION|PHILOSOPHICAL LAYER):/i.test(trimmed)) {
        closeSectionBlocks();
        out.push('<div class="pn-summary-block meaning-block">');
        out.push('<div class="pn-block-header"><span class="pn-block-icon">M</span> Meaning &amp; Reflection</div>');
        out.push('<div class="pn-block-content">');
        inMeaningBlock = true;

        let content = trimmed.replace(/^(?:\d+\.\s+)?\*\*(?:MEANING & REFLECTION|MEANING|PHILOSOPHICAL|REFLECTION|PHILOSOPHICAL LAYER)\*\*:\s*|^(?:MEANING & REFLECTION|PHILOSOPHICAL LAYER):\s*/i, '');
        if (content.trim()) {
          pendingParagraph.push(content);
        }
        continue;
      }

      // Headings — support # (h1) through ###### (h6)
      if (/^#{1,6}\s+/.test(trimmed)) {
        flushParagraph();
        closeList();
        const lvl = trimmed.match(/^(#+)/)[1].length;
        // Map markdown # → h3, ## → h4, ### → h5, #### → h6, ##### → h6, ###### → h6
        // (keep within h3-h6 to fit the panel — h1/h2 are too big)
        const tag = `h${Math.min(lvl + 2, 6)}`;
        out.push(`<${tag}>${inlineFormat(trimmed.replace(/^#+\s+/, ''))}</${tag}>`);
        continue;
      }

      // Unordered bullets: *, -, •, or leading spaces + those
      if (/^\s*[-*•]\s+/.test(line)) {
        flushParagraph();
        if (!inUL) { closeList(); out.push('<ul>'); inUL = true; }
        out.push(`<li>${inlineFormat(line.replace(/^\s*[-*•]\s+/, ''))}</li>`);
        continue;
      }

      // Ordered list
      if (/^\s*\d+\.\s+/.test(line)) {
        flushParagraph();
        if (!inOL) { closeList(); out.push('<ol>'); inOL = true; }
        out.push(`<li>${inlineFormat(line.replace(/^\s*\d+\.\s+/, ''))}</li>`);
        continue;
      }

      // Markdown table: a line starting with | followed by a separator row
      // (| :--- | :--- |). The separator must contain at least one - between
      // each pair of |. This detects the table header + separator, then
      // consumes all subsequent |-delimited rows.
      if (/^\s*\|/.test(line) && i + 1 < lines.length &&
          /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1]) && /-/.test(lines[i + 1])) {
        flushParagraph();
        closeList();

        // Parse header cells
        const headerCells = trimmed.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(c => c.trim());

        // Parse alignment from separator row
        const sepCells = lines[i + 1].trim().replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(c => c.trim());
        const alignments = sepCells.map(s => {
          if (s.startsWith(':') && s.endsWith(':')) return 'center';
          if (s.endsWith(':')) return 'right';
          return 'left';
        });

        // Skip header and separator lines
        i += 2;

        // Build table HTML
        let tableHtml = '<div class="md-table-wrap"><table class="md-table"><thead><tr>';
        headerCells.forEach((cell, idx) => {
          tableHtml += `<th style="text-align:${alignments[idx] || 'left'}">${inlineFormat(cell)}</th>`;
        });
        tableHtml += '</tr></thead><tbody>';

        // Parse data rows
        while (i < lines.length) {
          const dataLine = lines[i];
          const dataTrimmed = dataLine.trim();
          if (!dataTrimmed.startsWith('|')) break;
          const cells = dataTrimmed.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(c => c.trim());
          tableHtml += '<tr>';
          cells.forEach((cell, idx) => {
            tableHtml += `<td style="text-align:${alignments[idx] || 'left'}">${inlineFormat(cell)}</td>`;
          });
          tableHtml += '</tr>';
          i++;
        }
        // Back up one so the main loop's i++ doesn't skip the next non-table line
        i--;

        tableHtml += '</tbody></table></div>';
        out.push(tableHtml);
        continue;
      }

      // Blank line — paragraph separator (flush accumulated lines, no <br>)
      if (trimmed === '') {
        flushParagraph();
        continue;
      }

      // Regular line — if we're inside a list, CLOSE IT first.
      // This prevents <p> tags from being generated inside <ul>/<ol> (which
      // is invalid HTML and causes browsers to render the text at unpredictable
      // sizes — the root cause of the "tiny text" bug). Closing the list here
      // means explanation text after a bullet becomes a proper sibling <p>,
      // and if the next line is another bullet, a new <ul>/<ol> opens.
      if (inUL || inOL) {
        flushParagraph();
        closeList();
      }
      pendingParagraph.push(trimmed);
    }

    closeSectionBlocks();
    if (inCode) out.push('</code></pre>');

    return out.join('');
  }

  function inlineFormat(s) {
    return s
      // Bold+italic ***text***
      .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
      // Bold **text** or __text__
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/__(.+?)__/g, '<strong>$1</strong>')
      // Italic *text* or _text_
      .replace(/\*([^*\n]+?)\*/g, '<em>$1</em>')
      .replace(/_([^_\n]+?)_/g, '<em>$1</em>')
      // Inline code `text`
      .replace(/`([^`]+?)`/g, '<code>$1</code>');
  }

  // ===== PARSE PDF =====
  function parsePDF() {
    chrome.runtime.sendMessage({ type: 'PARSE_PDF', url: pdfUrl }, (res) => {
      if (chrome.runtime.lastError) {
        showSummaryError('Extension error. Try reloading the page.');
        return;
      }
      if (!res || !res.success) {
        showSummaryError(res?.error || 'Failed to parse PDF.');
        return;
      }
      totalPages = res.pageCount;
      pageTotalEl.textContent = `/ ${totalPages}`;
      pageInput.max = totalPages;
      // Show the initial page as a range
      const endPage = Math.min(currentPage + contextCount - 1, totalPages);
      pageInput.value = (endPage > currentPage) ? currentPage + '-' + endPage : currentPage;
      pdfReady = true;
      updateProgressBar();
      pushRemoteState(true);
      
      // Initialize quizzes
      const numChunks = Math.ceil(totalPages / 20);
      for (let i = 0; i < numChunks; i++) {
        generatedQuizzes[i] = { status: 'not_generated' };
      }
      renderQuizList();
      
      // Show idle state — user must press Start or Continue
      summaryTextEl.className = 'pn-summary-text idle';
      if (savedPdfPosition && savedPdfPosition.page && positionEnabled) {
        updateStartButtonUI(true, savedPdfPosition.page);
      } else {
        updateStartButtonUI(false);
      }
    });
  }

  // ===== RECAP POPUP =====
  // When recapMode is ON and the user navigates to a new page, this takes
  // the summary of the page(s) they just LEFT, sends it to the AI to be
  // condensed into a 3-4 sentence paragraph, and displays it in a popup
  // overlay on top of the main panel.
  //
  // PRE-GENERATION: To avoid waiting when navigating, recaps are generated
  // in the background AS SOON AS a summary is ready (see summarizePage
  // callback). The recap is cached in recapCache[pageNum] and displayed
  // instantly when the user navigates away from that page.
  let recapPopupEl = null;
  let recapCache = {}; // pageNum -> condensed recap text (pre-generated)
  let recapInFlight = new Map(); // summaryText -> Promise<{success, recap, error}>

  function cacheRecapForSummary(summaryText, recapText) {
    if (!summaryText || !recapText) return;
    for (let p = 1; p <= totalPages; p++) {
      if (summaries[p] === summaryText) {
        recapCache[p] = recapText;
      }
    }
  }

  function fetchRecap(summaryText) {
    if (!summaryText || !summaryText.trim()) {
      return Promise.resolve({ success: false, error: 'No summary to recap.' });
    }
    if (recapInFlight.has(summaryText)) {
      return recapInFlight.get(summaryText);
    }

    const p = new Promise((resolve) => {
      chrome.runtime.sendMessage({
        type: 'RECAP_GENERATE',
        summary: summaryText,
        ollamaUrl,
        model: ollamaModel,
        language
      }, (res) => {
        recapInFlight.delete(summaryText);
        if (chrome.runtime.lastError || !res || !res.success) {
          const err = res?.error || chrome.runtime.lastError?.message || 'Connection lost';
          console.log('[Recap] Generation failed:', err);
          resolve({ success: false, error: err });
          return;
        }
        cacheRecapForSummary(summaryText, res.recap);
        pushRemoteState(true);
        resolve({ success: true, recap: res.recap });
      });
    });

    recapInFlight.set(summaryText, p);
    return p;
  }

  function showRecapPopup(previousPageNum) {
    if (!recapMode || !pdfReady) return;

    // Get the summary for the page we just left
    const prevSummary = summaries[previousPageNum];
    if (!prevSummary || !prevSummary.trim()) {
      console.log('[Recap] No summary for page', previousPageNum, '— skipping');
      return;
    }

    // Compute the page range for the title:
    // - If contextCount is 1 → "Page X"
    // - If contextCount > 1 → "Pages X-Y" (the full context range)
    const rangeStart = previousPageNum;
    const rangeEnd = Math.min(previousPageNum + contextCount - 1, totalPages);
    const titleText = (contextCount === 1)
      ? `Page ${previousPageNum}`
      : `Pages ${rangeStart}–${rangeEnd}`;

    console.log('[Recap] Showing recap popup for', titleText, '(cached:', !!recapCache[previousPageNum], ')');

    // Dismiss any existing recap popup first
    dismissRecapPopup();

    // Create the popup
    const popup = document.createElement('div');
    popup.className = 'pn-recap-popup';
    popup.innerHTML = `
      <div class="pn-recap-header" id="pnRecapHeader">
        <span class="pn-recap-title">Recap — ${titleText}</span>
        <div class="pn-recap-controls">
          <button class="pn-recap-font-btn" id="pnRecapFontDec" title="Decrease font size">A-</button>
          <button class="pn-recap-font-btn" id="pnRecapFontInc" title="Increase font size">A+</button>
          <button class="pn-recap-close" title="Close">✕</button>
        </div>
      </div>
      <div class="pn-recap-body" id="pnRecapBody">
        <span class="pn-spinner"></span> Condensing summary…
      </div>
      <div class="pn-recap-resize-handle bottom-right" data-dir="br"></div>
      <div class="pn-recap-resize-handle right" data-dir="r"></div>
      <div class="pn-recap-resize-handle bottom" data-dir="b"></div>
    `;

    // Apply persisted bounds (position + size) BEFORE appending to the DOM.
    // If we append first, the CSS animation starts at the centered position
    // (top:50%; left:50%; transform:translate(-50%,-50%)) and the popup
    // visibly "jumps" to the saved position when we set left/top afterward.
    // By applying inline styles first, the popup is born at the correct
    // position and never flashes in the wrong spot.
    if (recapPopupBounds) {
      popup.style.left = recapPopupBounds.left + 'px';
      popup.style.top = recapPopupBounds.top + 'px';
      popup.style.width = recapPopupBounds.width + 'px';
      popup.style.height = recapPopupBounds.height + 'px';
      // Override the centered transform
      popup.style.transform = 'none';
      // Disable the entrance animation — it would override our transform
      // and cause the popup to flash at the centered position before
      // snapping to the saved position.
      popup.style.animation = 'none';
    }

    // Append to the PANEL element so it's inside the Shadow DOM
    panel.appendChild(popup);
    recapPopupEl = popup;

    // Apply persisted font size
    const bodyEl = popup.querySelector('#pnRecapBody');
    if (bodyEl) bodyEl.style.fontSize = recapFontSize + 'px';

    // Wire up close button
    popup.querySelector('.pn-recap-close').addEventListener('click', () => {
      dismissRecapPopup();
    });

    // Wire up font size buttons
    popup.querySelector('#pnRecapFontDec').addEventListener('click', (e) => {
      e.stopPropagation();
      recapFontSize = Math.max(10, recapFontSize - 1);
      const b = popup.querySelector('#pnRecapBody');
      if (b) b.style.fontSize = recapFontSize + 'px';
      chrome.storage.local.set({ recapFontSize });
    });
    popup.querySelector('#pnRecapFontInc').addEventListener('click', (e) => {
      e.stopPropagation();
      recapFontSize = Math.min(24, recapFontSize + 1);
      const b = popup.querySelector('#pnRecapBody');
      if (b) b.style.fontSize = recapFontSize + 'px';
      chrome.storage.local.set({ recapFontSize });
    });

    // Make the popup draggable by its header
    makeRecapDraggable(popup.querySelector('#pnRecapHeader'), popup);

    // Make the popup resizable via its handles
    makeRecapResizable(popup);

    // If the recap is already cached (pre-generated), display it instantly.
    if (recapCache[previousPageNum]) {
      bodyEl.innerHTML = markdownToHTML(recapCache[previousPageNum]);
    } else {
      fetchRecap(prevSummary).then((res) => {
        if (!res || !res.success) {
          if (bodyEl) bodyEl.textContent = '! Could not generate recap: ' + (res?.error || 'Connection lost');
          return;
        }
        if (bodyEl && recapPopupEl) {
          bodyEl.innerHTML = markdownToHTML(res.recap);
        }
      });
    }
  }

  // Save recap popup position/size to storage.
  // Uses offsetLeft/offsetTop (panel-relative) so the saved position is
  // relative to the panel — matching the CSS positioning context. If we
  // saved viewport coords (getBoundingClientRect), restoring them as
  // left/top would place the popup in the wrong spot.
  function saveRecapBounds() {
    if (!recapPopupEl) return;
    recapPopupBounds = {
      left: recapPopupEl.offsetLeft,
      top: recapPopupEl.offsetTop,
      width: recapPopupEl.offsetWidth,
      height: recapPopupEl.offsetHeight
    };
    chrome.storage.local.set({ recapPopupBounds });
  }

  // Drag handler for the recap popup.
  // CRITICAL: The popup is position:absolute inside the panel (position:fixed).
  // We must use offsetLeft/offsetTop (relative to the panel) — NOT
  // getBoundingClientRect() (viewport coordinates) — otherwise the popup
  // jumps when dragging starts, because viewport coords ≠ panel-relative coords.
  function makeRecapDraggable(handle, element) {
    let ds = { active: false, sx: 0, sy: 0, sl: 0, st: 0 };

    handle.addEventListener('pointerdown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      e.preventDefault();
      e.stopPropagation();
      handle.setPointerCapture(e.pointerId);
      // Use offsetLeft/offsetTop — these are relative to the offset parent
      // (the panel), which matches the CSS positioning context.
      // Switch from centered transform to explicit positioning.
      element.style.transform = 'none';
      // Read the CURRENT position via offsetLeft/offsetTop BEFORE setting
      // explicit left/top (which would override the transform-based centering).
      const startLeft = element.offsetLeft;
      const startTop = element.offsetTop;
      element.style.left = startLeft + 'px';
      element.style.top = startTop + 'px';
      ds = { active: true, sx: e.clientX, sy: e.clientY, sl: startLeft, st: startTop };
    });

    handle.addEventListener('pointermove', (e) => {
      if (!ds.active) return;
      element.style.left = (ds.sl + e.clientX - ds.sx) + 'px';
      element.style.top = (ds.st + e.clientY - ds.sy) + 'px';
    });

    handle.addEventListener('pointerup', (e) => {
      if (!ds.active) return;
      handle.releasePointerCapture(e.pointerId);
      ds.active = false;
      saveRecapBounds();
    });

    handle.addEventListener('pointercancel', () => {
      ds.active = false;
    });
  }

  // Resize handler for the recap popup.
  // Uses offsetLeft/offsetTop (panel-relative) not getBoundingClientRect()
  // (viewport-relative) — same fix as the drag handler.
  function makeRecapResizable(popup) {
    const handles = popup.querySelectorAll('.pn-recap-resize-handle');
    handles.forEach(handle => {
      let rs = { active: false };

      handle.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        handle.setPointerCapture(e.pointerId);
        popup.style.transform = 'none';
        // Use offsetLeft/offsetTop (panel-relative) to avoid the jump
        const startLeft = popup.offsetLeft;
        const startTop = popup.offsetTop;
        popup.style.left = startLeft + 'px';
        popup.style.top = startTop + 'px';
        rs = {
          active: true,
          dir: handle.dataset.dir,
          sx: e.clientX, sy: e.clientY,
          sw: popup.offsetWidth, sh: popup.offsetHeight,
        };
      });

      handle.addEventListener('pointermove', (e) => {
        if (!rs.active) return;
        const dx = e.clientX - rs.sx;
        const dy = e.clientY - rs.sy;
        const d = rs.dir;
        if (d === 'r' || d === 'br') {
          popup.style.width = Math.max(280, rs.sw + dx) + 'px';
        }
        if (d === 'b' || d === 'br') {
          popup.style.height = Math.max(150, rs.sh + dy) + 'px';
        }
      });

      handle.addEventListener('pointerup', (e) => {
        if (!rs.active) return;
        handle.releasePointerCapture(e.pointerId);
        rs.active = false;
        saveRecapBounds();
      });

      handle.addEventListener('pointercancel', () => {
        rs.active = false;
      });
    });
  }

  function dismissRecapPopup() {
    if (recapPopupEl) {
      recapPopupEl.remove();
      recapPopupEl = null;
    }
  }

  // Click outside the recap popup to close it.
  // Uses coordinate-based hit-testing instead of composedPath() because:
  // 1. The popup lives inside a CLOSED Shadow DOM — composedPath() can't see
  //    internal elements, only the shadow host.
  // 2. The popup can be dragged OUTSIDE the shadow host's bounds, so checking
  //    if the click is inside the host would wrongly close it.
  // Solution: get the popup's viewport rect via getBoundingClientRect() and
  // check if the click's clientX/clientY falls inside it. This works
  // regardless of shadow DOM boundaries or where the popup is positioned.
  document.addEventListener('pointerdown', (e) => {
    if (!recapPopupEl) return;
    const rect = recapPopupEl.getBoundingClientRect();
    // If the click is inside the popup's rectangle → don't close
    if (e.clientX >= rect.left && e.clientX <= rect.right &&
        e.clientY >= rect.top && e.clientY <= rect.bottom) return;
    // Click was outside the popup → close
    dismissRecapPopup();
  }, true);

  // Press 'f' to TOGGLE the recap popup:
  // - If open → close it
  // - If closed (and recapMode is ON) → open it for the current page
  document.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() !== 'f' || e.ctrlKey || e.metaKey || e.altKey) return;
    // Don't fire if the user is typing in an input/textarea
    const tag = document.activeElement?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    if (!pdfReady) return;

    if (recapPopupEl) {
      // Popup is open → close it
      dismissRecapPopup();
    } else if (recapMode) {
      // Popup is closed and recap mode is on → open it for the current page
      showRecapPopup(currentPage);
    }
  });

  // Pre-generate a recap for a summary chunk as soon as its summary is ready.
  // This way, when the user navigates away from that chunk, the recap
  // popup displays instantly from the cache instead of making the user
  // wait for a live AI call.
  function pregenerateRecap(summaryText) {
    if (!pdfReady) return;
    if (!summaryText || !summaryText.trim()) return;

    // Check if recap already cached for this summary
    for (let p = 1; p <= totalPages; p++) {
      if (summaries[p] === summaryText && recapCache[p]) return;
    }
    // Check if already in-flight
    if (recapInFlight.has(summaryText)) return;

    console.log('[Recap] Pre-generating recap for summary chunk');
    fetchRecap(summaryText).then((res) => {
      if (res && res.success) {
        console.log('[Recap] Pre-generated recap cached successfully');
      }
    });
  }

  // ===== ORIGINAL TEXT MODE =====
  // Fetches the raw book text for the current context page range and
  // displays it in the main panel. Completely independent of the summary
  // system — doesn't touch summaries[], summarizing, prefetch, or TTS.
  // The contextCount setting determines how many pages of original text
  // are shown (matching the summary context window).
  function loadOriginalText() {
    if (!pdfReady || !originalMode) return;

    // Build the page list: current page + (contextCount - 1) pages ahead
    const pages = [];
    for (let i = 0; i < contextCount; i++) {
      const p = currentPage + i;
      if (p <= totalPages) pages.push(p);
    }

    showSummaryLoading('Loading original text…');

    chrome.runtime.sendMessage({
      type: 'GET_PAGE_TEXT',
      url: pdfUrl,
      pages: pages
    }, (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        showSummaryError('Could not load original text: ' + (res?.error || 'Connection lost'));
        return;
      }
      // Only display if we're still in original mode and on the same page
      if (!originalMode) return;
      // Show the raw text — convert page markers to headings for readability
      const displayText = res.text
        .replace(/^--- Page (\d+) ---$/gm, '##### Page $1')
        .trim();
      showSummaryText(displayText);
    });
  }

  // ===== READING POSITION FEATURE (10-DAY EXPIRATION) =====
  // Remembers the last page visited on a specific PDF for up to 10 days after the
  // last time that specific PDF was opened. If a saved position exists, the panel
  // displays a "▶ Continue" button instead of "▶ Start". Clicking "Continue" jumps
  // to the saved page and generates its summary while syncing Discord Rich Presence.
  function getPdfPositionKey(url = null) {
    const canon = canonicalizePdfUrl(url || pdfUrl || location.href || '');
    return 'position_' + encodeURIComponent(canon);
  }

  function updateStartButtonUI(hasPosition, pageNum) {
    if (!startBtn) return;
    if (started) return;

    if (hasPosition && pageNum && positionEnabled) {
      startBtn.textContent = '▶ Continue';
      startBtn.title = `Continue reading from page ${pageNum} and generate summary (Right-click to clear)`;
      startBtn.classList.add('continue');
      if (summaryTextEl && summaryTextEl.classList.contains('idle')) {
        summaryTextEl.innerHTML = `Press <strong>Continue</strong> to resume from page ${pageNum}.`;
      }
    } else {
      startBtn.textContent = '▶ Start';
      startBtn.title = 'Start summarizing';
      startBtn.classList.remove('continue');
      if (summaryTextEl && summaryTextEl.classList.contains('idle')) {
        summaryTextEl.innerHTML = 'Press <strong>Start</strong> to summarize this page.';
      }
    }
  }

  function initPositionFeature() {
    const canonicalKey = getPdfPositionKey();
    chrome.storage.local.get(null, (allData) => {
      const now = Date.now();
      let bestPos = null;
      const redundantKeys = [];
      const expiredKeys = [];

      if (allData) {
        for (const k of Object.keys(allData)) {
          if (!k.startsWith('position_')) continue;

          const entry = allData[k];
          if (!entry || !entry.lastOpenedAt) {
            redundantKeys.push(k);
            continue;
          }

          // Check if this entry is older than 10 days
          if (now - entry.lastOpenedAt > TEN_DAYS_MS) {
            expiredKeys.push(k);
            continue;
          }

          // Check if this key corresponds to the current PDF (exact match or canonical match)
          let matchesThisPdf = (k === canonicalKey);
          if (!matchesThisPdf) {
            try {
              const rawKeyUrl = decodeURIComponent(k.replace(/^position_/, ''));
              if (getPdfPositionKey(rawKeyUrl) === canonicalKey) {
                matchesThisPdf = true;
              }
            } catch (e) {}
          }

          if (matchesThisPdf) {
            if (!bestPos || (entry.lastOpenedAt > (bestPos.lastOpenedAt || 0))) {
              bestPos = entry;
            }
            if (k !== canonicalKey) {
              redundantKeys.push(k);
            }
          }
        }
      }

      // Purge any expired keys or redundant duplicate keys from storage so no overlap exists
      const toRemove = [...new Set([...expiredKeys, ...redundantKeys])];
      if (toRemove.length > 0) {
        chrome.storage.local.remove(toRemove);
      }

      if (bestPos && bestPos.page) {
        // Valid saved position! Refresh lastOpenedAt to right now
        bestPos.lastOpenedAt = now;
        savedPdfPosition = bestPos;
        if (positionEnabled) {
          // Always persist to the single canonical key
          chrome.storage.local.set({ [canonicalKey]: bestPos });
        }
        if (!started) {
          updateStartButtonUI(true, bestPos.page);
        }
      } else {
        savedPdfPosition = null;
        if (!started) {
          updateStartButtonUI(false);
        }
      }
    });
  }

  function saveCurrentPosition(pageNum) {
    if (!positionEnabled || !pageNum) return;
    savedPdfPosition = {
      page: pageNum,
      lastOpenedAt: Date.now(),
    };
    if (savePositionTimer) clearTimeout(savePositionTimer);
    savePositionTimer = setTimeout(() => {
      savePositionTimer = null;
      flushSavedPosition();
    }, 300);
  }

  function flushSavedPosition() {
    if (savePositionTimer) {
      clearTimeout(savePositionTimer);
      savePositionTimer = null;
    }
    if (positionEnabled && savedPdfPosition && savedPdfPosition.page) {
      const key = getPdfPositionKey();
      chrome.storage.local.set({ [key]: savedPdfPosition });
    }
  }

  function clearSavedPosition() {
    if (savePositionTimer) {
      clearTimeout(savePositionTimer);
      savePositionTimer = null;
    }
    savedPdfPosition = null;
    const key = getPdfPositionKey();
    chrome.storage.local.remove(key);
  }

  // ===== BOOKMARK FEATURE =====
  // Single bookmark per PDF. Stores the generated summary, recap, page range,
  // and clicked word location into chrome.storage.local. Returning to the PDF
  // displays the bookmark in a distinct color and allows instant jumping without
  // re-calling Ollama or generating a new summary.
  function getPdfBookmarkKey(url = null) {
    const canon = canonicalizePdfUrl(url || pdfUrl || location.href || '');
    return 'bookmark_' + encodeURIComponent(canon);
  }

  function initBookmarkFeature() {
    bookmarkBtnEl = shadow.getElementById('pnBookmarkBtn');
    bookmarkBannerEl = shadow.getElementById('pnBookmarkBanner');

    if (!bookmarkBtnEl) return;

    // Load any existing bookmark for this PDF from storage
    const key = getPdfBookmarkKey();
    chrome.storage.local.get([key], (data) => {
      if (data && data[key]) {
        currentBookmark = data[key];
        updateBookmarkButtonUI();
      }
    });

    // Bookmark button click
    bookmarkBtnEl.addEventListener('click', (e) => {
      e.stopPropagation();
      handleBookmarkButtonClick();
    });

    // Bookmark button right-click: clear bookmark
    bookmarkBtnEl.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (currentBookmark) {
        clearBookmark();
      } else {
        showBookmarkBanner('No bookmark saved for this PDF.', false, 2500);
      }
    });
  }

  function updateBookmarkButtonUI() {
    if (!bookmarkBtnEl) return;
    if (currentBookmark) {
      bookmarkBtnEl.classList.add('has-bookmark');
      bookmarkBtnEl.title = `Bookmark: Pages ${currentBookmark.pageRangeText} ("${currentBookmark.word}")\n• Click to jump to bookmark\n• Right-click to clear bookmark`;
    } else {
      bookmarkBtnEl.classList.remove('has-bookmark');
      bookmarkBtnEl.title = 'Bookmark current summary';
    }
  }

  function handleBookmarkButtonClick() {
    // If currently selecting a word, clicking the button cancels selection
    if (isSelectingBookmarkWord) {
      cancelBookmarkSelection();
      return;
    }

    // If there is an existing bookmark
    if (currentBookmark) {
      // Check if user currently has an active summary on screen that is DIFFERENT from the bookmark
      const hasActiveDifferentSummary = (currentPage !== currentBookmark.startPage) &&
        !!(summaries[currentPage] && summaries[currentPage].trim().length > 0 && started);

      if (hasActiveDifferentSummary) {
        // User has another summary open! Give them the choice: jump to saved bookmark, or bookmark this new page
        const curEnd = Math.min(currentPage + (contextCount || 1) - 1, totalPages);
        const curRange = (curEnd > currentPage) ? `${currentPage}-${curEnd}` : `${currentPage}`;
        showBookmarkActionPrompt(
          `Bookmark exists for pages ${currentBookmark.pageRangeText}.`,
          [
            { label: `Jump (${currentBookmark.pageRangeText})`, primary: true, action: () => jumpToBookmark() },
            { label: `Bookmark Here (${curRange})`, action: () => startBookmarkSelection() },
            { label: 'Clear', action: () => clearBookmark() }
          ]
        );
      } else {
        // Return to bookmarked position, scroll to word, clear bookmark, and restore color!
        jumpToBookmark();
      }
      return;
    }

    // No bookmark exists yet
    // Check if there is an active summary displayed
    const currentSummary = (summaries[currentPage] || '').trim();
    const isIdle = summaryTextEl.classList.contains('idle');
    if (isIdle || !currentSummary || summarizing.has(currentPage)) {
      showBookmarkBanner('Please generate a summary first before bookmarking.', false, 3000);
      return;
    }

    startBookmarkSelection();
  }

  function startBookmarkSelection() {
    isSelectingBookmarkWord = true;
    if (bookmarkBtnEl) bookmarkBtnEl.classList.add('selecting');
    if (summaryTextEl) summaryTextEl.classList.add('pn-bookmark-selecting');

    showBookmarkBanner(
      '🔖 Click a word in the summary to set your bookmark',
      true,
      0, // do not auto-hide while waiting
      () => cancelBookmarkSelection()
    );
  }

  function cancelBookmarkSelection() {
    isSelectingBookmarkWord = false;
    if (bookmarkBtnEl) bookmarkBtnEl.classList.remove('selecting');
    if (summaryTextEl) summaryTextEl.classList.remove('pn-bookmark-selecting');
    hideBookmarkBanner();
  }

  function handleBookmarkWordSelection(span) {
    if (!isSelectingBookmarkWord || !span) return;

    const wordText = span.textContent.trim();
    if (!wordText) return;

    // Find occurrence of this word among all .wh-word elements
    const allWordSpans = Array.from(summaryTextEl.querySelectorAll('.wh-word'));
    const wordSpanIndex = allWordSpans.indexOf(span);
    const matchingSpans = allWordSpans.filter(s => s.textContent.trim().toLowerCase() === wordText.toLowerCase());
    const wordOccurrence = matchingSpans.indexOf(span);

    const startPage = currentPage;
    const count = contextCount || 1;
    const endPage = Math.min(currentPage + count - 1, totalPages);
    const pageRangeText = (endPage > startPage) ? `${startPage}-${endPage}` : `${startPage}`;

    const summary = summaries[currentPage] || '';
    const recap = recapCache[currentPage] || '';

    currentBookmark = {
      url: (pdfUrl || location.href || '').split('#')[0].replace(/\/+$/, ''),
      startPage,
      endPage,
      pageRangeText,
      summary,
      recap,
      word: wordText,
      wordOccurrence: Math.max(0, wordOccurrence),
      wordSpanIndex: Math.max(0, wordSpanIndex),
      savedAt: Date.now()
    };

    const key = getPdfBookmarkKey();
    chrome.storage.local.set({ [key]: currentBookmark });

    // If recap was not yet ready, fetch and update the saved bookmark with recap
    if (!recap && summary) {
      fetchRecap(summary).then(res => {
        if (res && res.success && currentBookmark && currentBookmark.summary === summary) {
          currentBookmark.recap = res.recap;
          chrome.storage.local.set({ [key]: currentBookmark });
        }
      });
    }

    // Mark span with bookmark highlight
    allWordSpans.forEach(s => s.classList.remove('wh-bookmarked-word'));
    span.classList.add('wh-bookmarked-word');

    cancelBookmarkSelection();
    updateBookmarkButtonUI();

    showBookmarkBanner(`✓ Bookmark saved at "${wordText}" (pages ${pageRangeText})!`, false, 2500);
  }

  function jumpToBookmark() {
    if (!currentBookmark) return;

    if (isSelectingBookmarkWord) cancelBookmarkSelection();
    hideBookmarkBanner();

    // Capture bookmark data before clearing
    const bm = currentBookmark;

    // Pause existing audio
    pauseAudioForNavigation(currentPage);

    // 1. Update page counters
    currentPage = bm.startPage;
    if (pageInput) {
      pageInput.value = bm.pageRangeText;
    }

    // 2. Sync native PDF viewer
    try {
      const pageHash = `#page=${currentPage}`;
      if (window.location.hash !== pageHash) {
        window.location.hash = pageHash;
      }
      const viewerElements = document.querySelectorAll('embed, iframe, object');
      viewerElements.forEach(el => {
        try {
          const currentSrc = el.src || el.data;
          if (currentSrc && currentSrc.includes('.pdf')) {
            const baseUrl = currentSrc.split('#')[0];
            const newSrc = baseUrl + pageHash;
            if (currentSrc !== newSrc) {
              if (el.src) el.src = newSrc;
              else if (el.data) el.data = newSrc;
            }
          }
        } catch (e) {}
      });
      const viewer = document.querySelector('pdf-viewer') || viewerElements[0];
      if (viewer && typeof viewer.postMessage === 'function') {
        viewer.postMessage({ type: 'goToPage', page: currentPage - 1 }, '*');
      }
    } catch (e) {
      console.warn("Could not sync PDF viewer:", e);
    }

    // 3. Update prev/next button states and progress bar
    const prevBtn = shadow.getElementById('pnPrev');
    const nextBtn = shadow.getElementById('pnNext');
    if (prevBtn) prevBtn.disabled = currentPage <= 1;
    if (nextBtn) nextBtn.disabled = currentPage >= totalPages;
    updateProgressBar();

    // 4. Restore cached summary and recap without Ollama API call
    started = true;
    if (discordRpcEnabled) {
      sendDiscordPresence(true, false);
      startDiscordHeartbeat();
    }
    const endP = bm.endPage || bm.startPage;
    for (let p = bm.startPage; p <= endP; p++) {
      if (p <= totalPages) {
        summaries[p] = bm.summary;
        if (bm.recap) {
          recapCache[p] = bm.recap;
        }
      }
    }

    // 5. Delete bookmark from storage and restore icon color
    const key = getPdfBookmarkKey();
    chrome.storage.local.remove([key], () => {
      currentBookmark = null;
      updateBookmarkButtonUI();
    });

    // 6. Render summary
    showSummaryText(bm.summary);

    // 7. Find the bookmarked word span, scroll smoothly to it, then unhighlight the word
    setTimeout(() => {
      const targetSpan = findBookmarkedWordSpan(bm);
      if (targetSpan) {
        const allSpans = summaryTextEl.querySelectorAll('.wh-word');
        allSpans.forEach(s => s.classList.remove('wh-bookmarked-word'));
        targetSpan.classList.add('wh-bookmarked-word');
        scrollToBookmarkedWord(targetSpan);

        // Flash briefly during scroll, then unhighlight the word so user can re-bookmark if desired
        setTimeout(() => {
          targetSpan.classList.remove('wh-bookmarked-word');
        }, 1500);
      }
    }, 60);

    showBookmarkBanner(`🔖 Returned to bookmark (pages ${bm.pageRangeText}). Bookmark cleared.`, false, 2500);
  }

  function clearBookmark() {
    const key = getPdfBookmarkKey();
    chrome.storage.local.remove([key], () => {
      currentBookmark = null;
      updateBookmarkButtonUI();
      if (summaryTextEl) {
        const allSpans = summaryTextEl.querySelectorAll('.wh-bookmarked-word');
        allSpans.forEach(s => s.classList.remove('wh-bookmarked-word'));
      }
      showBookmarkBanner('Bookmark removed for this PDF.', false, 2500);
    });
  }

  function findBookmarkedWordSpan(bm) {
    if (!bm || !summaryTextEl) return null;
    const allSpans = Array.from(summaryTextEl.querySelectorAll('.wh-word'));
    if (allSpans.length === 0) return null;

    // 1. Try exact index if words match
    if (bm.wordSpanIndex != null && bm.wordSpanIndex < allSpans.length) {
      const s = allSpans[bm.wordSpanIndex];
      if (s && s.textContent.trim().toLowerCase() === bm.word.toLowerCase()) {
        return s;
      }
    }

    // 2. Try occurrence match
    const matching = allSpans.filter(s => s.textContent.trim().toLowerCase() === bm.word.toLowerCase());
    if (matching.length > 0) {
      const occ = bm.wordOccurrence || 0;
      return matching[occ] || matching[0];
    }

    // 3. Fallback: contains word
    return allSpans.find(s => s.textContent.toLowerCase().includes(bm.word.toLowerCase())) || null;
  }

  function scrollToBookmarkedWord(wordSpan) {
    if (!wordSpan || !summaryTextEl) return;
    const summaryContainer = summaryTextEl.parentElement;
    if (!summaryContainer) return;

    const containerRect = summaryContainer.getBoundingClientRect();
    const spanRect = wordSpan.getBoundingClientRect();
    const currentScrollTop = summaryContainer.scrollTop;
    const offset = spanRect.top - containerRect.top;
    const targetScrollTop = currentScrollTop + offset - (containerRect.height / 2) + (spanRect.height / 2);

    summaryContainer.scrollTo({
      top: Math.max(0, targetScrollTop),
      behavior: 'smooth'
    });
  }

  function showBookmarkBanner(text, showCancel = false, autoHideMs = 2500, onCancel = null) {
    if (!bookmarkBannerEl) return;
    clearTimeout(bookmarkBannerTimeout);

    bookmarkBannerEl.innerHTML = `
      <span class="pn-bookmark-banner-text">${text}</span>
      ${showCancel ? '<button class="pn-bookmark-banner-cancel" id="pnBmCancel">Cancel</button>' : ''}
    `;
    bookmarkBannerEl.style.display = 'flex';

    if (showCancel) {
      const cancelBtn = bookmarkBannerEl.querySelector('#pnBmCancel');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (typeof onCancel === 'function') onCancel();
          else hideBookmarkBanner();
        });
      }
    }

    if (autoHideMs > 0) {
      bookmarkBannerTimeout = setTimeout(() => {
        hideBookmarkBanner();
      }, autoHideMs);
    }
  }

  function showBookmarkActionPrompt(msg, actions = []) {
    if (!bookmarkBannerEl) return;
    clearTimeout(bookmarkBannerTimeout);

    const actionButtonsHtml = actions.map((act, i) => `
      <button class="pn-bookmark-action-btn ${act.primary ? 'primary' : ''}" data-idx="${i}">${act.label}</button>
    `).join('');

    bookmarkBannerEl.innerHTML = `
      <span class="pn-bookmark-banner-text">${msg}</span>
      <div class="pn-bookmark-actions-group">
        ${actionButtonsHtml}
      </div>
    `;
    bookmarkBannerEl.style.display = 'flex';

    bookmarkBannerEl.querySelectorAll('.pn-bookmark-action-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.dataset.idx, 10);
        const actionObj = actions[idx];
        if (actionObj && typeof actionObj.action === 'function') {
          actionObj.action();
        }
      });
    });

    // Auto-hide after 8 seconds if no choice is made
    bookmarkBannerTimeout = setTimeout(() => {
      hideBookmarkBanner();
    }, 8000);
  }

  function hideBookmarkBanner() {
    clearTimeout(bookmarkBannerTimeout);
    if (bookmarkBannerEl) {
      bookmarkBannerEl.style.display = 'none';
    }
  }

  // ===== PAGE NAVIGATION =====
  function goToPage(num) {
    if (num < 1 || num > totalPages || !pdfReady) return;
    if (isSelectingBookmarkWord) cancelBookmarkSelection();

    // CRITICAL: Save the OLD page's audio position BEFORE updating currentPage.
    // If we update currentPage first, the old page's position gets saved to the
    // NEW page's entry — causing the new page to resume from the old page's spot.
    const oldPage = currentPage;
    pauseAudioForNavigation(oldPage);

    // If Recap mode is ON and we're actually navigating to a DIFFERENT page,
    // trigger the recap popup for the page we're leaving. This is purely
    // additive — it doesn't modify any navigation logic below.
    if (recapMode && oldPage !== num) {
      console.log('[Recap] Navigation detected: oldPage=' + oldPage + ', newPage=' + num + ', recapMode=' + recapMode);
      // Use setTimeout(0) so the popup appears AFTER the new page renders
      setTimeout(() => showRecapPopup(oldPage), 0);
    }

    // If TTS intent is active (user was listening, not paused), auto-start TTS
    // on the new page from the beginning (position 0).
    if (ttsEnabled && ttsIntentActive) {
      autoAdvanceTarget = num;
    }

    currentPage = num;
    pushRemoteState(true);
    // Display as range: "80-139" (capped at totalPages), unless the input is focused (editing)
    if (document.activeElement !== pageInput) {
      const endPage = Math.min(num + contextCount - 1, totalPages);
      pageInput.value = (endPage > num) ? num + '-' + endPage : num;
    } else {
      pageInput.value = num;
    }

    if (started) {
      sendDiscordPresence(true, false);
      if (positionEnabled) {
        saveCurrentPosition(num);
      }
    }

    // Update prev/next button states
    const prevBtn = shadow.getElementById('pnPrev');
    const nextBtn = shadow.getElementById('pnNext');
    if (prevBtn) prevBtn.disabled = num <= 1;
    if (nextBtn) nextBtn.disabled = num >= totalPages;

    // Sync native PDF viewer to match this page
    try {
      const pageHash = `#page=${num}`;
      if (window.location.hash !== pageHash) {
        window.location.hash = pageHash;
      }

      // Aggressively target the viewer elements and update their sources
      // This is often the only way to force the Chrome PDF viewer to jump
      const viewerElements = document.querySelectorAll('embed, iframe, object');
      viewerElements.forEach(el => {
        try {
          const currentSrc = el.src || el.data;
          if (currentSrc && currentSrc.includes('.pdf')) {
            const baseUrl = currentSrc.split('#')[0];
            const newSrc = baseUrl + pageHash;
            
            // Only update if it's actually different to avoid unnecessary reloads
            if (currentSrc !== newSrc) {
              if (el.src) el.src = newSrc;
              else if (el.data) el.data = newSrc;
            }
          }
        } catch (e) {}
      });

      // Fallback: Notify the viewer via postMessage
      const viewer = document.querySelector('pdf-viewer') || viewerElements[0];
      if (viewer && typeof viewer.postMessage === 'function') {
        viewer.postMessage({ type: 'goToPage', page: num - 1 }, '*');
      }
    } catch (e) {
      console.warn("Could not sync PDF viewer:", e);
    }

    // Show summary (only if already started)
    // — BUT if "Original" mode is ON, skip the summary entirely and load
    //   the raw book text instead. This is an additive override: it doesn't
    //   modify the summary logic below, just short-circuits it when active.
    if (originalMode) {
      loadOriginalText();
    } else if (summaries[num]) {
      showSummaryText(summaries[num]);
    } else if (summarizing.has(num)) {
      showSummaryLoading('Summarizing…');
    } else if (started) {
      // Current page isn't ready — prioritize it immediately
      summarizePage(num);
    } else {
      summaryTextEl.className = 'pn-summary-text idle';
      summaryTextEl.innerHTML = 'Press <strong>Start</strong> to summarize this page.';
    }

    // Reset summary scroll to the top smoothly on every navigation.
    // The scroll container is .pn-summary (summaryTextEl.parentElement).
    // Use 'smooth' so the reset feels animated, not jarring. When the
    // summary is still loading and arrives later, showSummaryText() will
    // also reset scroll instantly (see currentPageForScroll logic there).
    const summaryContainer = summaryTextEl.parentElement;
    if (summaryContainer && typeof summaryContainer.scrollTo === 'function') {
      summaryContainer.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
    }

    // Update progress bar
    updateProgressBar();

    // When navigating, summarize the new page if not already cached,
    // and buffer one page ahead.
    if (started && !summaries[num] && !summarizing.has(num)) summarizePage(num);
    if (started) schedulePrefetch(num);
  }

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (!pdfReady) return;

    // Check if user is currently typing in any input field (in main panel, sidebars, or document)
    const isTyping = (root) => {
      if (!root) return false;
      const active = root.activeElement;
      return active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable);
    };

    if (isTyping(shadow) || isTyping(chatShadow) || isTyping(lbShadow) || isTyping(document)) return;

    // Word highlight mode is always on — no Shift toggle needed.
    // Control key triggers phrase popup for current selection
    if (e.key === 'Control' && wordHighlightActive) {
      const sel = getActiveSelection();
      if (sel && sel.rangeCount > 0) {
        const selectedText = sel.toString().trim();
        if (selectedText) {
          const range = sel.getRangeAt(0);
          if (summaryTextEl.contains(range.commonAncestorContainer)) {
            const rect = range.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
              showPopupForText(selectedText, rect);
            }
          }
        }
      }
    }

    const key = e.key.toLowerCase();

    // ArrowUp / ArrowDown scroll the summary panel. Slowed down to 16% of
    // the visible height per keypress (was 80% — way too fast).
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      const c = summaryTextEl.parentElement;
      if (c) c.scrollBy({ top: c.clientHeight * 0.16, behavior: 'smooth' });
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      const c = summaryTextEl.parentElement;
      if (c) c.scrollBy({ top: -c.clientHeight * 0.16, behavior: 'smooth' });
      return;
    }

    // 'd' advances forward, 'a' goes back. ArrowRight / ArrowLeft also still
    // navigate (kept as alternates so existing users don't break).
    if (e.key === 'ArrowRight' || key === 'd') {
      e.preventDefault();
      goToPage(Math.min(currentPage + contextCount, totalPages));
    } else if (e.key === 'ArrowLeft' || key === 'a') {
      e.preventDefault();
      goToPage(Math.max(currentPage - contextCount, 1));
    }
  });

  // ===== SUMMARIZE =====
  function summarizePage(pageNum, isPrefetch = false) {
    if (summarizing.has(pageNum) || summaries[pageNum]) return; // already in-flight or done
    summarizing.add(pageNum);
    activePrefetches++;
    if (!isPrefetch) showSummaryLoading('Summarizing…');

    chrome.runtime.sendMessage({
      type: 'SUMMARIZE_PAGE',
      url: pdfUrl,
      pageNum,
      contextCount,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language,
      summaryLength
    }, (res) => {
      summarizing.delete(pageNum);
      activePrefetches = Math.max(0, activePrefetches - 1);
      const count = contextCount || 1;
      const isCurrentRange = currentPage >= pageNum && currentPage < pageNum + count;

      if (chrome.runtime.lastError || !res) {
        if (isCurrentRange) showSummaryError('Lost connection to extension.');
        drainPrefetchQueue();
        return;
      }

      if (!res.success) {
        const err = res.error || 'Unknown error';
        if (isCurrentRange) showSummaryError(err);
        if (err.includes('NetworkError') || err.includes('ERR_CONNECTION') || err.includes('connect ECONNREFUSED') || err.includes('Ollama returned')) {
          setOllamaStatus(false);
        }
        drainPrefetchQueue();
        return;
      }

      for (let i = 0; i < count; i++) {
        const p = pageNum + i;
        if (p <= totalPages) {
          summaries[p] = res.summary;
        }
      }
      if (recapMode) {
        pregenerateRecap(res.summary);
      }

      // Update UI if still on this page
      if (currentPage >= pageNum && currentPage < pageNum + count) {
        showSummaryText(res.summary);
      }

      // Trigger audio prefetch since new summaries are available
      triggerAudioPrefetch(currentPage);

      // Continue draining the prefetch queue
      drainPrefetchQueue();
    });
  }

  function summarizeHoverRange(startPage, endPage) {
    if (summarizing.has(startPage)) return;
    summarizing.add(startPage);
    showSummaryLoading('Summarizing Range (' + startPage + '-' + endPage + '). This may take a while...');

    chrome.runtime.sendMessage({
      type: 'SUMMARIZE_HOVER_RANGE',
      url: pdfUrl,
      startPage,
      endPage,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language
    }, (res) => {
      summarizing.delete(startPage);
      if (chrome.runtime.lastError || !res) {
        showSummaryError('Lost connection to extension.');
        return;
      }
      if (!res.success) {
        showSummaryError(res.error || 'Unknown error during range summary');
        return;
      }
      
      showSummaryText(res.summary);
    });
  }

  function schedulePrefetch(fromPage) {
    // Buffer ONE summary ahead (the next page set). This keeps the next
    // page ready so navigation feels instant, without generating dozens
    // of summaries ahead like the old PREFETCH_AHEAD=3 did.
    const desired = [];
    const nextP = fromPage + contextCount;
    if (nextP <= totalPages && !summaries[nextP] && !summarizing.has(nextP)) {
      desired.push(nextP);
    }
    prefetchQueue = desired;
    drainPrefetchQueue();
  }

  // Pull pages off the queue up to MAX_CONCURRENT parallel calls
  function drainPrefetchQueue() {
    while (prefetchQueue.length > 0 && activePrefetches < MAX_CONCURRENT) {
      const nextPage = prefetchQueue.shift();
      // Skip if already done or in-flight
      if (summaries[nextPage] || summarizing.has(nextPage)) continue;
      const isPrefetch = nextPage !== currentPage;
      summarizePage(nextPage, isPrefetch);
    }
  }

  // ===== UI HELPERS =====
  function showSummaryText(text) {
    const isNewPage = currentPageForScroll !== currentPage;

    summaryTextEl.className = 'pn-summary-text';
    
    // Render Markdown and sections
    summaryTextEl.innerHTML = markdownToHTML(text);

    // If this summary is being shown for a NEW page (i.e. the summary just
    // arrived after the user navigated, or the user just navigated to a
    // cached page), reset scroll to the top instantly. We use 'auto' (not
    // 'smooth') here because the content just swapped — a smooth scroll
    // would visually slide through stale content from the previous page.
    // For the same-page re-render case (e.g. TTS state change), preserve
    // the user's scroll position.
    if (isNewPage) {
      const summaryContainer = summaryTextEl.parentElement;
      if (summaryContainer && typeof summaryContainer.scrollTo === 'function') {
        summaryContainer.scrollTo({ top: 0, left: 0, behavior: 'auto' });
      }
      currentPageForScroll = currentPage;
    }

    // Apply RTL if Arabic
    const isRTL = language === 'Arabic';
    summaryTextEl.style.direction = isRTL ? 'rtl' : 'ltr';
    summaryTextEl.setAttribute('lang', isRTL ? 'ar' : 'en');
    summaryTextEl.style.textAlign = isRTL ? 'right' : 'justify';

    // Enable TTS button (only if TTS master toggle is on)
    if (ttsEnabled) {
      const ttsBtn = shadow.getElementById('pnTTS');
      if (ttsBtn) ttsBtn.disabled = false;
    }

    // If we navigated to a different page, reset audio state for the new page.
    // Per-page resume positions are preserved in pageResumePositions.
    if (currentPageForAudio !== currentPage) {
      // Revoke old blob URL to prevent memory leak
      if (ttsAudioBuffer) {
        URL.revokeObjectURL(ttsAudioBuffer);
      }
      ttsAudioBuffer = null;
      currentPageForAudio = currentPage;
      ttsPlaying = false;
      ttsPaused = false;

      const controls = shadow.getElementById('pnAudioControls');
      if (controls) controls.style.display = 'none';
      stopProgressUpdater();
    }

    // Update the button label based on current state (Play vs Resume)
    updateTTSButtonLabel();

    // Auto-play if we just auto-advanced here (handleAudioFinished set the
    // target) OR if the user manually navigated while TTS was playing
    // (goToPage set the target because ttsIntentActive was true).
    // In both cases, we CLEAR any saved resume position for this page so
    // playback starts from 0 — the user wants to hear the new page from
    // the beginning, not from some old pause point.
    if (autoAdvanceTarget === currentPage) {
      autoAdvanceTarget = null;           // consume the flag
      delete pageResumePositions[currentPage]; // start from 0, not from any old pause
      const startTarget = currentPage;     // capture for closure
      setTimeout(() => {
        if (ttsEnabled && !ttsPlaying && !ttsLoading && summaries[startTarget]) {
          startTTSPlayback();
        }
      }, 300);
    } else if (autoAdvanceTarget !== null && autoAdvanceTarget !== currentPage) {
      // We navigated somewhere else — clear the stale target
      autoAdvanceTarget = null;
    }

    // Update word/char count next to status
    const statsEl = shadow.getElementById('pnSummaryStats');
    if (statsEl) {
      const words = text.trim().split(/\s+/).filter(w => w.length > 0).length;
      const chars = text.length;
      statsEl.textContent = `${words}w / ${chars}c`;
    }

    pushRemoteState(true);

    // Always wrap words for highlight mode (it's the default now)
    wrapWordsInSummary();
    summaryTextEl.classList.add('wh-active');

    // Highlight bookmarked word if viewing the bookmarked summary
    if (currentBookmark && currentBookmark.startPage === currentPage && currentBookmark.summary === text) {
      setTimeout(() => {
        const targetSpan = findBookmarkedWordSpan(currentBookmark);
        if (targetSpan) {
          targetSpan.classList.add('wh-bookmarked-word');
        }
      }, 20);
    }
  }

  // ===== WORD HIGHLIGHT MODE =====
  function toggleWordHighlightMode() {
    wordHighlightActive = !wordHighlightActive;
    dismissWordPopup();

    if (wordHighlightActive) {
      wrapWordsInSummary();
      summaryTextEl.classList.add('wh-active');
    } else {
      unwrapWordsInSummary();
      summaryTextEl.classList.remove('wh-active');
    }
  }

  function wrapWordsInSummary() {
    // Walk all text nodes inside the summary and wrap individual words in spans
    const walker = document.createTreeWalker(
      summaryTextEl,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          // Skip text inside code blocks, block headers, and block icons
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (parent.closest('pre, code, .pn-block-header, .pn-block-icon')) {
            return NodeFilter.FILTER_REJECT;
          }
          // Only accept nodes that have actual word characters
          if (/\w/.test(node.textContent)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );

    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);

    textNodes.forEach(textNode => {
      const text = textNode.textContent;
      // Split on word boundaries preserving whitespace/punctuation
      const parts = text.split(/(\s+)/);
      if (parts.length <= 1 && !/\w/.test(text)) return;

      const frag = document.createDocumentFragment();
      parts.forEach(part => {
        if (/\w/.test(part)) {
          const span = document.createElement('span');
          span.className = 'wh-word';
          span.textContent = part;
          span.addEventListener('mouseenter', onWordHover);
          span.addEventListener('mouseleave', onWordLeave);
          span.addEventListener('click', onWordClick);
          frag.appendChild(span);
        } else {
          frag.appendChild(document.createTextNode(part));
        }
      });

      textNode.parentNode.replaceChild(frag, textNode);
    });
  }

  function unwrapWordsInSummary() {
    const wordSpans = summaryTextEl.querySelectorAll('.wh-word');
    wordSpans.forEach(span => {
      const textNode = document.createTextNode(span.textContent);
      span.parentNode.replaceChild(textNode, span);
    });
    // Normalize to merge adjacent text nodes
    summaryTextEl.normalize();
  }

  let activeWordSpan = null; // which word span currently has the popup
  let activePopupTargetRect = null; // bounding rect of the target word/selection
  let lastMouseX = 0;
  let lastMouseY = 0;

  function getActiveSelection() {
    if (shadow && typeof shadow.getSelection === 'function') {
      const sel = shadow.getSelection();
      if (sel && sel.rangeCount > 0) return sel;
    }
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) return sel;
    return null;
  }

  function getMouseTargetRect(fallbackRect) {
    if (lastMouseX === 0 && lastMouseY === 0 && fallbackRect) {
      return fallbackRect;
    }
    return {
      left: lastMouseX,
      right: lastMouseX,
      top: lastMouseY,
      bottom: lastMouseY,
      width: 0,
      height: 0
    };
  }

  function onSummaryMouseUp(e) {
    if (!wordHighlightActive) return;
    if (!e.ctrlKey) return;

    // Capture mouse coordinates on mouseup
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;

    // Wait slightly to let selection update
    setTimeout(() => {
      const sel = getActiveSelection();
      if (!sel || sel.rangeCount === 0) return;

      const selectedText = sel.toString().trim();
      if (!selectedText) return;

      const range = sel.getRangeAt(0);
      if (!summaryTextEl.contains(range.commonAncestorContainer)) {
        return;
      }

      const rangeRect = range.getBoundingClientRect();
      const rect = getMouseTargetRect(rangeRect);

      // Show popup for selected phrase
      showPopupForText(selectedText, rect);
    }, 20);
  }

  function onWordHover(e) {
    const span = e.target;
    // Just add a visual hover cue — the popup is shown on click
    span.classList.add('wh-hovered');
  }

  function onWordLeave(e) {
    const span = e.target;
    span.classList.remove('wh-hovered');
  }

  function onWordClick(e) {
    if (e.ctrlKey) return; // Ignore click if Ctrl is pressed (let selection mouseup handle it)
    e.stopPropagation();
    const span = e.target;

    // Check if we are currently in bookmark selection mode
    if (isSelectingBookmarkWord) {
      handleBookmarkWordSelection(span);
      return;
    }

    // Capture click coordinates
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;

    // If clicking the same word that already has a popup, dismiss it
    if (activeWordSpan === span && activeWordPopup) {
      dismissWordPopup();
      return;
    }

    showWordPopup(span);
  }

  // Dismiss popup when clicking anywhere else in the summary or panel
  function setupPopupDismiss() {
    // Listen on the panel itself — clicks that aren't on a word or the popup dismiss it
    panel.addEventListener('click', (e) => {
      if (!activeWordPopup) return;
      // Don't dismiss if the click is inside the popup itself
      if (activeWordPopup.contains(e.target)) return;
      // Don't dismiss if clicking another word (onWordClick handles that)
      if (e.target.classList && e.target.classList.contains('wh-word')) return;
      dismissWordPopup();
    });
  }

  function showPopupForText(text, rect) {
    dismissWordPopup(false); // Do NOT clear selection when opening a popup

    const cleanText = text.trim();
    if (!cleanText) return;

    activePopupTargetRect = rect;

    // Detect if this is a multi-word phrase
    const isPhrase = cleanText.split(/\s+/).length > 1;

    const popup = document.createElement('div');
    popup.className = 'wh-popup';
    popup.innerHTML = `
      <div class="wh-popup-word">${cleanText}</div>
      <div class="wh-popup-actions">
        <button class="wh-popup-btn wh-define-btn" title="Get definition">PDF Define</button>
        <button class="wh-popup-btn wh-search-btn" title="Search the web">Search</button>
        <button class="wh-popup-btn wh-aloud-btn" title="Read aloud with the selected voice">Aloud</button>
        ${isPhrase ? `<button class="wh-popup-btn wh-truth-btn" title="Verify if this is true"> Is this true?</button>` : ''}
      </div>
      <div class="wh-popup-definition" style="display:none;"></div>
    `;

    // Calculate position relative to the summary container
    popup.style.position = 'absolute';

    // Append to summary container first to measure
    summaryTextEl.parentElement.appendChild(popup);

    const parentEl = summaryTextEl.parentElement;
    const popupRect = popup.getBoundingClientRect();
    const summaryParentRect = parentEl.getBoundingClientRect();
    const scrollTop = parentEl.scrollTop;
    const scrollLeft = parentEl.scrollLeft;

    let left = rect.left - summaryParentRect.left + scrollLeft + (rect.width / 2) - (popupRect.width / 2);
    let top = rect.top - summaryParentRect.top + scrollTop - popupRect.height - 8;

    // Keep within bounds
    left = Math.max(4, Math.min(left, summaryParentRect.width - popupRect.width - 4));
    if (top < scrollTop) {
      // Show below the target instead
      top = rect.bottom - summaryParentRect.top + scrollTop + 8;
    }

    popup.style.left = left + 'px';
    popup.style.top = top + 'px';
    popup.style.zIndex = '9999';

    // Prevent clicks and scroll wheel inside popup from bubbling to parent container
    popup.addEventListener('click', (e) => e.stopPropagation());
    popup.addEventListener('wheel', (e) => e.stopPropagation(), { passive: true });

    // Define button
    popup.querySelector('.wh-define-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      fetchWordDefinition(cleanText, popup);
    });

    // Search button
    popup.querySelector('.wh-search-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      window.open(`https://www.google.com/search?q=${encodeURIComponent(cleanText)}`, '_blank');
    });

    // Aloud button — speak the selected text via Piper TTS using the
    // currently-selected voice for the panel's language.
    popup.querySelector('.wh-aloud-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      speakTextAloud(cleanText, popup);
    });

    // Is this true button
    if (isPhrase) {
      popup.querySelector('.wh-truth-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        checkTruthOfText(cleanText, popup);
      });
    }

    activeWordPopup = popup;
  }

  function showWordPopup(wordSpan) {
    dismissWordPopup(false); // Do NOT clear selection when opening a popup

    const word = wordSpan.textContent.replace(/[^a-zA-Z0-9'-]/g, '').trim();
    if (!word) return;

    activeWordSpan = wordSpan;
    wordSpan.classList.add('wh-selected');

    const rect = getMouseTargetRect(wordSpan.getBoundingClientRect());
    showPopupForText(word, rect);
  }

  function dismissWordPopup(clearSelection = true) {
    if (activeWordPopup) {
      activeWordPopup.remove();
      activeWordPopup = null;
    }
    if (activeWordSpan) {
      activeWordSpan.classList.remove('wh-selected');
      activeWordSpan = null;
    }
    activePopupTargetRect = null;
    if (clearSelection) {
      try {
        const sel = getActiveSelection();
        if (sel) sel.removeAllRanges();
      } catch (err) {}
    }
  }

  function fetchWordDefinition(word, popup) {
    const defEl = popup.querySelector('.wh-popup-definition');
    const defineBtn = popup.querySelector('.wh-define-btn');
    const truthBtn = popup.querySelector('.wh-truth-btn');
    const searchBtn = popup.querySelector('.wh-search-btn');
    
    // Show loading state
    defEl.style.display = 'block';
    defEl.innerHTML = '<span class="pn-spinner" style="width:12px;height:12px;border-width:1.5px;"></span> Defining…';
    defEl.className = 'wh-popup-definition wh-loading';
    defineBtn.disabled = true;
    defineBtn.textContent = 'Loading';
    if (truthBtn) truthBtn.disabled = true;
    if (searchBtn) searchBtn.disabled = true;

    // Grab the current summary text for context. Do NOT truncate — for 20-page
    // summaries the text can run ~14000 chars, and the old 2000-char cap was
    // causing the AI to claim "this term is not in the summary" for words
    // that actually appear near the end. The chat endpoint can comfortably
    // accept the full summary as a single user message.
    const currentSummaryText = summaries[currentPage] || summaryTextEl.innerText || '';

    // CRITICAL: explicitly tell the AI what language the word is in,
    // so it doesn't try to interpret a French/Spanish/etc. word as English.
    // The definition itself is always written in English (per user requirement).
    const prompt = `Here is the passage the reader is currently studying:\n\n"${currentSummaryText}"\n\nThe reader wants to understand the term "${word}". This term is in **${language}** — do NOT interpret it as English or as a misspelled English word. Treat it as a ${language} word/phrase. The term appears verbatim in the passage above — locate it and use its surrounding context to ground your explanation.\n\nIn 1-3 concise sentences, define "${word}":\n1. First, give its general meaning in ${language} (translate to English if it's not English).\n2. Then explain how it applies in the context of the passage above.\n\nCRITICAL RULES:\n- Write your definition IN ENGLISH (even though the word itself is ${language}).\n- If the word is a common noun, verb, or adjective, give its English translation first, then explain nuance.\n- If the word has no direct English equivalent (e.g. cultural terms, idioms), explain it in English.\n- Write plainly without markdown formatting. Do NOT start with the term itself.`;

    chrome.runtime.sendMessage({
      type: 'CHAT_PDF',
      url: pdfUrl,
      history: [{ role: 'user', content: prompt }],
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language: 'English'  // Force the response to be in English regardless of panel language
    }, (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        defEl.innerHTML = '! Could not fetch definition.';
        defEl.className = 'wh-popup-definition wh-error';
      } else {
        // Render the reply through inlineFormat to handle any markdown bold/italic
        // Sanitize LaTeX first so $\to$ etc. don't show as garbage
        const sanitizedReply = sanitizeLatex(res.reply);
        const rendered = inlineFormat(sanitizedReply
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;'));
        defEl.innerHTML = `<span class="wh-def-word">${word}</span> <span style="color:#71717a; font-size:11px; font-weight:500;">(${language})</span> — ${rendered}`;
        defEl.className = 'wh-popup-definition wh-loaded';
      }
      defineBtn.disabled = false;
      defineBtn.textContent = 'PDF Define';
      if (truthBtn) truthBtn.disabled = false;
      if (searchBtn) searchBtn.disabled = false;

      // Reposition popup since it grew — recalc position
      if (activePopupTargetRect && activeWordPopup) {
        const popupRect = popup.getBoundingClientRect();
        const parentEl = summaryTextEl.parentElement;
        const summaryParentRect = parentEl.getBoundingClientRect();
        const scrollTop = parentEl.scrollTop;
        const scrollLeft = parentEl.scrollLeft;

        let left = activePopupTargetRect.left - summaryParentRect.left + scrollLeft + (activePopupTargetRect.width / 2) - (popupRect.width / 2);
        let top = activePopupTargetRect.top - summaryParentRect.top + scrollTop - popupRect.height - 8;

        left = Math.max(4, Math.min(left, summaryParentRect.width - popupRect.width - 4));
        if (top < scrollTop) {
          top = activePopupTargetRect.bottom - summaryParentRect.top + scrollTop + 8;
        }

        popup.style.left = left + 'px';
        popup.style.top = top + 'px';
      }
    });
  }

  function checkTruthOfText(selectionText, popup) {
    const defEl = popup.querySelector('.wh-popup-definition');
    const truthBtn = popup.querySelector('.wh-truth-btn');
    const defineBtn = popup.querySelector('.wh-define-btn');
    const searchBtn = popup.querySelector('.wh-search-btn');
    
    // Show loading state
    defEl.style.display = 'block';
    defEl.innerHTML = '<span class="pn-spinner" style="width:12px;height:12px;border-width:1.5px;"></span> Verifying truth…';
    defEl.className = 'wh-popup-definition wh-loading';
    
    // Disable all actions during lookup
    if (truthBtn) {
      truthBtn.disabled = true;
      truthBtn.textContent = 'Verifying';
    }
    if (defineBtn) defineBtn.disabled = true;
    if (searchBtn) searchBtn.disabled = true;

    // Grab current page's generated summary as context
    const currentSummaryText = summaries[currentPage] || summaryTextEl.innerText || '';

    chrome.runtime.sendMessage({
      type: 'VERIFY_CLAIM',
      ollamaUrl,
      model: ollamaModel,
      claim: selectionText,
      claimLanguage: language,    // NEW: tell the AI what language the claim is in
      context: currentSummaryText,
      language: 'English'         // Force the AI's response to be in English
    }, (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        defEl.innerHTML = '! Could not verify claim.';
        defEl.className = 'wh-popup-definition wh-error';
      } else {
        // Sanitize LaTeX first so $\to$ etc. don't show as garbage
        const sanitizedReply = sanitizeLatex(res.reply);
        const rendered = inlineFormat(sanitizedReply
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;'));

        // Color mapping for different truth ratings: green, greener, yellow, red, redder
        const lowerReply = res.reply.toLowerCase();
        let ratingColor = '#fbbf24'; // default yellow
        if (lowerReply.includes('inaccurate')) {
          ratingColor = '#b91c1c'; // redder (dark red)
        } else if (lowerReply.includes('accurate')) {
          ratingColor = '#10b981'; // green (emerald)
        } else if (lowerReply.includes('true')) {
          ratingColor = '#22c55e'; // greener (vibrant green)
        } else if (lowerReply.includes('nuanced') || lowerReply.includes('context-dependent')) {
          ratingColor = '#fbbf24'; // yellow (amber)
        } else if (lowerReply.includes('false')) {
          ratingColor = '#ef4444'; // red (vibrant red)
        }

        // Colorize the rating prefix label if present in response
        let formattedReply = rendered;
        const ratingRegex = /^(Accurate|Nuanced\/Context-Dependent|Nuanced|Context-Dependent|Inaccurate|True|False)(:|\b)/i;
        if (ratingRegex.test(formattedReply)) {
          formattedReply = formattedReply.replace(ratingRegex, (match) => {
            return `<strong style="color: ${ratingColor}; font-weight: 700;">${match}</strong>`;
          });
        }

        defEl.innerHTML = `<span class="wh-def-word" style="color: ${ratingColor};">Fact Check:</span> ${formattedReply}`;
        defEl.className = 'wh-popup-definition wh-loaded';
      }
      
      if (truthBtn) {
        truthBtn.disabled = false;
        truthBtn.textContent = ' Is this true?';
      }
      if (defineBtn) defineBtn.disabled = false;
      if (searchBtn) searchBtn.disabled = false;

      // Reposition popup since it grew — recalc position
      if (activePopupTargetRect && activeWordPopup) {
        const popupRect = popup.getBoundingClientRect();
        const parentEl = summaryTextEl.parentElement;
        const summaryParentRect = parentEl.getBoundingClientRect();
        const scrollTop = parentEl.scrollTop;
        const scrollLeft = parentEl.scrollLeft;

        let left = activePopupTargetRect.left - summaryParentRect.left + scrollLeft + (activePopupTargetRect.width / 2) - (popupRect.width / 2);
        let top = activePopupTargetRect.top - summaryParentRect.top + scrollTop - popupRect.height - 8;

        left = Math.max(4, Math.min(left, summaryParentRect.width - popupRect.width - 4));
        if (top < scrollTop) {
          top = activePopupTargetRect.bottom - summaryParentRect.top + scrollTop + 8;
        }

        popup.style.left = left + 'px';
        popup.style.top = top + 'px';
      }
    });
  }

  // ===== POPUP "ALOUD" — speak the selected word/phrase via Piper TTS =====
  // Uses the panel's currently-selected voice for the current language.
  // One shared Audio element (popupAudioEl) — clicking Aloud on a new word
  // stops any previously-playing popup audio.
  function speakTextAloud(text, popup) {
    const aloudBtn = popup.querySelector('.wh-aloud-btn');
    if (!aloudBtn) return;

    // Stop any currently-playing popup audio
    if (popupAudioEl) {
      try { popupAudioEl.pause(); } catch (_) {}
      popupAudioEl = null;
    }

    // Show loading state
    const originalText = aloudBtn.textContent;
    aloudBtn.disabled = true;
    aloudBtn.textContent = 'Loading…';

    chrome.runtime.sendMessage({
      type: 'TTS_INLINE',
      text: text,
      language: language  // the panel's current language
    }, (res) => {
      aloudBtn.disabled = false;
      aloudBtn.textContent = originalText;

      if (chrome.runtime.lastError || !res || !res.success) {
        // Show error in the definition area (same place Define/Truth show results)
        const defEl = popup.querySelector('.wh-popup-definition');
        if (defEl) {
          defEl.style.display = 'block';
          defEl.innerHTML = '! Could not generate speech: ' + (res?.error || 'Connection lost');
          defEl.className = 'wh-popup-definition wh-error';
        }
        return;
      }

      try {
        // Decode base64 → ArrayBuffer → Blob URL → Audio
        const binaryString = atob(res.wavData);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const blob = new Blob([bytes.buffer], { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        popupAudioEl = audio;

        // Update button while playing
        aloudBtn.textContent = 'Playing…';
        audio.addEventListener('play', () => {
          aloudBtn.textContent = 'Playing…';
        });
        audio.addEventListener('ended', () => {
          aloudBtn.textContent = originalText;
          URL.revokeObjectURL(url);
          if (popupAudioEl === audio) popupAudioEl = null;
        });
        audio.addEventListener('error', () => {
          aloudBtn.textContent = originalText;
          URL.revokeObjectURL(url);
          if (popupAudioEl === audio) popupAudioEl = null;
        });

        audio.play().catch(err => {
          aloudBtn.textContent = originalText;
          URL.revokeObjectURL(url);
          if (popupAudioEl === audio) popupAudioEl = null;
          const defEl = popup.querySelector('.wh-popup-definition');
          if (defEl) {
            defEl.style.display = 'block';
            defEl.innerHTML = '! Playback failed: ' + err.message;
            defEl.className = 'wh-popup-definition wh-error';
          }
        });
      } catch (err) {
        const defEl = popup.querySelector('.wh-popup-definition');
        if (defEl) {
          defEl.style.display = 'block';
          defEl.innerHTML = '! Playback failed: ' + err.message;
          defEl.className = 'wh-popup-definition wh-error';
        }
      }
    });
  }

  function showSummaryLoading(msg) {
    summaryTextEl.className = 'pn-summary-text loading';
    summaryTextEl.innerHTML = `<span class="pn-spinner"></span> ${msg}`;
    const ttsBtn = shadow?.getElementById('pnTTS');
    if (ttsBtn) {
      ttsBtn.disabled = true;
      ttsBtn.classList.remove('playing');
    }
  }

  function showSummaryError(msg) {
    summaryTextEl.className = 'pn-summary-text error';
    summaryTextEl.textContent = '⚠ ' + msg;
    const ttsBtn = shadow?.getElementById('pnTTS');
    if (ttsBtn) {
      ttsBtn.disabled = true;
      ttsBtn.classList.remove('playing');
    }
    if (startBtn) {
      startBtn.disabled = false;
    }
  }

  function updateProgressBar() {
    if (!totalPages || !progressFill) return;
    const endPage = Math.min(currentPage + contextCount - 1, totalPages);
    const pct = Math.round((endPage / totalPages) * 100);
    const left = Math.max(0, totalPages - endPage);
    
    progressFill.style.width = pct + '%';
    percentLabel.textContent = pct + '%';
    pagesLeftLabel.textContent = left === 1 ? '1 page left' : `${left} pages left`;
  }

  // ===== OLLAMA STATUS =====
  function checkOllama() {
    chrome.runtime.sendMessage({ type: 'CHECK_OLLAMA', url: ollamaUrl }, (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        setOllamaStatus(false);
        return;
      }
      setOllamaStatus(true);
      const models = res.models || [];
      if (models.length > 0) {
        // Auto-select model if saved one exists
        const names = models.map(m => m.name);
        const match = names.find(n => n === ollamaModel || n.startsWith(ollamaModel));
        if (match) ollamaModel = match;
        modelLabel.textContent = ollamaModel;
      }
    });
  }

  function setOllamaStatus(connected) {
    statusDot.className = connected ? 'pn-dot connected' : 'pn-dot disconnected';
    statusLabel.textContent = connected ? 'Ollama connected' : 'Ollama offline';
  }

  // ===== SAVE PANEL BOUNDS =====
  function savePanelBounds() {
    const rect = panel.getBoundingClientRect();
    chrome.storage.local.set({
      panelLeft:   rect.left,
      panelTop:    rect.top,
      panelWidth:  rect.width,
      panelHeight: rect.height,
    });
  }

  // ===== DRAGGABLE PANEL (pointer capture) =====
  function makeDraggable(handle, element) {
    let ds = { active: false, sx: 0, sy: 0, sl: 0, st: 0 };

    handle.addEventListener('pointerdown', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
      e.preventDefault();
      handle.setPointerCapture(e.pointerId);
      const rect = element.getBoundingClientRect();
      element.style.right = 'auto';
      element.style.left  = rect.left + 'px';
      element.style.top   = rect.top  + 'px';
      ds = { active: true, sx: e.clientX, sy: e.clientY, sl: rect.left, st: rect.top };
      element.classList.add('dragging');
    });

    handle.addEventListener('pointermove', (e) => {
      if (!ds.active) return;
      element.style.left = (ds.sl + e.clientX - ds.sx) + 'px';
      element.style.top  = (ds.st + e.clientY - ds.sy) + 'px';
    });

    handle.addEventListener('pointerup', (e) => {
      if (!ds.active) return;
      handle.releasePointerCapture(e.pointerId);
      ds.active = false;
      element.classList.remove('dragging');
      savePanelBounds();
    });

    handle.addEventListener('pointercancel', () => {
      ds.active = false;
      element.classList.remove('dragging');
    });
  }

  // ===== RESIZABLE PANEL (pointer capture per handle) =====
  function makeResizable() {
    const handles = shadow.querySelectorAll('.pn-resize-handle');

    handles.forEach(handle => {
      let rs = { active: false };

      handle.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        handle.setPointerCapture(e.pointerId);
        const rect = panel.getBoundingClientRect();
        panel.style.right = 'auto';
        panel.style.left  = rect.left + 'px';
        panel.style.top   = rect.top  + 'px';
        panel.classList.add('resizing');
        rs = {
          active: true,
          dir: handle.dataset.dir,
          sx: e.clientX, sy: e.clientY,
          sw: rect.width, sh: rect.height,
          sl: rect.left,  st: rect.top,
        };
      });

      handle.addEventListener('pointermove', (e) => {
        if (!rs.active) return;
        const dx = e.clientX - rs.sx;
        const dy = e.clientY - rs.sy;
        const d  = rs.dir;

        if (d === 'r' || d === 'br' || d === 'tr') {
          panel.style.width  = Math.max(280, rs.sw + dx) + 'px';
        }
        if (d === 'l' || d === 'bl' || d === 'tl') {
          const nw = Math.max(280, rs.sw - dx);
          panel.style.width = nw + 'px';
          panel.style.left  = (rs.sl + rs.sw - nw) + 'px';
        }
        if (d === 'b' || d === 'br' || d === 'bl') {
          panel.style.height = Math.max(180, rs.sh + dy) + 'px';
        }
        if (d === 't' || d === 'tr' || d === 'tl') {
          const nh = Math.max(180, rs.sh - dy);
          panel.style.height = nh + 'px';
          panel.style.top    = (rs.st + rs.sh - nh) + 'px';
        }
      });

      handle.addEventListener('pointerup', (e) => {
        if (!rs.active) return;
        handle.releasePointerCapture(e.pointerId);
        rs.active = false;
        panel.classList.remove('resizing');
        savePanelBounds();
      });

      handle.addEventListener('pointercancel', () => {
        rs.active = false;
        panel.classList.remove('resizing');
      });
    });
  }

  function generateQuiz(chunkIndex, includeFocus = false, customStart = null, customEnd = null) {
    const startPage = customStart !== null ? customStart : chunkIndex * 20 + 1;
    const endPage = customEnd !== null ? customEnd : Math.min((chunkIndex + 1) * 20, totalPages);
    
    chrome.runtime.sendMessage({
      type: 'GENERATE_QUIZ',
      url: pdfUrl,
      startPage,
      endPage,
      includeFocus,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language
    }, (res) => {
      if (chrome.runtime.lastError) {
        console.warn('Quiz generation error:', chrome.runtime.lastError.message);
      }
      
      if (res && res.success) {
        generatedQuizzes[chunkIndex].status = 'ready';
        generatedQuizzes[chunkIndex].questions = res.questions;
        generatedQuizzes[chunkIndex].focusQuestions = res.focusQuestions || [];
        
        // Auto-open the quiz in the requested mode
        openQuizView(chunkIndex, includeFocus ? 'focus' : 'direct');
      } else {
        generatedQuizzes[chunkIndex].status = 'not_generated';
        alert('Quiz generation failed: ' + (res?.error || 'Unknown error'));
      }
      renderQuizList();
    });
  }

  function renderQuizList() {
    if (!chatShadow) return;
    const list = chatShadow.getElementById('qzList');
    if (!list) return;

    if (!totalPages) {
      list.innerHTML = '<div class="qz-empty">Open a PDF to see quizzes</div>';
      return;
    }

    let html = '';
    const numChunks = Math.ceil(totalPages / 20);
    for (let i = 0; i < numChunks; i++) {
      const q = generatedQuizzes[i];
      if (!q) continue;
      
      const start = i * 20 + 1;
      const end = Math.min((i + 1) * 20, totalPages);
      const title = `Quiz ${i + 1} (Pages ${start}-${end})`;
      
      let statusHtml = '';
      if (q.status === 'not_generated') {
        statusHtml = `
          <div style="display:flex; gap:6px; flex:1;">
            <button class="qz-btn qz-gen-btn" data-chunk="${i}" data-mode="direct" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #3b82f6, #2563eb);">Gen Quiz</button>
            <button class="qz-btn qz-gen-btn" data-chunk="${i}" data-mode="focus" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #6366f1, #818cf8);">Gen Focus + Quiz</button>
          </div>
        `;
      } else if (q.status === 'generating') {
        statusHtml = `<div style="font-size:11px; color:#fbbf24; display:flex; align-items:center; gap:4px;"><span class="pn-spinner" style="width:10px; height:10px; border-width:1px;"></span> Generating...</div>`;
      } else if (q.status === 'ready') {
        statusHtml = `
          <div style="display:flex; gap:6px; flex:1;">
            <button class="qz-btn qz-take-btn" data-chunk="${i}" data-mode="direct" style="flex:1; padding: 6px 4px; font-size:11px;">Take Quiz</button>
            <button class="qz-btn qz-take-btn qz-focus-mode" data-chunk="${i}" data-mode="focus" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #6366f1, #818cf8);">Focus + Quiz</button>
          </div>
        `;
      } else if (q.status === 'grading') {
        statusHtml = `<div style="font-size:11px; color:#fbbf24; display:flex; align-items:center; gap:4px;"><span class="pn-spinner" style="width:10px; height:10px; border-width:1px;"></span> Grading...</div>`;
      } else if (q.status === 'graded') {
        statusHtml = `<button class="qz-btn qz-view-btn" data-chunk="${i}" style="background: linear-gradient(135deg, #10b981, #059669);">View Grade</button>`;
      }

      html += `
        <div class="qz-item">
          <div class="qz-item-title">${title}</div>
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
            ${statusHtml}
          </div>
        </div>
      `;
    }
    // Render custom quizzes
    customQuizKeys.forEach(key => {
      const q = generatedQuizzes[key];
      if (!q) return;
      const parts = key.split('_');
      const cStart = parts[1], cEnd = parts[2];
      const title = `Custom Quiz (Pages ${cStart}-${cEnd})`;

      let statusHtml = '';
      if (q.status === 'not_generated') {
        statusHtml = `
          <div style="display:flex; gap:6px; flex:1;">
            <button class="qz-btn qz-gen-btn" data-chunk="${key}" data-mode="direct" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #3b82f6, #2563eb);">Gen Quiz</button>
            <button class="qz-btn qz-gen-btn" data-chunk="${key}" data-mode="focus" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #6366f1, #818cf8);">Gen Focus + Quiz</button>
          </div>
        `;
      } else if (q.status === 'generating') {
        statusHtml = `<div style="font-size:11px; color:#fbbf24; display:flex; align-items:center; gap:4px;"><span class="pn-spinner" style="width:10px; height:10px; border-width:1px;"></span> Generating...</div>`;
      } else if (q.status === 'ready') {
        statusHtml = `
          <div style="display:flex; gap:6px; flex:1;">
            <button class="qz-btn qz-take-btn" data-chunk="${key}" data-mode="direct" style="flex:1; padding: 6px 4px; font-size:11px;">Take Quiz</button>
            <button class="qz-btn qz-take-btn qz-focus-mode" data-chunk="${key}" data-mode="focus" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #6366f1, #818cf8);">Focus + Quiz</button>
          </div>
        `;
      } else if (q.status === 'grading') {
        statusHtml = `<div style="font-size:11px; color:#fbbf24; display:flex; align-items:center; gap:4px;"><span class="pn-spinner" style="width:10px; height:10px; border-width:1px;"></span> Grading...</div>`;
      } else if (q.status === 'graded') {
        statusHtml = `<button class="qz-btn qz-view-btn" data-chunk="${key}" style="background: linear-gradient(135deg, #10b981, #059669);">View Grade</button>`;
      }

      html += `
        <div class="qz-item" style="border-left: 3px solid #f59e0b;">
          <div class="qz-item-title">${title}</div>
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
            ${statusHtml}
          </div>
        </div>
      `;
    });

    // Custom Range Input
    html += `
      <div class="qz-item" style="border-left: 3px solid #f59e0b; background: rgba(245, 158, 11, 0.05);">
        <div class="qz-item-title" style="color:#f59e0b;">Custom Range Quiz</div>
        <div style="display:flex; gap:6px; align-items:center; margin-top:8px;">
          <span style="font-size:11px; color:#a1a1aa;">Pages</span>
          <input type="number" id="qzCustomFrom" min="1" max="${totalPages}" value="1" style="width:50px; padding:4px 6px; border-radius:6px; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.05); color:#f4f4f5; font-size:12px; text-align:center;">
          <span style="font-size:11px; color:#71717a;">to</span>
          <input type="number" id="qzCustomTo" min="1" max="${totalPages}" value="${totalPages}" style="width:50px; padding:4px 6px; border-radius:6px; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.05); color:#f4f4f5; font-size:12px; text-align:center;">
        </div>
        <div style="display:flex; gap:6px; margin-top:8px;">
          <button class="qz-btn" id="qzCustomGen" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #f59e0b, #d97706);">Gen Quiz</button>
          <button class="qz-btn" id="qzCustomGenFocus" style="flex:1; padding: 6px 4px; font-size:11px; background: linear-gradient(135deg, #6366f1, #818cf8);">Gen Focus + Quiz</button>
        </div>
      </div>
    `;

    list.innerHTML = html || '<div class="qz-empty">No quizzes generated.</div>';

    // Attach listeners for regular + custom quizzes
    list.querySelectorAll('.qz-gen-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const chunkKey = btn.dataset.chunk;
        const mode = btn.dataset.mode || 'direct';
        const isCustom = chunkKey.startsWith('c_');
        const idx = isCustom ? chunkKey : parseInt(chunkKey);
        generatedQuizzes[idx].status = 'generating';
        renderQuizList();
        if (isCustom) {
          const parts = chunkKey.split('_');
          generateQuiz(idx, mode === 'focus', parseInt(parts[1]), parseInt(parts[2]));
        } else {
          generateQuiz(idx, mode === 'focus');
        }
      });
    });

    list.querySelectorAll('.qz-take-btn, .qz-view-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const chunkKey = btn.dataset.chunk;
        const mode = btn.dataset.mode || 'direct';
        const idx = chunkKey.startsWith('c_') ? chunkKey : parseInt(chunkKey);
        openQuizView(idx, mode);
      });
    });

    // Custom range buttons
    const customGenBtn = list.querySelector('#qzCustomGen');
    const customGenFocusBtn = list.querySelector('#qzCustomGenFocus');
    if (customGenBtn) {
      customGenBtn.addEventListener('click', () => {
        const from = parseInt(list.querySelector('#qzCustomFrom').value);
        const to = parseInt(list.querySelector('#qzCustomTo').value);
        if (!from || !to || from > to || from < 1 || to > totalPages) {
          alert('Invalid page range.');
          return;
        }
        const key = `c_${from}_${to}`;
        if (!customQuizKeys.includes(key)) customQuizKeys.push(key);
        generatedQuizzes[key] = { status: 'generating' };
        renderQuizList();
        generateQuiz(key, false, from, to);
      });
    }
    if (customGenFocusBtn) {
      customGenFocusBtn.addEventListener('click', () => {
        const from = parseInt(list.querySelector('#qzCustomFrom').value);
        const to = parseInt(list.querySelector('#qzCustomTo').value);
        if (!from || !to || from > to || from < 1 || to > totalPages) {
          alert('Invalid page range.');
          return;
        }
        const key = `c_${from}_${to}`;
        if (!customQuizKeys.includes(key)) customQuizKeys.push(key);
        generatedQuizzes[key] = { status: 'generating' };
        renderQuizList();
        generateQuiz(key, true, from, to);
      });
    }
  }

  function openQuizView(chunkIndex, mode = 'direct') {
    const q = generatedQuizzes[chunkIndex];
    if (!q) return;

    activeQuizChunk = chunkIndex;
    const isCustom = typeof chunkIndex === 'string' && chunkIndex.startsWith('c_');
    let start, end, titleText;
    if (isCustom) {
      const parts = chunkIndex.split('_');
      start = parseInt(parts[1]);
      end = parseInt(parts[2]);
      titleText = `Custom Quiz (Pages ${start}-${end})`;
    } else {
      start = chunkIndex * 20 + 1;
      end = Math.min((chunkIndex + 1) * 20, totalPages);
      titleText = `Quiz ${chunkIndex + 1} (Pages ${start}-${end})`;
    }
    
    chatShadow.getElementById('qzList').style.display = 'none';
    chatShadow.getElementById('qzView').style.display = 'flex';
    
    chatShadow.getElementById('qzViewTitle').textContent = titleText;
    
    const submitBtn = chatShadow.getElementById('qzSubmit');
    const resultDiv = chatShadow.getElementById('qzResult');
    const contentDiv = chatShadow.getElementById('qzContent');

    if (q.status === 'ready') {
      const showFocus = (mode === 'focus' && q.focusQuestions && q.focusQuestions.length > 0);

      // Step 1: Focus Questions (conditionally hidden)
      let focusHtml = `
        <div id="qzFocusContainer" style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 12px; padding: 16px; margin-bottom: 20px; display: ${showFocus ? 'block' : 'none'};">
          <div style="font-weight: 700; color: #818cf8; margin-bottom: 12px; font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em;">Reading Focus Questions</div>
          <div style="font-size: 13px; color: #a1a1aa; margin-bottom: 16px; line-height: 1.5;">Keep these two questions in mind while you read the text to help you prepare for the quiz.</div>
          <div style="display: flex; flex-direction: column; gap: 10px;">
      `;
      
      const fQs = q.focusQuestions || [];
      fQs.forEach((fq, i) => {
        focusHtml += `
          <div style="background: rgba(255, 255, 255, 0.03); border-left: 3px solid #818cf8; padding: 12px; border-radius: 4px; font-size: 14px; line-height: 1.5; font-weight: 500;">
            ${fq}
          </div>
        `;
      });
      
      focusHtml += `
          </div>
          <button id="qzStartActual" class="qz-btn" style="margin-top: 20px; width: 100%; background: linear-gradient(135deg, #6366f1, #818cf8);">I'm done reading, take the quiz</button>
        </div>
      `;

      // Step 2: The Quiz Content
      let quizHtml = `<div id="qzActualContent" style="display: ${showFocus ? 'none' : 'block'};">`;
      if (Array.isArray(q.questions)) {
        q.questions.forEach((question, index) => {
          quizHtml += `<div class="qz-mcq" style="margin-bottom: 20px;">
            <div style="font-weight: 600; margin-bottom: 12px; font-size:14px;">${index + 1}. ${question.question}</div>
            <div style="display: flex; flex-direction: column; gap: 8px;">`;
          if (Array.isArray(question.options)) {
            question.options.forEach((opt, optIndex) => {
              quizHtml += `<label style="display: flex; align-items: flex-start; gap: 8px; cursor: pointer; background: rgba(255,255,255,0.03); padding: 10px; border-radius: 6px; font-size: 13px; transition: background 0.2s;">
                <input type="radio" name="q${index}" value="${optIndex}" style="margin-top:2px;">
                <span>${opt}</span>
              </label>`;
            });
          }
          quizHtml += `</div></div>`;
        });
      } else {
        quizHtml = '<div style="color:#ef4444;">Error: Quiz format invalid. Please try generating again.</div>';
      }
      quizHtml += '</div>';
      
      contentDiv.innerHTML = focusHtml + quizHtml;
      contentDiv.style.display = 'block';
      submitBtn.style.display = showFocus ? 'none' : 'block';
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit Answers';
      resultDiv.style.display = 'none';

      // Event listener for the "take the quiz" button
      const startBtn = chatShadow.getElementById('qzStartActual');
      if (startBtn) {
        startBtn.addEventListener('click', () => {
          chatShadow.getElementById('qzFocusContainer').style.display = 'none';
          chatShadow.getElementById('qzActualContent').style.display = 'block';
          submitBtn.style.display = 'block';
        });
      }
    } else if (q.status === 'graded') {
      contentDiv.style.display = 'none';
      submitBtn.style.display = 'none';
      resultDiv.style.display = 'block';
      resultDiv.innerHTML = q.grading;
    }
  }

  // ===== PURPOSE TAB LOGIC =====
  let purposeData = null; // { questions: string }

  function loadPurpose() {
    if (!chatShadow) return;
    const welcome = chatShadow.getElementById('prWelcome');
    const content = chatShadow.getElementById('prContent');
    const questionsEl = chatShadow.getElementById('prQuestions');

    if (!welcome || !content) return;

    if (purposeData) {
      welcome.style.display = 'none';
      content.style.display = 'flex';
      renderPurposeQuestions(purposeData.questions);
    } else {
      welcome.style.display = 'block';
      content.style.display = 'none';
    }
  }

  function runPurposeGeneration() {
    if (!chatShadow) return;
    const welcome = chatShadow.getElementById('prWelcome');
    const content = chatShadow.getElementById('prContent');
    const genBtn = chatShadow.getElementById('prGenerate');
    const refreshBtn = chatShadow.getElementById('prRefresh');

    genBtn.disabled = true;
    genBtn.innerHTML = `<span class="pn-spinner" style="width:12px; height:12px; border-width:1px;"></span> Analyzing Document...`;
    refreshBtn.disabled = true;

    chrome.runtime.sendMessage({
      type: 'GENERATE_PURPOSE',
      url: pdfUrl,
      ollamaUrl,
      model: ollamaModel,
      genre: bookGenre,
      language
    }, (res) => {
      genBtn.disabled = false;
      genBtn.textContent = 'Generate Purpose Questions';
      refreshBtn.disabled = false;

      if (res && res.success) {
        purposeData = { questions: res.questions };
        if (welcome) welcome.style.display = 'none';
        if (content) content.style.display = 'flex';
        renderPurposeQuestions(res.questions);
      } else {
        alert('Failed to generate purpose questions: ' + (res?.error || 'Unknown error'));
      }
    });
  }

  function renderPurposeQuestions(text) {
    const questionsEl = chatShadow.getElementById('prQuestions');
    if (!questionsEl) return;

    let questions = [];
    try {
      // Clean up potential markdown code blocks
      let rawJson = text.trim();
      if (rawJson.startsWith('```json')) {
        rawJson = rawJson.replace(/^```json/, '').replace(/```$/, '').trim();
      } else if (rawJson.startsWith('```')) {
        rawJson = rawJson.replace(/^```/, '').replace(/```$/, '').trim();
      }
      questions = JSON.parse(rawJson);
    } catch (e) {
      // Fallback if parsing fails — split by lines
      questions = text.split('\n')
        .map(l => l.replace(/^\d+\.\s*/, '').replace(/^-\s*/, '').trim())
        .filter(l => l.length > 10)
        .slice(0, 3);
    }
    
    let html = '';
    let questionCount = 0;
    
    questions.forEach(qText => {
      if (questionCount >= 3) return;
      questionCount++;
      
      // Use markdownToHTML for the content
      const formatted = markdownToHTML(qText);

      html += `
        <div style="background: rgba(129, 140, 248, 0.08); border: 1px solid rgba(129, 140, 248, 0.2); border-radius: 14px; padding: 18px; position: relative; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.2);">
          <div style="position: absolute; top: -8px; left: -8px; font-size: 44px; opacity: 0.08; color: #818cf8; pointer-events: none; font-weight: 800; font-family: serif;">${questionCount}</div>
          <div class="pr-question-body" style="font-size: 14px; font-weight: 500; line-height: 1.6; color: #e0e7ff; position: relative; z-index: 1;">
            ${formatted}
          </div>
        </div>
      `;
    });

    if (questionCount === 0) {
      html = `<div style="color: #a1a1aa; font-style: italic; text-align: center; padding: 20px;">AI returned an unexpected format. Try regenerating.</div>`;
    }

    questionsEl.innerHTML = html;
  }

  // ===== GEMINI TEXT TO SPEECH PLAYBACK =====
  // Single button handler — state machine:
  //   - If TTS disabled:        no-op
  //   - If currently loading:   no-op (wait for current load)
  //   - If currently playing:   PAUSE (save position)
  //   - If paused on this page: RESUME from saved position
  //   - Otherwise:              START (fetch or use cached TTS, play from start or saved position)
  async function handleTTSButtonClick() {
    if (ttsLoading || !ttsEnabled) return;

    if (ttsPlaying) {
      pauseAudio();
      return;
    }

    // Either resume (audio already loaded for this page) or start fresh
    await startTTSPlayback();
  }

  // Pause audio and remember the current playback position for this page.
  function pauseAudio() {
    if (!ttsAudioElement || !ttsPlaying) return;

    const pos = ttsAudioElement.currentTime || 0;
    if (pos > 0) {
      pageResumePositions[currentPage] = pos;
    }

    ttsAudioElement.pause();
    ttsPlaying = false;
    ttsPaused = true;
    ttsIntentActive = false;     // user explicitly paused — don't auto-start on navigation
    autoAdvanceTarget = null;    // clear any pending auto-start
    stopProgressUpdater();

    const audioPanel = shadow.getElementById('pnAudioControls');
    if (audioPanel) audioPanel.classList.remove('is-playing');

    updateTTSButtonLabel();
  }

  // Called when navigating to a different page — pauses audio without
  // discarding the audio element, and saves the resume position so the
  // user can pick up where they left off if they return to that page.
  // `forPage` is the page whose position should be saved (defaults to currentPage).
  function pauseAudioForNavigation(forPage = currentPage) {
    if (!ttsAudioElement) return;

    if (ttsPlaying) {
      const pos = ttsAudioElement.currentTime || 0;
      if (pos > 0) {
        pageResumePositions[forPage] = pos;
      }
      ttsAudioElement.pause();
    }

    ttsPlaying = false;
    ttsPaused = false; // reset — paused state is per-page, tracked via pageResumePositions
    stopProgressUpdater();

    const audioPanel = shadow?.getElementById('pnAudioControls');
    if (audioPanel) audioPanel.classList.remove('is-playing');
  }

  // Update the TTS button label / disabled state based on the current
  // ttsEnabled / ttsPlaying / ttsPaused / pageResumePositions state.
  function updateTTSButtonLabel() {
    const ttsBtn = shadow?.getElementById('pnTTS');
    if (!ttsBtn) return;

    if (!ttsEnabled) {
      ttsBtn.disabled = true;
      ttsBtn.textContent = '🔇 TTS Off';
      ttsBtn.title = 'TTS is disabled — enable the TTS toggle to play audio';
      ttsBtn.classList.remove('playing');
      return;
    }

    // While loading, the loading handler manages the label
    if (ttsLoading) return;

    ttsBtn.disabled = false;

    if (ttsPlaying) {
      ttsBtn.textContent = '⏸ Pause';
      ttsBtn.title = 'Pause audio';
      ttsBtn.classList.add('playing');
    } else if (pageResumePositions[currentPage] != null) {
      // There's a saved position for this page → show Resume
      ttsBtn.textContent = '▶ Resume';
      ttsBtn.title = 'Resume from where you left off on this page';
      ttsBtn.classList.remove('playing');
    } else {
      ttsBtn.textContent = '▶ Play';
      ttsBtn.title = 'Play summary audio';
      ttsBtn.classList.remove('playing');
    }
  }

  // Start (or resume) TTS playback on the current page.
  // If audio is already loaded for this page, resume from the saved position (or 0).
  // Otherwise, fetch from the background (which may have it cached) and play.
  async function startTTSPlayback() {
    if (!ttsEnabled) return;

    const text = summaries[currentPage] || summaryTextEl.innerText;
    if (!text || text.trim().startsWith('Press Start') || text.trim().startsWith('Summarizing')) {
      return;
    }

    const ttsBtn = shadow.getElementById('pnTTS');

    // Fast path: audio is already loaded for this page → just resume from saved position.
    if (ttsAudioBuffer && currentPageForAudio === currentPage && ttsAudioElement) {
      const resumePos = pageResumePositions[currentPage] || 0;
      // Make sure controls panel is visible
      const controls = shadow.getElementById('pnAudioControls');
      if (controls) controls.style.display = 'block';
      // Restore scrubber max/value if needed
      const scrubber = shadow.getElementById('pnAudioScrubber');
      if (scrubber && ttsAudioDuration) {
        scrubber.max = Math.floor(ttsAudioDuration);
        scrubber.value = Math.floor(resumePos);
      }
      const durationLabel = shadow.getElementById('pnAudioDuration');
      if (durationLabel) durationLabel.textContent = formatTime(ttsAudioDuration);
      playFromOffset(resumePos);
      triggerAudioPrefetch(currentPage);
      return;
    }

    // Slow path: fetch TTS from background (cached → fast, otherwise Gemini API call).
    const cleanedText = cleanMarkdownForTTS(text);
    if (!cleanedText) return;

    ttsLoading = true;
    if (ttsBtn) {
      ttsBtn.disabled = true;
      ttsBtn.textContent = 'Loading...';
      ttsBtn.classList.remove('playing');
    }

    chrome.runtime.sendMessage({
      type: 'GENERATE_TTS',
      url: pdfUrl,
      pageNum: currentPage,
      text: cleanedText
    }, async (res) => {
      ttsLoading = false;

      // If TTS was disabled during loading, abort
      if (!ttsEnabled) {
        updateTTSButtonLabel();
        return;
      }

      if (chrome.runtime.lastError || !res || !res.success) {
        if (ttsBtn) ttsBtn.disabled = false;
        alert('Failed to generate speech: ' + (res?.error || 'Connection lost'));
        updateTTSButtonLabel();
        return;
      }

      try {
        const binaryString = atob(res.wavData);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        await playWavArrayBuffer(bytes.buffer);
        triggerAudioPrefetch(currentPage);
      } catch (err) {
        if (ttsBtn) ttsBtn.disabled = false;
        alert('Failed to play audio: ' + err.message);
        updateTTSButtonLabel();
      }
    });
  }

  async function playWavArrayBuffer(arrayBuffer) {
    // Don't fully stop — just pause any current playback while we swap sources
    if (ttsAudioElement) {
      ttsAudioElement.pause();
    }
    ttsPlaying = false;
    stopProgressUpdater();

    // Revoke any previous blob URL to prevent memory leaks
    if (ttsAudioBuffer) {
      URL.revokeObjectURL(ttsAudioBuffer);
      ttsAudioBuffer = null;
    }

    try {
      // Create a Blob URL from the WAV ArrayBuffer.
      // We use an HTMLAudioElement instead of AudioBufferSourceNode because
      // HTMLAudioElement supports preservesPitch=true, which lets us change
      // playbackRate WITHOUT shifting pitch (no chipmunk at 1.5x / 2x speed).
      const blob = new Blob([arrayBuffer], { type: 'audio/wav' });
      const url = URL.createObjectURL(blob);

      // Reuse a single Audio element across plays (avoids leaking elements)
      if (!ttsAudioElement) {
        ttsAudioElement = new Audio();
        // CRITICAL: preserve pitch when playbackRate changes. This is the fix
        // for the chipmunk effect at higher speeds.
        ttsAudioElement.preservesPitch = true;
        ttsAudioElement.mozPreservesPitch = true;
        ttsAudioElement.webkitPreservesPitch = true;
        // Use a flag to distinguish natural completion from manual stop/seek.
        // The 'ended' event only fires on natural completion, but we add a
        // guard so any race conditions don't double-fire handleAudioFinished.
        let finishFired = false;
        ttsAudioElement.addEventListener('ended', () => {
          if (finishFired) return;
          finishFired = true;
          // Reset the guard after a tick so future loads can fire again
          setTimeout(() => { finishFired = false; }, 50);
          // Only treat as "finished" if we were actually playing (not paused/stopped)
          if (ttsPlaying) {
            handleAudioFinished();
          }
        });
        ttsAudioElement.addEventListener('error', (e) => {
          console.error('Audio element error:', e);
        });
      }

      ttsAudioElement.src = url;
      ttsAudioElement.playbackRate = ttsSpeed;
      ttsAudioBuffer = url;            // cache the URL so the fast-path works
      currentPageForAudio = currentPage;

      // Wait for metadata so we know the duration
      await new Promise((resolve, reject) => {
        const onLoaded = () => {
          ttsAudioElement.removeEventListener('loadedmetadata', onLoaded);
          ttsAudioElement.removeEventListener('error', onError);
          resolve();
        };
        const onError = (e) => {
          ttsAudioElement.removeEventListener('loadedmetadata', onLoaded);
          ttsAudioElement.removeEventListener('error', onError);
          reject(new Error('Failed to load audio metadata.'));
        };
        ttsAudioElement.addEventListener('loadedmetadata', onLoaded);
        ttsAudioElement.addEventListener('error', onError);
      });

      ttsAudioDuration = ttsAudioElement.duration;

      const durationLabel = shadow.getElementById('pnAudioDuration');
      if (durationLabel) {
        durationLabel.textContent = formatTime(ttsAudioDuration);
      }

      const scrubber = shadow.getElementById('pnAudioScrubber');
      if (scrubber) {
        scrubber.max = Math.floor(ttsAudioDuration);
        // If there's a saved resume position, scrubber starts there
        const resumePos = pageResumePositions[currentPage] || 0;
        scrubber.value = Math.floor(resumePos);
      }

      // Play from saved resume position if any, else from 0
      const resumePos = pageResumePositions[currentPage] || 0;
      playFromOffset(resumePos);

      const controls = shadow.getElementById('pnAudioControls');
      if (controls) controls.style.display = 'block';
    } catch (e) {
      console.error("playWavArrayBuffer error", e);
      throw new Error("Could not play audio: " + e.message);
    }
  }

  // Begin playback from a specific offset (seconds). Always restarts the
  // progress updater so the scrubber never freezes after a seek/restart.
  function playFromOffset(offsetSeconds) {
    if (!ttsAudioElement || !ttsAudioBuffer) return;

    // Jump to the requested position (seek)
    try {
      ttsAudioElement.currentTime = offsetSeconds;
    } catch (e) {
      // Setting currentTime can fail if metadata isn't loaded yet — ignore.
    }
    // Always sync the rate (in case speed was changed before audio loaded)
    ttsAudioElement.playbackRate = ttsSpeed;
    ttsPlaying = true;
    ttsPaused = false;
    ttsIntentActive = true;      // user wants TTS playing — auto-start on navigation

    const playPromise = ttsAudioElement.play();
    if (playPromise && typeof playPromise.catch === 'function') {
      playPromise.catch(err => {
        // Autoplay restrictions can cause play() to reject — log and move on.
        console.error('Audio play() rejected:', err);
      });
    }

    // CRITICAL FIX: always restart the progress updater so the scrubber
    // tracks correctly after a stop→seek→restart sequence.
    startProgressUpdater();

    const audioPanel = shadow.getElementById('pnAudioControls');
    if (audioPanel) audioPanel.classList.add('is-playing');

    updateTTSButtonLabel();
  }

  // Called when audio naturally reaches the end (the 'ended' event fires).
  function handleAudioFinished() {
    ttsPlaying = false;
    ttsPaused = false;
    // Clear resume position for this page since it finished naturally
    delete pageResumePositions[currentPage];

    stopProgressUpdater();

    const audioPanel = shadow?.getElementById('pnAudioControls');
    if (audioPanel) audioPanel.classList.remove('is-playing');

    const scrubber = shadow.getElementById('pnAudioScrubber');
    if (scrubber) scrubber.value = 0;
    const curTimeLabel = shadow.getElementById('pnAudioCurrentTime');
    if (curTimeLabel) curTimeLabel.textContent = '0:00';

    // Auto-advance to next page if enabled
    if (ttsAutoAdvance) {
      const nextP = Math.min(currentPage + contextCount, totalPages);
      if (nextP > currentPage) {
        // Keep ttsIntentActive true so goToPage sets autoAdvanceTarget,
        // which triggers auto-start on the new page.
        autoAdvanceTarget = nextP;
        goToPage(nextP);
      } else {
        ttsIntentActive = false;
        updateTTSButtonLabel();
      }
    } else {
      ttsIntentActive = false;
      updateTTSButtonLabel();
    }
  }

  // Hard stop — pause audio, optionally reset UI. Does NOT save resume
  // position (used by Reset, TTS-disable, and other "fully stop" cases).
  function stopAudio(resetUI = true) {
    if (ttsAudioElement) {
      ttsAudioElement.pause();
      if (resetUI) {
        try { ttsAudioElement.currentTime = 0; } catch (e) {}
      }
    }
    ttsPlaying = false;
    ttsPaused = false;
    ttsIntentActive = false;
    autoAdvanceTarget = null;
    stopProgressUpdater();

    const audioPanel = shadow?.getElementById('pnAudioControls');
    if (audioPanel) audioPanel.classList.remove('is-playing');

    if (resetUI) {
      const scrubber = shadow.getElementById('pnAudioScrubber');
      if (scrubber) scrubber.value = 0;
      const curTimeLabel = shadow.getElementById('pnAudioCurrentTime');
      if (curTimeLabel) curTimeLabel.textContent = '0:00';
    }

    updateTTSButtonLabel();
  }

  function changeTTSSpeed(newSpeed) {
    ttsSpeed = parseFloat(newSpeed);

    // Update playback rate on the audio element. Because preservesPitch=true
    // on the element, this changes speed WITHOUT shifting pitch (no chipmunk).
    if (ttsAudioElement) {
      ttsAudioElement.playbackRate = ttsSpeed;
    }
  }

  function startProgressUpdater() {
    stopProgressUpdater();
    ttsProgressInterval = setInterval(() => {
      if (!ttsPlaying || !ttsAudioDuration || !ttsAudioElement) return;

      const currentTime = ttsAudioElement.currentTime;

      const scrubber = shadow.getElementById('pnAudioScrubber');
      if (scrubber) {
        scrubber.value = Math.floor(currentTime);
      }

      const curTimeLabel = shadow.getElementById('pnAudioCurrentTime');
      if (curTimeLabel) {
        curTimeLabel.textContent = formatTime(currentTime);
      }
    }, 250);
  }

  function stopProgressUpdater() {
    if (ttsProgressInterval) {
      clearInterval(ttsProgressInterval);
      ttsProgressInterval = null;
    }
  }

  function formatTime(secs) {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  }

  function triggerAudioPrefetch(fromPage) {
    // Don't prefetch if TTS is disabled — saves API credits
    if (!ttsEnabled) return;

    // Buffer strictly ONE generation ahead (current + buffer = 2 generations total)
    const nextPage = fromPage + contextCount;
    if (nextPage <= totalPages && summaries[nextPage]) {
      chrome.runtime.sendMessage({
        type: 'PREFETCH_TTS',
        url: pdfUrl,
        pageNum: nextPage,
        text: cleanMarkdownForTTS(summaries[nextPage])
      });
    }
  }

  function cleanMarkdownForTTS(text) {
    return sanitizeLatex(text)
      // Remove headers
      .replace(/^#+\s+/gm, '')
      // Remove bold/italic markers
      .replace(/\*\*\*(.+?)\*\*\*/g, '$1')
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/__(.+?)__/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/_(.+?)_/g, '$1')
      // Remove inline code
      .replace(/`([^`]+?)`/g, '$1')
      // Remove narrative/meaning block headers if any
      .replace(/narrative:/gi, '')
      .replace(/meaning & reflection:/gi, '')
      .replace(/narrative/gi, '')
      .replace(/meaning & reflection/gi, '')
      // Remove list bullets
      .replace(/^\s*[-*•]\s+/gm, '')
      .replace(/^\s*\d+\.\s+/gm, '')
      // Remove blockquotes/excessive whitespace
      .replace(/^\s*>\s+/gm, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Keep background service worker alive during long generations
  setInterval(() => {
    if (pdfReady) {
      chrome.runtime.sendMessage({ type: 'PING' }, () => {
        if (chrome.runtime.lastError) {} // Ignore
      });
    }
  }, 20000);
})();
