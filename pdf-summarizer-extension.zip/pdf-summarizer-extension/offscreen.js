// PDF Summarizer — Offscreen Document
// Runs PDF.js to extract text from PDFs (needs DOM context).

import * as pdfjsLib from './lib/pdf.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc = './lib/pdf.worker.mjs';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PARSE_PDF_URL') {
    parsePDFFromUrl(msg.url, msg.cbId);
  } else if (msg.type === 'PARSE_PDF_DATA') {
    parsePDF(msg.data, msg.cbId);
  }
});

async function parsePDFFromUrl(url, cbId) {
  try {
    let pdf;
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Failed to fetch PDF: ${response.status}`);
      const arrayBuffer = await response.arrayBuffer();
      const uint8 = new Uint8Array(arrayBuffer);
      pdf = await pdfjsLib.getDocument({ data: uint8 }).promise;
    } catch (fetchErr) {
      // Fallback: let PDF.js attempt direct URL loading
      pdf = await pdfjsLib.getDocument(url).promise;
    }

    const pageCount = pdf.numPages;
    const pages = {};

    for (let i = 1; i <= pageCount; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      pages[i] = textContent.items.map(item => item.str).join(' ').trim();
    }

    chrome.runtime.sendMessage({
      type: 'PDF_PARSED',
      success: true,
      pageCount,
      pages,
      cbId
    }).catch(() => {});

  } catch (err) {
    chrome.runtime.sendMessage({
      type: 'PDF_PARSED',
      success: false,
      error: err.message,
      cbId
    }).catch(() => {});
  }
}

async function parsePDF(dataArray, cbId) {
  try {
    const uint8 = new Uint8Array(dataArray);
    const pdf = await pdfjsLib.getDocument({ data: uint8 }).promise;
    const pageCount = pdf.numPages;
    const pages = {};

    for (let i = 1; i <= pageCount; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      pages[i] = textContent.items.map(item => item.str).join(' ').trim();
    }

    chrome.runtime.sendMessage({
      type: 'PDF_PARSED',
      success: true,
      pageCount,
      pages,
      cbId
    });

  } catch (err) {
    chrome.runtime.sendMessage({
      type: 'PDF_PARSED',
      success: false,
      error: err.message,
      cbId
    });
  }
}
