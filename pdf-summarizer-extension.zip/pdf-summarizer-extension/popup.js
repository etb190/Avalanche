// PDF Summarizer - Popup Script

const ollamaUrlInput   = document.getElementById('ollamaUrl');
const modelInput       = document.getElementById('modelInput');
const modelList        = document.getElementById('modelList');
const genreSelect      = document.getElementById('genreSelect');
const langSelect       = document.getElementById('langSelect');
const statusDot        = document.getElementById('statusDot');
const statusText       = document.getElementById('statusText');
const refreshBtn       = document.getElementById('refreshModels');

// TTS UI (Piper only — Gemini removed)
const piperSection     = document.getElementById('piperSection');
const piperUrl         = document.getElementById('piperUrl');
const piperVoiceSelect = document.getElementById('piperVoiceSelect');
const piperVoiceHelp   = document.getElementById('piperVoiceHelp');
const refreshVoicesBtn = document.getElementById('refreshVoices');
const testPiperBtn     = document.getElementById('testPiper');
const piperTestStatus  = document.getElementById('piperTestStatus');

// Keys we load / save
const STORAGE_KEYS = [
  'ollamaUrl', 'ollamaModel', 'bookGenre', 'language', 'piperUrl',
  // Per-language voice selections
  'piperVoiceEn', 'piperVoiceAr', 'piperVoiceFr', 'piperVoiceIt', 'piperVoiceEs'
];

// Load saved settings
chrome.storage.local.get(STORAGE_KEYS, (data) => {
  if (data.ollamaUrl)     ollamaUrlInput.value = data.ollamaUrl;
  if (data.ollamaModel) {
    if (data.ollamaModel === 'gpt-oss:120b-cloud') {
      modelInput.value = 'nemotron-3-ultra:cloud';
      chrome.storage.local.set({ ollamaModel: 'nemotron-3-ultra:cloud' });
    } else {
      modelInput.value = data.ollamaModel;
    }
  } else {
    modelInput.value = 'nemotron-3-ultra:cloud';
  }
  if (data.bookGenre)     genreSelect.value    = data.bookGenre;
  if (data.language)      langSelect.value     = data.language;

  // Piper
  if (data.piperUrl) piperUrl.value = data.piperUrl;

  // Auto-fetch voices from the running Piper server (best-effort)
  refreshVoiceList();

  checkConnection();
});

// ===== Save settings on change =====
ollamaUrlInput.addEventListener('change', () => {
  chrome.storage.local.set({ ollamaUrl: ollamaUrlInput.value });
  checkConnection();
});

modelInput.addEventListener('change', () => {
  chrome.storage.local.set({ ollamaModel: modelInput.value });
});

genreSelect.addEventListener('change', () => {
  chrome.storage.local.set({ bookGenre: genreSelect.value });
});

langSelect.addEventListener('change', () => {
  const lang = langSelect.value;
  chrome.storage.local.set({ language: lang });
  // When the language changes, refresh the voice dropdown to show the
  // currently-saved voice for that language (and pre-select it).
  refreshVoiceList();
});

// Piper URL — when it changes, refresh the voice list
piperUrl.addEventListener('change', () => {
  chrome.storage.local.set({ piperUrl: piperUrl.value });
  refreshVoiceList();
});

// Voice dropdown — save the selected voice for the current language
piperVoiceSelect.addEventListener('change', () => {
  const selectedVoice = piperVoiceSelect.value;
  if (!selectedVoice) return;
  const lang = langSelect.value;
  const storageKey = `piperVoice${lang.charAt(0)}${lang.slice(1).toLowerCase()}`;
  // e.g. "English" → "piperVoiceEnglish"? No — we use piperVoiceEn / piperVoiceAr / etc.
  // Build the right key:
  const keyMap = {
    English: 'piperVoiceEn',
    Arabic:  'piperVoiceAr',
    French:  'piperVoiceFr',
    Italian: 'piperVoiceIt',
    Spanish: 'piperVoiceEs'
  };
  const actualKey = keyMap[lang];
  if (!actualKey) return;
  chrome.storage.local.set({ [actualKey]: selectedVoice });
});

// Refresh voices button
if (refreshVoicesBtn) {
  refreshVoicesBtn.addEventListener('click', (e) => {
    e.preventDefault();
    refreshVoiceList();
  });
}

// Fetch the list of loaded voices from the running Piper server
async function refreshVoiceList() {
  const url = piperUrl.value.replace(/\/+$/, '');
  if (!url) return;

  // Show loading state
  piperVoiceSelect.innerHTML = '<option value="">Loading voices...</option>';

  // Ask background script to fetch the voice list
  chrome.runtime.sendMessage(
    { type: 'CHECK_PIPER_VOICES', url },
    (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        piperVoiceSelect.innerHTML = '<option value="">— Cannot reach Piper —</option>';
        if (piperVoiceHelp) {
          piperVoiceHelp.innerHTML = `<span style="color:#fbbf24;">⚠ Could not reach Piper at ${url}.</span> Make sure the server is running. <a href="https://github.com/rhasspy/piper" target="_blank" style="color:#818cf8;">Setup guide →</a>`;
        }
        return;
      }

      // Normalize the voice list — Piper server may return either:
      //   OLD format: ["en_US-joe-medium", "ar_JO-kareem-medium", ...]   (strings)
      //   NEW format: [{name, language, quality, ...}, ...]              (objects)
      // We convert strings into objects so the rest of the code can use v.name etc.
      const rawVoices = response.voices || [];
      const voices = rawVoices.map(v => {
        if (typeof v === 'string') {
          // OLD format — string. Infer language from the name prefix.
          const prefix = v.split('-')[0];  // e.g. "en_US" from "en_US-joe-medium"
          const langMap = {
            en_US: 'English', en_GB: 'English (UK)', en_IE: 'English (Irish)',
            en_ZA: 'English (South African)', en_IN: 'English (Indian)',
            ar_JO: 'Arabic', es_ES: 'Spanish', es_MX: 'Spanish (Mexico)',
            fr_FR: 'French', fr_BE: 'French (Belgian)',
            it_IT: 'Italian', de_DE: 'German', nl_NL: 'Dutch',
            pl_PL: 'Polish', pt_BR: 'Portuguese (Brazil)', pt_PT: 'Portuguese',
            ru_RU: 'Russian', zh_CN: 'Chinese', vi_VN: 'Vietnamese',
            cs_CZ: 'Czech', cy_GB: 'Welsh', tr_TR: 'Turkish',
            kk_KZ: 'Kazakh', ca_ES: 'Catalan',
          };
          // Try to parse quality from the last segment (e.g. "medium" from "en_US-joe-medium")
          const parts = v.split('-');
          const quality = parts.length >= 3 ? parts[parts.length - 1] : '';
          return {
            name: v,
            language: langMap[prefix] || prefix,
            language_code: prefix,
            quality: quality
          };
        } else if (v && typeof v === 'object') {
          // NEW format — already an object. Make sure name is set.
          return {
            name: v.name || v.voice || String(v),
            language: v.language || v.lang || '',
            language_code: v.language_code || v.code || '',
            quality: v.quality || ''
          };
        }
        // Fallback for unexpected types
        return { name: String(v), language: '', language_code: '', quality: '' };
      });

      if (voices.length === 0) {
        piperVoiceSelect.innerHTML = '<option value="">— No voices loaded —</option>';
        if (piperVoiceHelp) {
          piperVoiceHelp.innerHTML = '<span style="color:#fbbf24;">⚠ Piper is running but no voices are loaded.</span> Download .onnx + .onnx.json files into your voices folder and restart Piper.';
        }
        return;
      }

      // Group voices by language for easier selection
      const currentLang = langSelect.value;
      const storageKey = ({
        English: 'piperVoiceEn',
        Arabic:  'piperVoiceAr',
        French:  'piperVoiceFr',
        Italian: 'piperVoiceIt',
        Spanish: 'piperVoiceEs'
      })[currentLang];

      // Read the saved voice for the current language
      chrome.storage.local.get([storageKey], (data) => {
        const savedVoice = data[storageKey];

        // Group by language
        const byLang = {};
        voices.forEach(v => {
          const lang = v.language || 'Unknown';
          if (!byLang[lang]) byLang[lang] = [];
          byLang[lang].push(v);
        });

        // Sort language names with the current language first
        const sortedLangs = Object.keys(byLang).sort((a, b) => {
          if (a === currentLang) return -1;
          if (b === currentLang) return 1;
          return a.localeCompare(b);
        });

        // Build options HTML
        let html = '';
        sortedLangs.forEach(lang => {
          const voicesForLang = byLang[lang];
          // Mark "current language" with a star in the optgroup label
          const label = lang === currentLang ? `★ ${lang} (current)` : lang;
          html += `<optgroup label="${label}">`;
          voicesForLang.forEach(v => {
            const sel = v.name === savedVoice ? ' selected' : '';
            const quality = v.quality ? ` (${v.quality})` : '';
            html += `<option value="${v.name}"${sel}>${v.name}${quality}</option>`;
          });
          html += '</optgroup>';
        });
        piperVoiceSelect.innerHTML = html;

        if (piperVoiceHelp) {
          const loadedCount = voices.length;
          const langCount = sortedLangs.length;
          piperVoiceHelp.innerHTML = `✓ <strong>${loadedCount}</strong> voice(s) loaded across <strong>${langCount}</strong> language(s). The selected voice will be used when the panel language is <strong>${currentLang}</strong>.`;
        }
      });
    }
  );
}

// Test Piper connection — does both /voices check and a tiny synthesis
if (testPiperBtn) {
  testPiperBtn.addEventListener('click', async () => {
    const url = piperUrl.value.replace(/\/+$/, '');
    piperTestStatus.textContent = 'Testing...';
    piperTestStatus.className = 'popup-test-status';
    try {
      const res = await fetch(`${url}/predict?text=hello&noise_scale=0.667&length_scale=1.0`, {
        method: 'GET'
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const buf = await res.arrayBuffer();
      if (buf.byteLength < 1000) throw new Error('Response too small to be audio');
      piperTestStatus.textContent = '✓ Connected — Piper is running';
      piperTestStatus.className = 'popup-test-status ok';
      // Refresh voice list now that we know it works
      refreshVoiceList();
    } catch (err) {
      piperTestStatus.textContent = '✗ ' + (err.message || 'Cannot connect');
      piperTestStatus.className = 'popup-test-status fail';
    }
  });
}

// Refresh models
refreshBtn.addEventListener('click', () => checkConnection());

// Check connection
function checkConnection() {
  const url = ollamaUrlInput.value.replace(/\/+$/, '');
  statusDot.className = 'dot';
  statusText.textContent = 'Connecting...';

  chrome.runtime.sendMessage(
    { type: 'CHECK_OLLAMA', url },
    (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        statusDot.className = 'dot error';
        statusText.textContent = 'Cannot connect to Ollama';
        return;
      }

      statusDot.className = 'dot connected';
      const models = response.models || [];
      statusText.textContent = `Connected`;

      modelList.innerHTML = '';
      models.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.name;
        modelList.appendChild(opt);
      });
    }
  );
}
