@echo off
title PDF Summarizer - Android Bridge Server
cd /d "%~dp0"
echo ========================================================
echo   PDF Summarizer - Android Remote Bridge Server
echo ========================================================
echo.
echo Make sure your phone is connected to the same Wi-Fi.
echo Your current PC IP is: 10.206.178.25:38126
echo.
echo Starting server...
node bridge-server.js
pause
