// PDF Summarizer — Background Service Worker
// Routes messages between content script, offscreen doc, and Ollama.

import { handleHoverRangeSummary } from './hover_range_summary.js';

let offscreenReady = false;
let pdfTexts = {};      // url -> { pageCount, pages: { 1: "text", 2: "text", ... } }
let pdfAudios = {};     // url -> { pageNum: wavBase64 }
let inFlightTts = new Set(); // url_pageNum
let pendingCallbacks = {};
let cbId = 0;

// ===== DISCORD RICH PRESENCE SESSION & TAB TRACKING =====
const AXO_BRIDGE_URL = 'http://127.0.0.1:38120';
let activeReadingTabs = new Set();
let sessionStartTime = null;

// Initialize session state from chrome.storage.session if available
if (chrome.storage && chrome.storage.session) {
  chrome.storage.session.get(['sessionStartTime', 'activeReadingTabs'], (data) => {
    if (data && data.sessionStartTime) {
      sessionStartTime = data.sessionStartTime;
    }
    if (data && Array.isArray(data.activeReadingTabs)) {
      activeReadingTabs = new Set(data.activeReadingTabs);
    }
  });
}

function persistSessionState() {
  if (chrome.storage && chrome.storage.session) {
    chrome.storage.session.set({
      sessionStartTime,
      activeReadingTabs: Array.from(activeReadingTabs)
    }).catch(() => {});
  }
}

function clearAxoPresence() {
  fetch(`${AXO_BRIDGE_URL}/clear`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  }).catch(() => {});
}

// Reset presence to 0 ONLY when the tab of the book in the browser is closed entirely
if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (activeReadingTabs.has(tabId)) {
      activeReadingTabs.delete(tabId);
      if (activeReadingTabs.size === 0) {
        // All reading tabs closed — reset session timer to 0 and clear Discord activity
        sessionStartTime = null;
        if (chrome.storage && chrome.storage.session) {
          chrome.storage.session.remove(['sessionStartTime', 'activeReadingTabs']).catch(() => {});
        }
        clearAxoPresence();
      } else {
        persistSessionState();
      }
    }
  });
}


// ===== ANTI META-LANGUAGE DIRECTIVE =====
// Appended to every summarization prompt. Forces the model to STATE the
// actual content (definitions, findings, events, arguments) directly as
// fact, instead of describing what the text "is about", "examines",
// "explores", etc. The reader is using the summary AS A SUBSTITUTE for
// reading the book — so describing what the text talks about is useless;
// the summary must SAY what the text says.
const ANTI_META_LANGUAGE = `
ABSOLUTE BAN ON META-LANGUAGE — these phrases are FORBIDDEN, never write them:
- "The text examines...", "The text explores...", "The text discusses...", "The text illustrates...", "The text investigates...", "The text considers...", "The text analyzes...", "The text looks at...", "The text deals with...", "The text covers...", "The text presents...", "The text describes...", "The text outlines...", "The text reviews...", "The text studies...", "The text delves into...", "The text talks about...", "The text addresses...", "The text examines how..."
- "The author argues...", "The author shows...", "The author portrays...", "The author suggests...", "The author claims...", "The author explains...", "The author makes the case that...", "The author contends..."
- "This passage covers...", "This section deals with...", "This section explores...", "This page discusses...", "These pages describe...", "This chapter examines...", "This range covers..."
- "The book examines...", "The book explores...", "The story explores...", "The narrative focuses on...", "The paper argues...", "The study investigates...", "The chapter argues..."

If the subject of your sentence is "the text", "the author", "the passage", "this section", "the book", "the story", "the narrative", "the paper", "the study", or "the chapter" — STOP and rewrite that sentence so the subject is the actual person, event, finding, idea, number, or definition.

THIS SUMMARY IS A SUBSTITUTE FOR READING. The reader is using it INSTEAD of the original. Do NOT describe what the text is about — SAY what the text says. State the actual content (definitions, findings, events, arguments, numbers, names, dates) directly as fact, as if you were the expert teaching it from memory.

BAD (forbidden — describes the text instead of stating content):
"The text examines the critical period hypothesis, specifically regarding how age affects pronunciation, grammaticality intuitions, and the overall rate of learning."

GOOD (states the content directly):
"After puberty, second-language learners almost never achieve native-like pronunciation; their grammaticality intuitions also plateau. Younger learners outperform them on implicit acquisition, but older learners actually show a faster explicit learning rate in the early stages — the critical period narrows the ceiling, not the speed of early gains."

BAD (forbidden):  "The author discusses the relationship between sleep and memory."
GOOD:             "Sleep after learning consolidates memories. REM-sleep deprivation specifically impairs procedural memory tasks, while slow-wave-sleep deprivation impairs declarative memory."

BAD (forbidden):  "The chapter explores Raskolnikov's moral conflict after the murder."
GOOD:             "After killing the pawnbroker, Raskolnikov hides the stolen items without using them, falls into a fever, and obsessively revisits the crime scene — convinced he has the right to transgress ordinary morality, yet crushed by guilt he cannot name."

Before finalizing your summary, re-read every sentence. If any sentence DESCRIBES the text instead of STATING the text's content, rewrite it.

ABSOLUTE BAN ON LATEX / MATH NOTATION — these are FORBIDDEN in your output:
- Never write "$\\to$", "$\\rightarrow$", "$\\Rightarrow$", "$\\leftarrow$", "$\\mapsto$", "$\\approx$", "$\\leq$", "$\\geq$", "$\\neq$", "$\\in$", "$\\sum$", "$\\int$", "$\\frac{}{}", "$\\sqrt{}$", or ANY other LaTeX command.
- NEVER write a dollar sign ($). Dollar signs are FORBIDDEN. If you are about to write a dollar sign, STOP. You have made a mistake.
- If you need an arrow, write the literal Unicode character "→" (copy this character: →). Or use the word "to".
- If you need any other math symbol, write the literal Unicode character directly: ≤, ≥, ≠, ×, ÷, ±, ≈, ∑, ∫, etc.
- For proportions or ratios, write "X to Y" or "X:Y" — never "$\\frac{X}{Y}$".
- For superscripts/subscripts, write them inline (e.g., "m²" not "$m^2$").

BAD (forbidden):  "research flows from topic $\\to$ thesis $\\to$ notes $\\to$ draft"
BAD (forbidden):  "research flows from topic $\\rightarrow$ thesis $\\rightarrow$ notes $\\rightarrow$ draft"
GOOD:              "research flows from topic → thesis → notes → draft"
ALSO GOOD:         "research flows from topic to thesis to notes to draft"

SELF-CHECK BEFORE OUTPUT: Scan your entire response. If it contains ANY dollar sign ($), you have FAILED. Remove every dollar sign and replace any LaTeX command with its plain-text equivalent before sending. Your output is rendered as PLAIN TEXT — it is NOT rendered by a LaTeX engine. Any "$\\to$" or "$\\rightarrow$" in your output will appear as literal garbage to the reader.

ABSOLUTE BAN ON CREATING ABBREVIATIONS — NEVER abbreviate proper nouns, technical terms, or multi-word concepts unless the abbreviation appears verbatim in the source text.
- If the source text says "Covenant Code", you MUST write "Covenant Code" — NEVER abbreviate it to "CC" or "(CC)".
- If the source text says "Critical Period Hypothesis", you MUST write "Critical Period Hypothesis" — NEVER abbreviate it to "CPH".
- If the source text says "System 1", you MUST write "System 1" — NEVER abbreviate it to "S1".
- Do NOT introduce abbreviations in parentheses after the first mention (e.g., do NOT write "Covenant Code (CC)"). Write the full term every time.
- The ONLY exception: if the source text itself uses an abbreviation (e.g., "DNA", "NASA", "MIS 6"), you may use it as the source does.
- When in doubt, write the full, unabbreviated term.`.trim();

// ===== OFFSCREEN DOCUMENT MANAGEMENT =====
async function ensureOffscreen() {
  const existing = await chrome.offscreen.hasDocument();
  if (!existing) {
    offscreenReady = false;
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DOM_PARSER'],
      justification: 'Parse PDF files to extract page text using PDF.js'
    });
    // Wait briefly for offscreen.js to initialize its message listener
    await new Promise(r => setTimeout(r, 350));
  }
  offscreenReady = true;
}

// Helper: Detect if text contains Arabic characters. Default to English otherwise.


// ===== MESSAGE HANDLER =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PARSE_PDF') {
    handleParsePDF(msg.url).then(sendResponse);
    return true;
  }

  if (msg.type === 'SUMMARIZE_PAGE') {
    handleSummarize(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'SUMMARIZE_HOVER_RANGE') {
    handleHoverRangeSummary(msg.url, msg.startPage, msg.endPage, msg.ollamaUrl, msg.model, msg.genre, msg.language, pdfTexts).then(sendResponse);
    return true;
  }

  if (msg.type === 'CHECK_OLLAMA') {
    handleCheckOllama(msg.url).then(sendResponse);
    return true;
  }

  if (msg.type === 'CHAT_PDF') {
    handleChat(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'CHAT_CHUNK_QUESTION') {
    handleChatChunkQuestion(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'CHAT_AMALGAMATE_ANSWERS') {
    handleChatAmalgamateAnswers(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'SUMMARIZE_RANGE') {
    handleSummarizeRange(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'SUMMARIZE_CONCEPT') {
    handleSummarizeConcept(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'OPEN_VIEWER') {
    // No custom viewer anymore — just a no-op or open instructions
    sendResponse({ success: true });
  }

  if (msg.type === 'DISCORD_READING_ACTIVE') {
    if (sender.tab && sender.tab.id) {
      activeReadingTabs.add(sender.tab.id);
    }
    if (!sessionStartTime) {
      sessionStartTime = Math.floor(Date.now() / 1000);
    }
    persistSessionState();
    sendResponse({ sessionStartTime });
    return true;
  }

  if (msg.type === 'GENERATE_QUIZ') {
    handleGenerateQuiz(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'GENERATE_PURPOSE') {
    handleGeneratePurpose(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'GRADE_QUIZ') {
    handleGradeQuiz(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'VERIFY_CLAIM') {
    handleVerifyClaim(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'RELEVANCE_SUMMARIZE_CHUNK') {
    handleRelevanceSummarizeChunk(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'RELEVANCE_ANSWER') {
    handleRelevanceAnswer(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'GENERATE_TTS' || msg.type === 'PREFETCH_TTS') {
    handleTTS(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'TTS_INLINE') {
    handleTTSInline(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'CHECK_PIPER_VOICES') {
    handleCheckPiperVoices(msg.url).then(sendResponse);
    return true;
  }

  if (msg.type === 'GET_PAGE_TEXT') {
    handleGetPageText(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'RECAP_GENERATE') {
    handleRecapGenerate(msg).then(sendResponse);
    return true;
  }

  if (msg.type === 'CLEAR_AUDIO_CACHE') {
    if (pdfAudios[msg.url]) {
      delete pdfAudios[msg.url];
    }
    sendResponse({ success: true });
    return false;
  }

  if (msg.type === 'PING') {
    sendResponse({ pong: true });
    return false; // Sync response
  }

  // Response from offscreen document
  if (msg.type === 'PDF_PARSED') {
    const cb = pendingCallbacks[msg.cbId];
    if (cb) {
      cb(msg);
      delete pendingCallbacks[msg.cbId];
    }
  }
});

// ===== PDF PARSING (via offscreen doc) =====
async function handleParsePDF(url) {
  // Check cache first
  if (pdfTexts[url]) {
    return { success: true, pageCount: pdfTexts[url].pageCount };
  }

  try {
    await ensureOffscreen();

    const id = ++cbId;
    const result = await new Promise((resolve, reject) => {
      pendingCallbacks[id] = resolve;

      const sendToOffscreen = () => {
        chrome.runtime.sendMessage({
          type: 'PARSE_PDF_URL',
          url: url,
          cbId: id
        }).catch(() => {
          // Offscreen might still be booting up, retry once after 350ms
          setTimeout(() => {
            chrome.runtime.sendMessage({
              type: 'PARSE_PDF_URL',
              url: url,
              cbId: id
            }).catch(e => {
              if (pendingCallbacks[id]) {
                delete pendingCallbacks[id];
                reject(new Error(`Failed to send to offscreen parser: ${e.message}`));
              }
            });
          }, 350);
        });
      };

      sendToOffscreen();

      // Timeout after 25 seconds
      setTimeout(() => {
        if (pendingCallbacks[id]) {
          delete pendingCallbacks[id];
          reject(new Error('PDF parsing timed out'));
        }
      }, 25000);
    });

    if (!result || !result.success) throw new Error(result?.error || 'Offscreen parser failed');

    // Cache the results
    pdfTexts[url] = { pageCount: result.pageCount, pages: result.pages };
    return { success: true, pageCount: result.pageCount };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== GET PAGE TEXT =====
function getPageText(url, pageNum) {
  const cached = pdfTexts[url];
  if (!cached || !cached.pages[pageNum]) return null;
  return cached.pages[pageNum];
}

// Helper: Resolve effective Ollama model (defaulting to nemotron-3-ultra:cloud, never gpt-oss:120b-cloud)
async function getEffectiveModel(base, requestedModel) {
  if (requestedModel && requestedModel !== 'gpt-oss:120b-cloud') {
    return requestedModel;
  }
  try {
    const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
    if (tagsRes && tagsRes.ok) {
      const tagsData = await tagsRes.json().catch(() => null);
      if (tagsData && tagsData.models && tagsData.models.length > 0) {
        const preferred = tagsData.models.find(m => m.name === 'nemotron-3-ultra:cloud' || m.name.includes('nemotron'));
        if (preferred) return preferred.name;
        return tagsData.models[0].name;
      }
    }
  } catch (_) {}
  return 'nemotron-3-ultra:cloud';
}

// ===== OLLAMA SUMMARIZATION =====
async function handleSummarize(msg) {
  let { url, pageNum, contextCount, ollamaUrl, model, genre, language, summaryLength } = msg;
  const isFiction = genre === 'fiction' || genre === 'philosophical_fiction';
  const isPhilosophical = genre === 'philosophical_fiction';
  const count = contextCount || 1;
  // summaryLength is now a NUMBER (max words) sent from the UI dropdown.
  // It applies to ALL genres and ALL page counts — no more per-genre
  // formulas or multipliers. The user picks the exact word limit.
  const wordLimit = parseInt(summaryLength) || 1000;

  let combinedText = '';

  // Ensure PDF text is parsed once before iterating
  if (!pdfTexts[url] || !pdfTexts[url].pages) {
    try {
      await handleParsePDF(url);
    } catch (_) {}
  }

  const cached = pdfTexts[url];

  for (let i = 0; i < count; i++) {
    const p = pageNum + i;
    if (cached && cached.pageCount && p > cached.pageCount) break;

    const text = getPageText(url, p);
    if (text && text.trim().length >= 10) {
      if (count > 1) {
        combinedText += `--- PAGE ${p} ---\n${text}\n\n`;
      } else {
        combinedText = text;
      }
    }
  }

  if (!combinedText || combinedText.trim().length < 10) {
    return { success: true, summary: 'The requested pages contain no readable text.', pageNum };
  }

  // For large page counts, feed the model more source text.
  let maxChars = 12000;
  if (count >= 60) maxChars = 140000;
  else if (count >= 50) maxChars = 115000;
  else if (count >= 40) maxChars = 90000;
  else if (count >= 30) maxChars = 70000;
  else if (count >= 20) maxChars = 48000;
  else if (count >= 10) maxChars = 24000;
  else if (count > 1) maxChars = 16000;
  const trimmedText = combinedText.length > maxChars ? combinedText.slice(0, maxChars) : combinedText;

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    const targetModel = await getEffectiveModel(base, model);

    let prompt = '';
    if (isPhilosophical) {
      // === PHILOSOPHICAL FICTION PROMPTS ===
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `You are a literary philosopher analyzing a work of philosophical fiction — the kind of book where narrative events and profound questions (about existence, morality, freedom, and the human condition) are equally important.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the book itself, so it must convey the actual content (events, dialogue, ideas, conclusions), not describe what the book is about.

Summarize the following pages AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words. You must balance the narrative events and their deeper significance 50/50:

1. NARRATIVE (50%): State what literally happens — the specific events, dialogue, and character actions in a cohesive story flow. Name names, follow the chronology, quote key lines.
2. MEANING & REFLECTION (50%): State the philosophical ideas, moral dilemmas, and existential questions these events raise — AND the positions or answers the text actually offers on them. Do not just name themes; say what the text says about them.

CRITICAL RULE: If these pages are transitional, descriptive, or lack deep philosophical content, focus fully on the narrative events (character interactions, plot progress, setting the scene) rather than forcing artificial philosophical themes.

${ANTI_META_LANGUAGE}

Respond in ${language} only.

Text:
${trimmedText}`;
      } else {
        prompt = `You are a literary philosopher analyzing a work of philosophical fiction — the kind of book where narrative events and profound questions (about existence, morality, freedom, and the human condition) are equally important.

This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the book itself, so it must convey the actual content (events, dialogue, ideas, conclusions), not describe what the page is about.

Summarize this page AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words. Your task is to analyze this page, balancing the narrative events and their deeper significance 50/50:

**NARRATIVE**: State what literally happens on this page — the specific events, dialogue, character actions, and narrative flow. Name names, follow the chronology, quote key lines.

**MEANING & REFLECTION**: State the philosophical ideas, moral dilemmas, and existential questions these events raise — AND the positions or answers the text actually offers on them. Do not just name themes; say what the text says about them.
- What specific philosophical ideas, moral dilemmas, or existential questions are raised — and what answer or stance does the text take?
- What do the characters' choices or inner thoughts reveal about human nature?
- Are there symbols, metaphors, or allegories at work — and what do they specifically mean?

CRITICAL RULES:
1. BALANCE: Give equal weight to the literal narrative events and their underlying meaning.
2. ORGANIC ANALYSIS: If the page is transitional, descriptive, or lacks heavy philosophical content, focus fully on the narrative events (character interactions, setting, actions, mood) rather than forcing artificial philosophical themes.
3. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else if (isFiction) {
      // === FICTION PROMPTS (event-preserving condensation with rewording) ===
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `You are condensing these pages of fiction into a dense, flowing, event-by-event retelling. The reader is using this INSTEAD of reading the book, so EVERY plot event on these pages must appear in your output — just condensed and RE-WORDED. You are a CONDENSER, not a SELECTOR, and not a TRANSCRIBER. Do not decide what's "important enough" to include; include every beat, in fewer words and in your own language.

YOUR OUTPUT MUST CONTAIN:
- Every event that occurs, in chronological order — none skipped.
- Scene, location, or time changes woven naturally into the sentence that describes the action there — never as a standalone label, heading, or list item.
- Every character action, decision, and key line of dialogue — paraphrased in your own words. State WHAT was said and its effect, not the original sentence.
- Every plot turn and revelation — preserved.

PARAPHRASE RULE (CRITICAL):
- Never copy a phrase of more than a few words directly from the source, including dialogue. If you can't compress a line without quoting it, rewrite it as reported/indirect speech instead (e.g. "she demanded to know where the money had gone" rather than repeating her exact words).
- Do not mirror the original's sentence structure or word order. A paraphrase that swaps a few words but keeps the original phrasing is NOT condensed — rewrite it.

FORMAT RULE:
- Plain flowing prose only. No headers, no bold, no bullet points, no dashes separating scenes, no labels of location/time set off from the sentence.

FORBIDDEN:
- Skipping an event because you decided it was "minor".
- Replacing specific events with a vague summary.
- Merging multiple events into one general sentence.
- Discussing themes, symbols, or style.
- Using meta-language ("The author describes...", "This page shows...").
- Quoting or near-quoting the source text.

If these pages contain 15 distinct plot events, your output must contain 15 condensed events — not 5. The goal is DENSITY through REWORDING, not through retained original text. A longer summary that preserves the full plot in your own words is better than a shorter one that drops events; a summary that keeps original phrasing to save effort is a FAILURE regardless of length.

Length: AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words.

LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      } else {
        prompt = `You are condensing this page of fiction into a dense, flowing, event-by-event retelling. The reader is using this INSTEAD of reading the book, so EVERY plot event on this page must appear in your output — just condensed and RE-WORDED. You are a CONDENSER, not a SELECTOR, and not a TRANSCRIBER. Do not decide what's "important enough" to include; include every beat, in fewer words and in your own language.

YOUR OUTPUT MUST CONTAIN:
- Every event that occurs, in chronological order — none skipped.
- Scene, location, or time changes woven naturally into the sentence that describes the action there — never as a standalone label, heading, or list item.
- Every character action, decision, and key line of dialogue — paraphrased in your own words. State WHAT was said and its effect, not the original sentence.
- Every plot turn and revelation — preserved.

PARAPHRASE RULE (CRITICAL):
- Never copy a phrase of more than a few words directly from the source, including dialogue. If you can't compress a line without quoting it, rewrite it as reported/indirect speech instead (e.g. "she demanded to know where the money had gone" rather than repeating her exact words).
- Do not mirror the original's sentence structure or word order. A paraphrase that swaps a few words but keeps the original phrasing is NOT condensed — rewrite it.

FORMAT RULE:
- Plain flowing prose only. No headers, no bold, no bullet points, no dashes separating scenes, no labels of location/time set off from the sentence.

FORBIDDEN:
- Skipping an event because you decided it was "minor".
- Replacing specific events with a vague summary.
- Merging multiple events into one general sentence.
- Discussing themes, symbols, or style.
- Using meta-language ("The author describes...", "This page shows...").
- Quoting or near-quoting the source text.

If this page contains 6 distinct events, your output must contain 6 condensed events — not 2. The goal is DENSITY through REWORDING, not through retained original text. A longer summary that preserves the full plot in your own words is better than a shorter one that drops events; a summary that keeps original phrasing to save effort is a FAILURE regardless of length.

LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else if (genre === 'law_books') {
      // === LAW BOOKS PROMPTS ===
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `You are a legal academic summarizing texts. Focus strictly on definitions, rules, exceptions, and key explanations. Summarize AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the original, so it must STATE every definition, rule, exception, and key explanation directly. The reader must walk away knowing the actual law, not knowing what the book "covers".

CRITICAL RULES:
1. FOCUS ON DETAIL: Detail is crucial. Do not be overly brief. State every definition, legal concept, test, and detailed explanation directly as fact.
2. ACADEMIC TONE: Maintain a precise, objective, academic tone.
3. Respond in ${language} only.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      } else {
        prompt = `You are a legal academic summarizing texts. Your goal is to STATE every definition, rule, exception, and detailed explanation found on this page — directly, as fact.

This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the original, so it must convey the actual law (definitions, rules, exceptions, tests), not describe what the page "discusses".

CRITICAL RULES:
1. FOCUS ON DETAIL: Detail is crucial. Identify and STATE any legal terminology, rules, principles, or tests mentioned — directly as fact.
2. ACADEMIC TONE: Maintain a precise, objective, academic tone.
3. Write 4 to 6 clear, detailed sentences.
4. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else if (genre === 'law_statutes') {
      // === LAW STATUTES PROMPTS ===
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `You are a legal expert summarizing statutory texts or codes. Your goal is to identify each section, subsection, and article, title them, and place an accurate, all-encompassing statement of the actual rule under each heading. Summarize AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the statute itself, so it must STATE the actual rules, not describe what the statute "covers".

CRITICAL RULES:
1. IDENTIFY SECTIONS: Explicitly identify each section, chapter, or article mentioned (e.g., "الفصل 7", "Article 12", "Section 3"). Use clear headings for each section.
2. STATE THE RULE: Place the actual rule — its substance, scope, conditions, exceptions — directly below its heading. Do not copy the text verbatim. Provide an accurate, comprehensive, all-encompassing statement of the rule or statute.
3. Respond in ${language} only.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      } else {
        prompt = `You are a legal expert summarizing statutory texts or codes. Your goal is to identify each section, subsection, and article, title them, and place an accurate, all-encompassing statement of the actual rule under each heading.

This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the statute itself, so it must STATE the actual rules, not describe what the page "covers".

CRITICAL RULES:
1. IDENTIFY SECTIONS: Explicitly identify each section, chapter, or article mentioned (e.g., "الفصل 7", "Article 12", "Section 3"). Use clear headings for each section.
2. STATE THE RULE: Place the actual rule — its substance, scope, conditions, exceptions — directly below its heading. Do not copy the text verbatim. Provide an accurate, comprehensive, all-encompassing statement of the rule or statute.
3. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else if (genre === 'research_papers') {
      // === RESEARCH PAPERS PROMPTS (priority tiers, skip-empties) ===
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `You are summarizing a portion of a research paper covering multiple pages. Summarize in priority order — include a tier only if the pages actually contain that kind of content; skip tiers that don't apply.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the paper itself, so it must STATE the actual findings, numbers, reasoning, and conclusions directly. The reader must walk away knowing WHAT was found and WHAT was concluded, not merely that "the paper examines X".

TIER 1 — STATISTICS: Every quantitative result (n, %, mean, median, SD, p-value, CI, effect size, correlation, regression coefficient). Verbatim with units and referents.
TIER 2 — REASONING: Any inferential step, statistical test, model, or logical argument used to move from data to claim. Name the test and report its output.
TIER 3 — CONCLUSION: Any stated conclusion or takeaway, with effect magnitude attached.
TIER 4 — METHODS: What was measured — design, sample, instruments, dataset — but only what's needed to understand the numbers above.
TIER 5 — CONTEXT: Background, motivation, prior literature — only what's needed to make the rest intelligible.

CRITICAL RULES:
1. NUMBERS VERBATIM. If a number appears, it appears in your summary exactly as written.
2. SKIP EMPTY TIERS. If a tier has no content in these pages, do not pad with placeholders or "N/A". Move to the next tier silently. (A multi-page literature review may fill only Tier 5 — that is correct.)
3. PRIORITY MEANS ORDER. If the pages are dense, prioritize Tiers 1–3 over 4–5. If the pages have only Tier 5 content (intro, lit review, methods description), state the actual definitions, prior findings, and methodological choices substantively — do not invent Tiers 1–4.
4. Length: AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words. Density over padding.
5. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      } else {
        prompt = `You are summarizing a page from a research paper. Summarize in priority order — include a tier only if the page actually contains that kind of content; skip tiers that don't apply.

This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the paper itself, so it must STATE the actual findings, numbers, reasoning, and conclusions directly. The reader must walk away knowing WHAT was found and WHAT was concluded, not merely that "the page examines X".

TIER 1 — STATISTICS: Every quantitative result (n, %, mean, median, SD, p-value, CI, effect size, correlation, regression coefficient). Verbatim with units and referents.
TIER 2 — REASONING: Any inferential step, statistical test, model, or logical argument used to move from data to claim. Name the test and report its output.
TIER 3 — CONCLUSION: Any stated conclusion or takeaway, with effect magnitude attached.
TIER 4 — METHODS: What was measured — design, sample, instruments, dataset — but only what's needed to understand the numbers above.
TIER 5 — CONTEXT: Background, motivation, prior literature — only what's needed to make the rest intelligible.

CRITICAL RULES:
1. NUMBERS VERBATIM. If a number appears, it appears in your summary exactly as written.
2. SKIP EMPTY TIERS. If a tier has no content on this page, do not pad with placeholders or "N/A". Move to the next tier silently.
3. PRIORITY MEANS ORDER. If the page is dense, prioritize Tiers 1–3 over 4–5. If the page has only Tier 5 content (lit review, intro), state the actual definitions, prior findings, and methodological choices substantively — do not invent Tiers 1–4.
4. Write 4 to 6 clear, information-dense sentences.
5. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else if (genre === 'self_help') {
      // === SELF HELP PROMPTS (practitioner's notes — substance-adaptive) ===
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `You are summarizing a portion of a self-help book. This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the book, so it must STATE the actual advice, frameworks, exercises, and mindset shifts directly. The reader must walk away knowing WHAT to do and HOW — not merely that "the author discusses X".

Write the summary as a practitioner's working notes — the notes a serious reader would take if they were going to apply this material next week. Notes capture substance, not narration.

CRITICAL RULES:
1. PRINCIPLES AS DIRECT STATEMENTS: State every principle, technique, framework, or mindset shift as a direct, applicable statement. ("When facing X, do Y because Z." — not "The author suggests that when facing X, one might consider Y.")
2. NAMED MODELS: If the author names a framework, model, or dichotomy (e.g., "System 1 vs System 2", "The 5 Love Languages", "Fixed vs Growth Mindset"), state the name, what it claims, and how to use it.
3. EXERCISES VERBATIM: Reproduce reflection questions, journaling prompts, and exercises verbatim — the reader is supposed to actually do them.
4. ANECDOTES → LESSONS: Compress every illustrative story into ONE sentence stating the lesson it demonstrates. Skip anecdotes that carry no lesson.
5. SUBSTANCE-ADAPTIVE: Dense framework pages get detailed notes; anecdote pages get the lesson only; pure filler/transition pages get skipped silently. Match output density to input density. A sparse range may yield a shorter summary — that is correct, not a failure.
6. Length: AT MOST ${wordLimit} words — do NOT exceed this limit. Aim for close to ${wordLimit} words (use the full budget), but NEVER go over ${wordLimit} words.
7. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      } else {
        prompt = `You are summarizing a page from a self-help book. This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the book, so it must STATE the actual advice, frameworks, exercises, and mindset shifts directly. The reader must walk away knowing WHAT to do and HOW — not merely that "the author discusses X".

Write the summary as a practitioner's working notes — the notes a serious reader would take if they were going to apply this material next week. Notes capture substance, not narration.

CRITICAL RULES:
1. PRINCIPLES AS DIRECT STATEMENTS: State every principle, technique, framework, or mindset shift as a direct, applicable statement. ("When facing X, do Y because Z." — not "The author suggests that when facing X, one might consider Y.")
2. NAMED MODELS: If the author names a framework, model, or dichotomy (e.g., "System 1 vs System 2", "The 5 Love Languages"), state the name, what it claims, and how to use it.
3. EXERCISES VERBATIM: Reproduce reflection questions, journaling prompts, and exercises verbatim — the reader is supposed to actually do them.
4. ANECDOTES → LESSONS: Compress every illustrative story into ONE sentence stating the lesson it demonstrates. Skip anecdotes that carry no lesson.
5. SUBSTANCE-ADAPTIVE: Match output density to input density. A pure-anecdote page yields its lesson; a pure-filler page yields a one-line acknowledgment; a dense framework page yields detailed notes.
6. Write 3 to 5 clear, applicable sentences.
7. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else if (genre === 'nonfiction_headers') {
      // === NON-FICTION PROMPTS WITH HEADERS ===
      if (count > 1) {
        prompt = `Summarize the following pages in approximately ${wordLimit} words (do NOT exceed ${wordLimit} words).

This summary is a SUBSTITUTE for reading these pages. The reader must understand the key facts, findings, the author's arguments, and the evidence supporting them.

CRITICAL RULES:
1. You MUST organize the summary using clear, distinct Markdown section headers (### Header) for each major topic or argument.
2. Cover the core arguments, evidence, definitions, historical facts, and conclusions directly and factually.
3. State content directly as facts and findings — never describe the text or the author.
4. Keep the summary focused, dense, and close to ${wordLimit} words — do NOT exceed ${wordLimit} words.

${ANTI_META_LANGUAGE}

Respond in ${language} only.

Text:
${trimmedText}`;
      } else {
        prompt = `You are an expert at summarizing text for readers.

This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the book itself, so it must convey the EXACT substance of the page, just condensed. Cover ALL details — not just the "key" or "important" ones.

CRITICAL RULE: You MUST use clear, distinct section headers (e.g. bolded titles or ## Markdown headers) to break up the text logically. Do NOT write one continuous block of paragraphs. Create a new header whenever the topic, argument, or section changes.

WHAT COUNTS AS "DETAILS" — all of these must be covered:
- Facts: names, dates, numbers, places, definitions — reproduced exactly.
- Arguments: the author's claims, thesis, and position on the topic.
- Evidence: the data, studies, examples, and cases the author uses.
- Interpretations: how the author reads the evidence — what they think it means.
- Comparisons: how X compares to Y.
- Reasoning: the logical steps from evidence to conclusion.
- Context: background information needed to understand the above.

FORBIDDEN:
- Skipping a topic because you decided it was "minor".
- Dropping the author's argument and keeping only the raw facts.
- Merging multiple distinct points into one vague sentence.
- Using meta-language ("The author discusses...", "This page covers...").
- Writing less than the word limit to be "concise".

CRITICAL RULES:
1. State the actual content DIRECTLY — facts, arguments, evidence, interpretations.
2. Write 5 to 8 clear, information-dense sentences. Use the full budget.
3. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    } else {
      // === NON-FICTION PROMPTS (cover ALL details, not just "key" ones) ===
      // The old prompt said "cover all key details" — the model interpreted
      // "key" as "important facts and numbers" and dropped arguments,
      // interpretations, evidence, and theoretical frameworks. The new prompt
      // says "cover ALL details" and explicitly defines what "details" means
      // for non-fiction, so the model captures the author's ARGUMENT and
      // REASONING, not just raw facts. This works for any non-fiction genre:
      // science, history, anthropology, biography, journalism, philosophy, etc.
      if (count > 1) {
        // wordLimit is set at the top of handleSummarize from the UI dropdown
        prompt = `Summarize the following text in approximately ${wordLimit} words (do NOT exceed ${wordLimit} words).

This summary is a SUBSTITUTE for reading these pages. The reader must understand the key facts, findings, the author's arguments, and the evidence supporting them.

CRITICAL RULES:
1. Cover the core arguments, evidence, definitions, historical facts, and conclusions directly and factually.
2. State content directly as facts and findings — never describe the text or the author.
3. Keep the summary focused, dense, and close to ${wordLimit} words — do NOT exceed ${wordLimit} words.

${ANTI_META_LANGUAGE}

Plain text only, no formatting. Respond in ${language} only.

Text:
${trimmedText}`;
      } else {
        prompt = `You are an expert at summarizing text for readers.

This summary is a SUBSTITUTE for reading this page — the reader is using it INSTEAD of the book itself, so it must convey the EXACT substance of the page, just condensed. Cover ALL details — not just the "key" or "important" ones.

WHAT COUNTS AS "DETAILS" — all of these must be covered:
- Facts: names, dates, numbers, places, definitions — reproduced exactly.
- Arguments: the author's claims, thesis, and position on the topic.
- Evidence: the data, studies, examples, and cases the author uses.
- Interpretations: how the author reads the evidence — what they think it means.
- Comparisons: how X compares to Y.
- Reasoning: the logical steps from evidence to conclusion.
- Context: background information needed to understand the above.

FORBIDDEN:
- Skipping a topic because you decided it was "minor".
- Dropping the author's argument and keeping only the raw facts.
- Merging multiple distinct points into one vague sentence.
- Using meta-language ("The author discusses...", "This page covers...").
- Writing less than the word limit to be "concise".

CRITICAL RULES:
1. State the actual content DIRECTLY — facts, arguments, evidence, interpretations.
2. Write 5 to 8 clear, information-dense sentences. Use the full budget.
3. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${trimmedText}`;
      }
    }

    // NO token limit (num_predict). The old approach set a hard token wall
    // that either cut the model off mid-sentence (buffer too small) or let
    // it generate way over the word limit (buffer too big). Neither worked.
    // Instead, we let the model generate freely and rely ENTIRELY on the
    // prompt to control length. The prompt says "AT MOST X words" and the
    // model does its best to obey. This means no cutoffs — ever.
    // Note: num_predict is omitted entirely (defaults to the model's max,
    // which for most models is 2048 or 4096 — enough to never cut off).
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 300000); // 5-minute timeout
    const keepAlive = setInterval(() => {
      chrome.runtime.getPlatformInfo().catch(() => {});
    }, 20000);

    let res;
    try {
      res = await fetch(`${base}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          model: targetModel,
          prompt: prompt,
          stream: false
        })
      });
    } catch (fetchErr) {
      clearInterval(keepAlive);
      clearTimeout(timeoutId);
      if (fetchErr.name === 'AbortError') {
        return { success: false, error: 'Ollama request timed out after 5 minutes. The model might be busy. Please try again.', pageNum };
      }
      return { success: false, error: `Failed to reach Ollama: ${fetchErr.message}`, pageNum };
    }
    clearInterval(keepAlive);
    clearTimeout(timeoutId);

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      let friendlyError = `Ollama returned ${res.status}: ${errText}`;
      if (res.status === 429 || errText.includes('overloaded') || errText.includes('concurrent request slot')) {
        friendlyError = 'Ollama Cloud is currently busy or overloaded. Please wait a few seconds and try again.';
      }
      return { success: false, error: friendlyError, pageNum };
    }

    const rawText = await res.text();
    if (!rawText || rawText.trim().length === 0) {
      return { success: false, error: 'Ollama returned an empty response.', pageNum };
    }

    let data;
    try {
      data = JSON.parse(rawText);
    } catch (parseErr) {
      // Might be newline-delimited JSON (streaming leftovers) — grab last valid object
      const lines = rawText.trim().split('\n').filter(l => l.trim());
      const lastLine = lines[lines.length - 1];
      data = JSON.parse(lastLine);
    }

    return { success: true, summary: data.response || '(No summary returned)', pageNum };

  } catch (err) {
    return { success: false, error: err.message, pageNum };
  }
}

// ===== AI CHAT (page-scoped context) =====
async function handleChat(msg) {
  let { url, history, ollamaUrl, model, genre, language, pages } = msg;
  const isFiction = genre === 'fiction' || genre === 'philosophical_fiction';

  // Re-parse if needed
  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  let fullText = '';

  // Build context from the SPECIFIED pages only (not the whole book).
  // `pages` is an array of page numbers. If missing/empty, fall back to
  // all pages (legacy behavior).
  if (cached && cached.pages) {
    let pageNums;
    if (pages && pages.length > 0) {
      pageNums = pages.filter(p => cached.pages[p]).sort((a, b) => +a - +b);
    } else {
      pageNums = Object.keys(cached.pages).sort((a, b) => +a - +b);
    }
    fullText = pageNums.map(p => `--- Page ${p} ---\n${cached.pages[p]}`).join('\n\n');
    // Trim to ~60k chars to stay within context windows
  }

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    // Build messages: system context + conversation history
    let systemPrompt;
    if (fullText) {
      if (genre === 'philosophical_fiction') {
        systemPrompt = `You are a philosophical reading companion helping a reader explore a work of philosophical fiction \u2014 books like Crime and Punishment, The Stranger, The Brothers Karamazov, The Trial, Siddhartha, Notes from Underground.

Here is the full text:\n\n${fullText}\n\nYou help the reader explore the DEEPER LAYERS of the text: existential questions, moral philosophy, the psychology of characters, symbolic meaning, and the philosophical traditions the work engages with (existentialism, nihilism, absurdism, determinism, etc.).

When answering:
- Connect events to their philosophical significance
- Explore what characters' choices reveal about the human condition
- Identify recurring symbols and their meanings
- Relate ideas to real philosophical concepts and thinkers
- Help the reader see beyond the surface narrative

LANGUAGE RULE (CRITICAL):\nYou MUST respond EXCLUSIVELY in ${language}.`;
      } else if (genre === 'fiction') {
        systemPrompt = `You are a literary companion helping a reader explore a fiction book. Here is the full text:\n\n${fullText}\n\nAnswer questions about characters, plot, themes, motivations, symbolism, foreshadowing, and narrative structure. Be insightful and help the reader appreciate the storytelling craft.\n\nLANGUAGE RULE (CRITICAL):\nYou MUST respond EXCLUSIVELY in ${language}.`;
      } else if (genre === 'research_papers') {
        systemPrompt = `You are a research methodology companion helping a reader work through an academic or scientific paper. Here is the full text:\n\n${fullText}\n\nWhen answering the reader's questions, prioritize the empirical and inferential substance of the paper:\n\n- NUMBERS FIRST: Whenever a question touches on a finding, cite the exact statistic from the paper (n, %, mean, SD, p-value, CI, effect size, regression coefficient) with its unit and referent. Never paraphrase a result without its underlying number.\n- REASONING EXPLICIT: When the reader asks "why" or "how", explain the inferential bridge — name the statistical test, model, comparison, or logical step that links data to conclusion. Do not jump from "X was measured" to "Y was concluded" without naming the bridge.\n- CONCLUSIONS WITH MAGNITUDE: When stating the authors' conclusions, always attach the size of the effect or the strength of the evidence (e.g., "reduced by 23%, 95% CI [14%, 31%]" rather than "had a significant effect").\n- ACKNOWLEDGE GAPS: If the paper does not report a statistic the reader asks about, say so directly rather than inventing one.\n- ADAPT TO THE PAPER: If the paper is non-empirical (theory, review, methods paper, qualitative study), answer questions about its actual substance — definitions, arguments, framework, qualitative findings — without forcing a quantitative frame.\n- NO META-LANGUAGE: Never write "The authors found..." or "The study shows..." — state findings and ideas directly as facts.\n\nLANGUAGE RULE (CRITICAL):\nYou MUST respond EXCLUSIVELY in ${language}.`;
      } else if (genre === 'self_help') {
        systemPrompt = `You are a practitioner's companion helping a reader apply a self-help book. Here is the full text:\n\n${fullText}\n\nWhen answering the reader's questions, prioritize actionable substance over narration:\n\n- ADVICE FIRST: Whenever a question touches on a technique, framework, or principle, state the specific steps, criteria, or implementation detail — including any named model the author uses (e.g., "System 1 vs System 2", "Fixed vs Growth Mindset"). State the name, what it claims, and how to use it.\n- EXERCISES VERBATIM: When the reader asks about an exercise, reflection prompt, or journaling question, reproduce it verbatim so they can actually perform it.\n- REASONING INCLUDED: For each piece of advice, include the psychological mechanism, evidence, or reasoning that justifies it.\n- ANECDOTES AS LESSONS: When the reader asks about an illustrative story, state the lesson it demonstrates in one sentence — do not retell the story.\n- ACKNOWLEDGE GAPS: If the book does not address the reader's question, say so directly rather than inventing advice.\n- NO META-LANGUAGE: Never write "The author suggests..." or "The book recommends..." — state the advice directly as instruction.\n\nLANGUAGE RULE (CRITICAL):\nYou MUST respond EXCLUSIVELY in ${language}.`;
      } else {
        systemPrompt = `You are a helpful assistant. The user is reading a PDF document. Here is the full text of the document:\n\n${fullText}\n\nAnswer the user's questions based on this document. Be concise and accurate.\n\nLANGUAGE RULE (CRITICAL):\nYou MUST respond EXCLUSIVELY in ${language}.`;
      }
    } else {
      systemPrompt = 'You are a helpful assistant answering questions about a PDF document. The document text could not be extracted.';
    }

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history
    ];

    const res = await fetch(`${base}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: targetModel, messages, stream: false })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    const reply = data.message?.content || data.response || '(No reply)';
    return { success: true, reply };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== AI CHAT: 60-PAGE ISOLATED CHUNK ANSWER =====
async function handleChatChunkQuestion(msg) {
  let { url, fromPage, toPage, question, ollamaUrl, model, genre, language } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  let chunkText = '';
  for (let p = fromPage; p <= toPage; p++) {
    if (cached.pages[p]) {
      chunkText += `Page ${p}:\n${cached.pages[p]}\n\n`;
    }
  }

  if (!chunkText.trim()) {
    return { success: true, answer: `(No readable text in pages ${fromPage}–${toPage})` };
  }

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    let genreInstruction = '';
    if (genre === 'philosophical_fiction') {
      genreInstruction = 'Connect events, character decisions, and themes to their existential, moral, and philosophical significance where applicable.';
    } else if (genre === 'fiction') {
      genreInstruction = 'Focus on concrete plot developments, character actions, narrative context, and events.';
    } else if (genre === 'research_papers') {
      genreInstruction = 'Report exact numbers, statistics, methodology, inferential steps, and findings verbatim where applicable.';
    } else if (genre === 'self_help') {
      genreInstruction = 'Focus on actionable principles, exercises, models, and concrete advice.';
    } else if (genre === 'law_books' || genre === 'law_statutes') {
      genreInstruction = 'Focus on precise legal definitions, rules, statutes, conditions, and exceptions.';
    }

    const prompt = `You are analyzing pages ${fromPage} to ${toPage} of a document to answer the following question:

Question: "${question}"

Below is the text of pages ${fromPage} to ${toPage}:

${chunkText}

Instructions:
1. Answer the question based strictly and thoroughly on the information present in pages ${fromPage} to ${toPage}.
2. If these pages contain relevant facts, details, explanations, arguments, or answers to the question, state them clearly, factually, and accurately. ${genreInstruction}
3. If these pages do NOT contain any relevant information to the question, state: "No relevant information on this topic found in pages ${fromPage}–${toPage}."
4. Do NOT speculate or make assumptions beyond what is in these pages.
5. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}`;

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: prompt,
        stream: false
      })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    return { success: true, answer: (data.response || '(No response)').trim() };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== AI CHAT: AMALGAMATE 60-PAGE CHUNK ANSWERS =====
async function handleChatAmalgamateAnswers(msg) {
  let { url, question, chunkAnswers, ollamaUrl, model, genre, language } = msg;

  if (!chunkAnswers || chunkAnswers.length === 0) {
    return { success: false, error: 'No chunk answers provided to amalgamate.' };
  }

  const combinedAnswers = chunkAnswers
    .map((c, i) => `=== Pages ${c.from}–${c.to} (Chunk ${i + 1}) ===\n${c.answer}`)
    .join('\n\n');

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const prompt = `A user asked the following question about the entire document:

"${question}"

The entire document was analyzed in 60-page isolated chunks. Here are the answers and findings extracted from each 60-page chunk:

${combinedAnswers}

Instructions:
1. Synthesize all the chunk answers above into a single, cohesive, comprehensive, and well-structured final answer to the user's question.
2. Base your response purely on the amalgamation of all chunk answers above.
3. Organize the response logically with clear paragraphs, headings, or bullet points if appropriate so it reads as a unified, seamless answer.
4. Eliminate any redundancies or repetitions between chunks.
5. If none of the chunk answers contain relevant information, clearly state that the document does not contain information regarding the question.
6. Do NOT refer to "Chunk 1" or "in the chunk summaries" — speak directly and authoritatively about the document's content.
7. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}`;

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: prompt,
        stream: false
      })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    return { success: true, reply: (data.response || '(No reply)').trim() };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function handleCheckOllama(url) {
  try {
    const base = (url || 'http://localhost:11434').replace(/\/+$/, '');
    const res = await fetch(`${base}/api/tags`);
    if (!res.ok) {
      return { success: false, error: `Ollama returned status ${res.status}` };
    }
    const rawText = await res.text();
    const data = JSON.parse(rawText);
    return { success: true, models: data.models || [] };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== RANGE SUMMARIZATION (chunked, isolated context) =====
async function handleSummarizeRange(msg) {
  let { url, startPage, endPage, ollamaUrl, model, genre, language } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  const CHUNK_SIZE = 20;
  const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
  const targetModel = await getEffectiveModel(base, model);

  const chunks = [];
  for (let i = startPage; i <= endPage; i += CHUNK_SIZE) {
    chunks.push({ from: i, to: Math.min(i + CHUNK_SIZE - 1, endPage) });
  }

  const chunkSummaries = [];
  let completedChunks = 0;

  // 160 words per 20-page chunk — same approach as the hovering bar
  // (hover_range_summary.js) which uses an explicit numeric word limit
  // that the AI respects accurately. For a 135-page book this gives
  // ~1120 words total instead of the 3000-4000 the old "8-12 sentences"
  // instruction produced.
  const wordLimit = 160;

  for (const chunk of chunks) {
    let chunkText = '';
    for (let p = chunk.from; p <= chunk.to; p++) {
      if (cached.pages[p]) {
        chunkText += `Page ${p}:\n${cached.pages[p]}\n\n`;
      }
    }

    if (!chunkText.trim()) {
      chunkSummaries.push({ label: `Pages ${chunk.from}-${chunk.to}`, summary: '(No readable text in this range.)' });
      completedChunks++;
      continue;
    }


    try {
      const res = await fetch(`${base}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: targetModel,
          prompt: genre === 'philosophical_fiction'
            ? `You are a literary philosopher analyzing a work of philosophical fiction.

You are summarizing pages ${chunk.from} to ${chunk.to} — these pages may contain multiple scenes, character actions, and thematic developments.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the book itself, so it must STATE the actual events, dialogue, ideas, and the answers/positions the text actually offers, not describe what the pages "are about".

Summarize these pages on TWO levels:
1. NARRATIVE: State what literally happens — specific events, character actions, dialogue. Name names, follow chronology.
2. PHILOSOPHICAL LAYER: State the existential, moral, or philosophical questions/themes raised — AND the answers or positions the text actually takes on them. Do not just name themes; say what the text says about them.

CRITICAL RULES:
1. Your response MUST be under ${wordLimit} words — do NOT exceed this limit. Be dense and concise.
2. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.
3. Every sentence should cover DIFFERENT content — no repetition.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`
            : genre === 'fiction'
            ? `You are condensing pages ${chunk.from} to ${chunk.to} of fiction into a dense, event-by-event retelling. These pages contain scenes, character actions, and plot developments — ALL of them must appear in your output, just condensed. You are a CONDENSER, not a SELECTOR. Do not decide what's "important enough" to include; include every beat of the story, in fewer words.

The reader is using this INSTEAD of reading the book, so EVERY plot event, scene, and development must appear — just condensed.

YOUR OUTPUT MUST CONTAIN:
- Every event that occurs, in chronological order — none skipped, none merged into vague generalities.
- Every scene change, location shift, and time jump — stated explicitly.
- Every character action, decision, and key line of dialogue — reproduced (condensed, but recognizable).
- Every plot turn, revelation, and complication — preserved.
- Every change in who knows what, who is where, and who is doing what — tracked.

FORBIDDEN — these are FAILURE MODES:
- Skipping an event because you decided it was "minor" or "transitional".
- Replacing specific events with vague summaries like "more things happen" or "the story continues".
- Merging multiple distinct scenes into one general sentence.
- Summarizing the "arc" instead of telling the events in order.
- Using meta-language ("The author describes...", "This section shows...").
- Discussing themes, symbols, or writing style.

If these pages contain 20 distinct plot events, your output must contain 20 condensed events — not 5. The goal is DENSITY. A longer summary that preserves the full plot is better than a shorter one that drops events.

CRITICAL RULES:
1. Your response MUST be under ${wordLimit} words — do NOT exceed this limit. Be dense and concise, retelling the story beat by beat.
2. Every sentence should cover DIFFERENT content — no repetition.
3. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`
            : genre === 'research_papers'
            ? `You are summarizing pages ${chunk.from} to ${chunk.to} of a research paper. This range may cover many pages of mixed content — introduction, methods, results, discussion, tables, or references. Summarize in priority order — include a tier only if these pages actually contain that kind of content; skip tiers that don't apply.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the paper itself, so it must STATE the actual findings, numbers, reasoning, and conclusions directly. The reader must walk away knowing WHAT was found and WHAT was concluded, not merely that "the pages examine X".

TIER 1 — STATISTICS: Every quantitative result (n, %, mean, median, SD, p-value, CI, effect size, correlation, regression coefficient). Verbatim with units and referents. Enumerate key values from tables and inline text.
TIER 2 — REASONING: Any inferential step, statistical test, model, or logical argument used to move from data to claim. Name the test and report its output.
TIER 3 — CONCLUSION: Any stated conclusion or takeaway, with effect magnitude attached.
TIER 4 — METHODS: What was measured — design, sample, instruments, dataset — but only what's needed to understand the numbers above.
TIER 5 — CONTEXT: Background, motivation, prior literature — only what's needed to make the rest intelligible.

CRITICAL RULES:
1. NUMBERS VERBATIM. If a number appears in this range, it appears in your summary exactly as written.
2. SKIP EMPTY TIERS. If a tier has no content in this range, do not pad with placeholders or "N/A". Move to the next tier silently. (A 20-page literature review may fill only Tier 5 — that is correct.)
3. PRIORITY MEANS ORDER. Prioritize Tiers 1–3 over 4–5 when the range is dense. If the range is purely contextual (intro, lit review, references), state the actual definitions, prior findings, and methodological choices substantively — do not invent Tiers 1–4.
4. Your response MUST be under ${wordLimit} words — do NOT exceed this limit. Each sentence should cover DIFFERENT content — no repetition.
5. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`
            : genre === 'self_help'
            ? `You are summarizing pages ${chunk.from} to ${chunk.to} of a self-help book — these pages cover techniques, frameworks, exercises, anecdotes, and reflection prompts.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the book, so it must STATE the actual advice, frameworks, exercises, and mindset shifts directly. The reader must walk away knowing WHAT to do and HOW — not merely that "the author discusses X".

Write the summary as a practitioner's working notes — the notes a serious reader would take if they were going to apply this material next week. Notes capture substance, not narration.

CRITICAL RULES:
1. PRINCIPLES AS DIRECT STATEMENTS: State every principle, technique, framework, or mindset shift as a direct, applicable statement. ("When facing X, do Y because Z." — not "The author suggests that when facing X, one might consider Y.")
2. NAMED MODELS: If the author names a framework, model, or dichotomy (e.g., "System 1 vs System 2", "The 5 Love Languages", "Fixed vs Growth Mindset"), state the name, what it claims, and how to use it.
3. EXERCISES VERBATIM: Reproduce reflection questions, journaling prompts, and exercises verbatim — the reader is supposed to actually do them.
4. ANECDOTES → LESSONS: Compress every illustrative story into ONE sentence stating the lesson it demonstrates. Skip anecdotes that carry no lesson.
5. SUBSTANCE-ADAPTIVE: Dense framework pages get detailed notes; anecdote pages get the lesson only; pure filler/transition pages get skipped silently. Match output density to input density. A sparse range may yield a shorter summary — that is correct, not a failure.
6. Your response MUST be under ${wordLimit} words — do NOT exceed this limit. Each sentence should cover DIFFERENT content — no repetition.
7. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`
            : `You are summarizing pages ${chunk.from} to ${chunk.to} — this is a LOT of content covering MANY different topics, ideas, and developments. Cover ALL of them, just condensed. Do NOT decide what's "important enough" to include; include everything, in fewer words. NOTHING may be omitted.

This summary is a SUBSTITUTE for reading these pages — the reader is using it INSTEAD of the original. They must walk away knowing not just the FACTS, but the AUTHOR'S ARGUMENT, the EVIDENCE that supports it, and what it all MEANS.

WHAT COUNTS AS "DETAILS" — ALL of these must be covered, no exceptions:
- Facts: names, dates, numbers, places, definitions — reproduced exactly.
- Arguments: the author's claims, thesis, and position on the topic.
- Evidence: the data, studies, examples, and cases the author uses to support claims.
- Interpretations: how the author reads the evidence — what they think it means.
- Comparisons: EVERY comparison the author makes. If the author compares X to Y, your summary must include that comparison.
- Parallels and analogies: EVERY parallel or analogy the author draws (comparisons to other species, modern practices, other time periods, other cultures). These are often the most memorable and important parts — NEVER omit them.
- Reasoning: the logical steps from evidence to conclusion.
- Counterarguments: positions the author disagrees with, and why.
- Specific artifacts and examples: every named artifact, site, case study, or specific example. If the author names it, it must appear.
- Context: background information needed to understand the above.

FORBIDDEN — these are FAILURE MODES:
- Skipping a topic, section, comparison, or parallel because you decided it was "minor".
- Dropping the author's argument and keeping only the raw facts.
- Merging multiple distinct arguments, comparisons, or parallels into one vague sentence.
- Replacing a specific parallel or comparison with a generic statement like "the author draws parallels".
- Omitting a specific artifact, site, or case study the author discusses in detail.
- Using meta-language ("The author discusses...", "This section covers...").
- Stopping early. Use the full sentence budget.

SELF-CHECK BEFORE OUTPUT: Scan the source text for topics, comparisons, parallels, or artifacts you omitted, and add them. Your summary is not done until it covers EVERYTHING the author discusses.

CRITICAL RULES:
1. Your response MUST be under ${wordLimit} words — do NOT exceed this limit. Be dense and concise.
2. Every sentence should cover DIFFERENT content — no repetition.
3. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`,
          stream: false
        })
      });

      if (!res.ok) {
        chunkSummaries.push({ label: `Pages ${chunk.from}-${chunk.to}`, summary: `(Ollama error: ${res.status})` });
      } else {
        const data = await res.json();
        chunkSummaries.push({
          label: `Pages ${chunk.from}-${chunk.to}`,
          summary: (data.response || '(No summary returned)').trim()
        });
      }
    } catch (err) {
      chunkSummaries.push({ label: `Pages ${chunk.from}-${chunk.to}`, summary: `(Error: ${err.message})` });
    }

    completedChunks++;
  }

  const finalSummary = chunkSummaries
    .map(c => `**${c.label}:**\n${c.summary}`)
    .join('\n\n');

  return { success: true, summary: finalSummary, totalChunks: chunks.length, completedChunks };
}

// ===== CONCEPT SUMMARIZATION =====
async function handleSummarizeConcept(msg) {
  let { url, concept, ollamaUrl, model, genre, language } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  const totalPages = cached.pageCount;
  const paragraphLimit = Math.ceil(totalPages / 20);

  const pageNums = Object.keys(cached.pages).sort((a, b) => +a - +b);
  let fullText = pageNums.map(p => cached.pages[p]).join('\n\n---\n\n');

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    const targetModel = await getEffectiveModel(base, model);
    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: genre === 'philosophical_fiction'
          ? `Based on the following story text, STATE directly how the concept "${concept}" operates as a philosophical, existential, or moral theme in this narrative. This analysis is a SUBSTITUTE for reading — STATE what the concept means in the story, how it shapes characters' decisions, and what position the text takes on it. Do NOT describe what the book "explores" — say what the book says.

Name the specific characters, decisions, plot developments, and symbols through which "${concept}" is dramatized. Relate it to the core philosophical questions of the work and STATE the answers the text offers.

CRITICAL CONSTRAINT:
Your analysis MUST be exactly ${paragraphLimit} paragraph(s) long (one paragraph for every 20 pages of the story or fraction thereof).
The total book length is ${totalPages} pages.

LANGUAGE RULE (CRITICAL):
You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Story Text Context:
${fullText}`
          : genre === 'fiction'
          ? `Based on the following story text, STATE directly the role of "${concept}" as a narrative device, plot element, or literal object in the story. This analysis is a SUBSTITUTE for reading — STATE the specific scenes, characters, and events where "${concept}" appears and how it changes the plot. Do NOT describe what the book "explores" — say what the book says.

Focus strictly on:
- The specific scenes and lines where this element/object is introduced, used, or referred to by characters.
- How it directly changes the actions, events, and plot progression.
- The literal contexts in which it appears.

Do NOT write an abstract thematic or philosophical interpretation. Keep the analysis strictly focused on narrative action and plot function.

CRITICAL CONSTRAINT:
Your analysis MUST be exactly ${paragraphLimit} paragraph(s) long (one paragraph for every 20 pages of the story or fraction thereof).
The total book length is ${totalPages} pages.

LANGUAGE RULE (CRITICAL):
You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Story Text Context:
${fullText}`
          : genre === 'research_papers'
          ? `Based on the following research paper text, STATE directly what the paper actually says about "${concept}". This analysis is a SUBSTITUTE for reading — STATE the definitions, findings, numbers, and conclusions attached to "${concept}" directly as fact. Do NOT describe what the paper "examines" — say what the paper says.

Track how this concept appears across the paper — as a variable, construct, method, theoretical frame, or finding. Wherever the concept is tied to a quantitative result, reproduce the number verbatim with its unit and referent (n, %, mean, SD, p-value, CI, effect size, regression coefficient). Wherever it is tied to an inferential step, name the test or model used. Wherever it is tied to a conclusion, attach the magnitude of the effect.

If the concept is purely theoretical or methodological and carries no numbers, state its definition, role, and use directly — do not invent statistics.

CRITICAL RULES:
1. NUMBERS VERBATIM. Every quantitative value attached to the concept appears exactly as written in the paper.
2. NO INVENTED STRUCTURE. Adapt to whatever role the concept actually plays in the paper.

CRITICAL CONSTRAINT:
Your analysis MUST be exactly ${paragraphLimit} paragraph(s) long (one paragraph for every 20 pages of the paper or fraction thereof).
The total paper length is ${totalPages} pages.

LANGUAGE RULE (CRITICAL):
You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Paper Text Context:
${fullText}`
          : genre === 'self_help'
          ? `Based on the following self-help book text, STATE directly what the book actually says about "${concept}". This analysis is a SUBSTITUTE for reading — STATE the actual advice, frameworks, exercises, and mindset shifts the book attaches to "${concept}", directly as fact. Do NOT describe what the book "examines" or "explores" — say what the book says.

Write the analysis as a practitioner's working notes — the notes a serious reader would take if they were going to apply the book's guidance on "${concept}" next week.

CRITICAL RULES:
1. PRINCIPLES AS DIRECT STATEMENTS: State every principle, technique, framework, or mindset shift tied to "${concept}" as a direct, applicable statement. ("When facing X, do Y because Z." — not "The author suggests that when facing X, one might consider Y.")
2. NAMED MODELS: If the author names a framework, model, or dichotomy tied to "${concept}", state the name, what it claims, and how to use it.
3. EXERCISES VERBATIM: Reproduce any reflection questions, journaling prompts, or exercises tied to "${concept}" verbatim — the reader is supposed to actually do them.
4. ANECDOTES → LESSONS: Compress any illustrative story about "${concept}" into ONE sentence stating the lesson it demonstrates. Skip anecdotes that carry no lesson.
5. SUBSTANCE-ADAPTIVE: Match output density to the book's actual coverage of "${concept}". If the concept is only mentioned in passing, the analysis is short — that is correct, not a failure.

CRITICAL CONSTRAINT:
Your analysis MUST be exactly ${paragraphLimit} paragraph(s) long (one paragraph for every 20 pages of the entire book or fraction thereof).
The total book length is ${totalPages} pages.

LANGUAGE RULE (CRITICAL):
You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Book Text Context:
${fullText}`
          : `Based on the following book text, STATE directly what the book actually says about "${concept}". This summary is a SUBSTITUTE for reading — STATE the actual definitions, facts, arguments, and conclusions attached to "${concept}" directly as fact. Do NOT describe what the book "examines" or "explores" — say what the book says.

CRITICAL CONSTRAINT:
Your summary MUST be exactly ${paragraphLimit} paragraph(s) long (one paragraph for every 20 pages of the entire book or fraction thereof).
The total book length is ${totalPages} pages.

LANGUAGE RULE (CRITICAL):
You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Book Text Context:
${fullText}`,
        stream: false
      })
    });

    if (!res.ok) return { success: false, error: `Ollama error: ${res.status}` };
    const data = await res.json();
    return { success: true, summary: data.response };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== QUIZ GENERATION =====
async function handleGenerateQuiz(msg) {
  let { url, startPage, endPage, includeFocus, ollamaUrl, model, genre, language } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  let rangeText = '';
  for (let i = startPage; i <= endPage; i++) {
    if (cached.pages[i]) rangeText += `Page ${i}:\n${cached.pages[i]}\n\n`;
  }

  if (!rangeText.trim()) {
    return { success: false, error: 'No text found in the specified range.' };
  }


  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: genre === 'philosophical_fiction'
          ? `You are a philosophical reading guide. Based on the following text from pages ${startPage} to ${endPage}, generate a 4-question multiple choice quiz to test the reader's understanding of both the narrative events and their underlying philosophical, existential, or moral significance.

Focus on:
- Character choices, moral dilemmas, and existential struggles
- The philosophical implications of key plot events
- The meaning of symbols and metaphors
- Deeper insights into human nature as presented in this text

LANGUAGE RULE (CRITICAL):
You MUST generate the questions, options, answers, and explanations EXCLUSIVELY in ${language}.

You MUST output ONLY a valid JSON array of objects. Do not include any other text.

Each object must have:
- "question": The text of the question
- "options": An array of exactly 4 possible answer strings
- "answer": The exact string of the correct option
- "explanation": A short 1-sentence explanation referencing the story events and their philosophical meaning.

Text:
${rangeText}`
          : genre === 'fiction'
          ? `You are a storytelling quiz master. Based on the following story text from pages ${startPage} to ${endPage}, generate a 4-question multiple choice quiz to test the reader's understanding of the story's events.

Focus strictly on:
- What characters actually do, say, and decide
- Key plot events, scenes, and actions
- Concrete developments in relationships and situations
- Emotional reactions to events on the page

Do NOT ask about abstract themes, symbols, or analytical interpretations. Keep it centered on the narrative action.

LANGUAGE RULE (CRITICAL):
You MUST generate the questions, options, answers, and explanations EXCLUSIVELY in ${language}.

You MUST output ONLY a valid JSON array of objects. Do not include any other text.

Each object must have:
- "question": The text of the question
- "options": An array of exactly 4 possible answer strings
- "answer": The exact string of the correct option
- "explanation": A short 1-sentence explanation referencing the facts in the text.

Text:
${rangeText}`
          : genre === 'research_papers'
          ? `You are a research methodology examiner. Based on the following text from pages ${startPage} to ${endPage} of a research paper, generate a 4-question multiple choice quiz that tests the reader's understanding of the empirical and inferential substance of the paper.

Focus on:
- Specific quantitative results: sample sizes, percentages, means, p-values, confidence intervals, effect sizes. Correct answers must reproduce the exact value from the text.
- Statistical reasoning: which test or model was applied, what comparison was made, what the result of the test was.
- Conclusions with magnitude: what the authors concluded, and the size or strength of the effect.
- Methodological design choices: what was measured, in whom, against what comparison.

If the pages contain no quantitative content (e.g., pure introduction or literature review), test the reader on the substantive arguments, definitions, or prior findings presented instead — do not invent statistics that are not in the text.

LANGUAGE RULE (CRITICAL):
You MUST generate the questions, options, answers, and explanations EXCLUSIVELY in ${language}.

You MUST output ONLY a valid JSON array of objects. Do not include any other text.

Each object must have:
- "question": The text of the question
- "options": An array of exactly 4 possible answer strings
- "answer": The exact string of the correct option
- "explanation": A short 1-sentence explanation referencing the specific number, test, or conclusion in the text.

Text:
${rangeText}`
          : `You are an expert tutor. Based on the following text from pages ${startPage} to ${endPage}, generate a 4-question multiple choice quiz to test the reader's understanding.

LANGUAGE RULE (CRITICAL):
You MUST generate the questions, options, answers, and explanations EXCLUSIVELY in ${language}.

You MUST output ONLY a valid JSON array of objects. Do not include any other text.

Each object must have:
- "question": The text of the question
- "options": An array of exactly 4 possible answer strings
- "answer": The exact string of the correct option
- "explanation": A short 1-sentence explanation of why the answer is correct based on the text.

Text:
${rangeText}`,
        stream: false,
        format: 'json'
      })
    });

    if (!res.ok) return { success: false, error: `Ollama error: ${res.status}` };
    const data = await res.json();
    return { success: true, quiz: data.response };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== GRADED QUIZ =====
async function handleGradeQuiz(msg) {
  let { url, startPage, endPage, questions, answers, ollamaUrl, model } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  let rangeText = '';
  if (cached && cached.pages) {
    for (let i = startPage; i <= endPage; i++) {
      if (cached.pages[i]) rangeText += `Page ${i}:\n${cached.pages[i]}\n\n`;
    }
  }


  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: `You are an expert tutor grading a student's quiz based on pages ${startPage} to ${endPage} of a text.

Original text context:
${rangeText}

Quiz Questions:
${questions}

Student's Answers:
${answers}

Please grade the student. Provide a clear grade (e.g., A, B, C, or X/3), gently correct any mistakes, and provide the correct answers based ONLY on the text context provided.

LANGUAGE RULE (CRITICAL):
You MUST respond EXCLUSIVELY in ${language}.`,
        stream: false
      })
    });

    if (!res.ok) return { success: false, error: `Ollama error: ${res.status}` };
    const data = await res.json();
    return { success: true, grading: data.response };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== PURPOSE GENERATION =====
async function handleGeneratePurpose(msg) {
  let { url, ollamaUrl, model, genre, language } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  const pageNums = Object.keys(cached.pages).sort((a, b) => +a - +b);
  let fullText = pageNums.map(p => cached.pages[p]).join('\n\n---\n\n');


  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: genre === 'philosophical_fiction'
          ? `You are a philosophical reading guide. Based on the following story text, generate 3 guiding questions that will help the reader uncover the deeper philosophical, existential, and moral questions explored in this work.

        These questions should encourage the reader to notice:
        1. Existential struggles and choices: How do the characters confront freedom, mortality, guilt, or the search for meaning?
        2. Philosophical concepts: What ideas about morality, truth, justice, or human nature are dramatized in the text?
        3. Symbolic and psychological layers: What symbols, mood elements, or psychological states represent these deeper ideas?

        Write the questions in simple, inviting language — as if a thoughtful companion is asking you to ponder something profound.

        LANGUAGE RULE (CRITICAL):
        You MUST generate your response EXCLUSIVELY in ${language}.

        You MUST return ONLY a JSON array of 3 strings. Do not include any introductory or concluding text.

        Story Text:
        ${fullText}`
          : genre === 'fiction'
          ? `You are a thoughtful reading guide for fiction. Based on the following story text, generate 3 guiding questions that will deepen the reader's engagement with the narrative.

        These questions should encourage the reader to notice:
        1. Character development: How do the characters change, what drives them, what are they hiding?
        2. Story structure: What conflicts are building, what patterns emerge in the plot?
        3. Deeper meaning: What themes, symbols, or emotions run beneath the surface of the story?

        Write the questions in simple, inviting language — as if a friend is asking you to pay attention to something interesting.

        LANGUAGE RULE (CRITICAL):
        You MUST generate your response EXCLUSIVELY in ${language}.

        You MUST return ONLY a JSON array of 3 strings. Do not include any introductory or concluding text.

        Story Text:
        ${fullText}`
          : genre === 'research_papers'
          ? `You are a research methodology advisor. Based on the following research paper text, generate 3 guiding questions in plain language that a reader should keep in mind while reading the entire paper.

These questions should encourage the reader to notice:
1. The empirical core: What were the key numbers — sample size, effect size, p-value, confidence interval — and what do they actually tell us?
2. The inferential bridge: How did the authors move from measurement to conclusion? What test, model, or comparison justifies the claim?
3. The strength of the conclusion: Is the conclusion supported by the magnitude of the effect, or does it overreach the evidence? What would weaken or strengthen it?

Write the questions in simple, inviting language — as if a thoughtful research companion is asking you to pay attention to what really matters in the paper.

If the paper is non-empirical (theory, review, methods paper, qualitative study), adapt the questions to its actual substance — do not force a quantitative frame where none exists.

LANGUAGE RULE (CRITICAL):
You MUST generate your response EXCLUSIVELY in ${language}.

You MUST return ONLY a JSON array of 3 strings. Do not include any introductory or concluding text.

Paper Text:
        ${fullText}`
          : `You are an expert at simplifying complex information. Based on the following document text, generate 3 simple, clear, and encompassing questions in plain language that a reader should keep in mind while reading the entire document.
        
        These questions should be:
        1. Broad enough to cover the main themes of the whole document (not just specific details).
        2. Written in very simple, everyday language.
        3. Designed to help the reader understand the "big picture" and the overall goal of the text.

        LANGUAGE RULE (CRITICAL):
        You MUST generate your response EXCLUSIVELY in ${language}.

        Avoid academic jargon or complex sentence structures.
        You MUST return ONLY a JSON array of 3 strings. Do not include any introductory or concluding text.

        Document Text:
        ${fullText}`,
        stream: false,
        format: 'json'
      })
    });

    if (!res.ok) return { success: false, error: `Ollama error: ${res.status}` };
    const data = await res.json();
    return { success: true, questions: data.response };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== TRUTH VERIFICATION (uses general knowledge and web search if available) =====
async function handleVerifyClaim(msg) {
  let { ollamaUrl, model, claim, claimLanguage, context, language } = msg;
  // `language` is the language the AI should RESPOND in (always English for popups).
  // `claimLanguage` is the language the claim text is WRITTEN in (so the AI
  // doesn't misinterpret a French/Spanish/etc. phrase as English).

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const responseLang = language || 'English';
    const claimLang = claimLanguage || responseLang;

    const systemPrompt = `You are an expert fact-checking assistant with web search access.
Verify the accuracy of the claim provided by the user using your search/web capabilities to check the internet.
Do NOT restrict yourself to any document or text.
Analyze the claim's accuracy keeping in mind the provided background context to avoid hyper-literal pedantry (e.g. if a specific number falls within a known scientific range, or is accurate for a specific subset/context mentioned in the book, it should be evaluated as Accurate or Nuanced/Context-Dependent).
Be concise and precise.
Respond in ${responseLang} only.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Context from the book the user is reading (for background/context):\n"${context}"\n\nClaim to verify on the internet:\n"${claim}"\n\nIMPORTANT: The claim above is written in **${claimLang}**. Do NOT interpret it as English or as a misspelled English phrase. Translate it to ${responseLang} mentally before fact-checking, and evaluate the meaning of the ${claimLang} phrase.\n\nInstructions:\nEvaluate the accuracy of the claim based on your internet search, keeping in mind the provided background context.\nInstead of a strict True/False, rate it as one of:\n- Accurate: The text matches established facts or a major scientific school of thought.\n- Nuanced/Context-Dependent: The text is accurate within a specific context (e.g., a specific fossil group, location, or a particular date range) but shouldn't be generalized.\n- Inaccurate: The text contains clear factual errors.\n\nSummarize your findings and reasoning in 2-3 sentences. Write your response in ${responseLang}.` }
    ];

    const res = await fetch(`${base}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: targetModel, messages, stream: false })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    const reply = data.message?.content || data.response || '(No reply)';
    return { success: true, reply };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== RELEVANCE CHECK — CHUNKED SUMMARIZATION =====
// Summarizes a single 20-page chunk in ISOLATION (fresh /api/generate call,
// no conversation history). The content script calls this repeatedly, once
// per chunk, collecting the results. Each call gets a clean model context
// so chunks don't bleed into each other.
async function handleRelevanceSummarizeChunk(msg) {
  let { url, fromPage, toPage, ollamaUrl, model, genre, language } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  // Build text for just this chunk
  let chunkText = '';
  for (let p = fromPage; p <= toPage; p++) {
    if (cached.pages[p]) {
      chunkText += `Page ${p}:\n${cached.pages[p]}\n\n`;
    }
  }

  if (!chunkText.trim()) {
    return { success: true, summary: '(No readable text in this range.)' };
  }

  // Cap input text to keep the call fast and within context limits
  if (chunkText.length > 18000) chunkText = chunkText.substring(0, 18000) + '...';

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    // Build a genre-aware "extract everything substantive" prompt.
    // The goal is a faithful, dense representation of what these pages
    // actually SAY — so that when all chunk summaries are concatenated
    // later, the model has a faithful proxy for the whole book.
    // Reuses the ANTI_META_LANGUAGE directive so the chunk summaries
    // state content directly rather than describing what the book "is about".
    let prompt;
    if (genre === 'philosophical_fiction') {
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a work of philosophical fiction. Summarize these pages densely enough that a reader who never sees the original can still know what happens AND what ideas are explored.

Summarize these pages on TWO levels:
1. NARRATIVE: State what literally happens — specific events, character actions, key dialogue. Name names, follow chronology.
2. PHILOSOPHICAL LAYER: State the existential, moral, or philosophical questions/themes raised — AND the answers or positions the text actually takes on them. Do not just name themes; say what the text says about them.

CRITICAL RULES:
1. Write 8-12 information-dense sentences. Each sentence should cover DIFFERENT content — no repetition.
2. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    } else if (genre === 'fiction') {
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a fiction book. Summarize these pages densely enough that a reader who never sees the original can still know what happens.

CRITICAL RULES:
1. State all major plot events, concrete character actions, physical movements, and scenes across these pages.
2. Track character relationships and interactions (who speaks to whom, what decisions they make).
3. Do NOT include abstract analysis, themes, or symbols. Narrate the events directly.
4. Write 8-12 vivid, chronological sentences that retell the story sequence.
5. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.
6. Every sentence should cover DIFFERENT content — no repetition.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    } else if (genre === 'research_papers') {
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a research paper. Summarize in priority order — include a tier only if these pages actually contain that kind of content; skip tiers that don't apply.

Summarize densely enough that a reader who never sees the original can still know what was found, how, and what was concluded.

TIER 1 — STATISTICS: Every quantitative result (n, %, mean, median, SD, p-value, CI, effect size, correlation, regression coefficient). Verbatim with units and referents.
TIER 2 — REASONING: Any inferential step, statistical test, model, or logical argument used to move from data to claim. Name the test and report its output.
TIER 3 — CONCLUSION: Any stated conclusion or takeaway, with effect magnitude attached.
TIER 4 — METHODS: What was measured — design, sample, instruments, dataset — but only what's needed to understand the numbers above.
TIER 5 — CONTEXT: Background, motivation, prior literature — only what's needed to make the rest intelligible.

CRITICAL RULES:
1. NUMBERS VERBATIM. If a number appears in this range, it appears in your summary exactly as written.
2. SKIP EMPTY TIERS. If a tier has no content in this range, do not pad with placeholders or "N/A". Move to the next tier silently.
3. PRIORITY MEANS ORDER. Prioritize Tiers 1–3 over 4–5 when the range is dense. If the range is purely contextual (intro, lit review, references), state the actual definitions, prior findings, and methodological choices substantively — do not invent Tiers 1–4.
4. Write 8–12 information-dense sentences. Each sentence should cover DIFFERENT content — no repetition.
5. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    } else if (genre === 'self_help') {
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a self-help book. Summarize these pages densely enough that a reader who never sees the original can still know what advice, frameworks, and exercises the book prescribes.

Write the summary as a practitioner's working notes — the notes a serious reader would take if they were going to apply this material next week.

CRITICAL RULES:
1. PRINCIPLES AS DIRECT STATEMENTS: State every principle, technique, framework, or mindset shift as a direct, applicable statement. ("When facing X, do Y because Z." — not "The author suggests that when facing X, one might consider Y.")
2. NAMED MODELS: If the author names a framework, model, or dichotomy (e.g., "System 1 vs System 2", "Fixed vs Growth Mindset"), state the name, what it claims, and how to use it.
3. EXERCISES VERBATIM: Reproduce reflection questions, journaling prompts, and exercises verbatim — the reader is supposed to actually do them.
4. ANECDOTES → LESSONS: Compress every illustrative story into ONE sentence stating the lesson it demonstrates. Skip anecdotes that carry no lesson.
5. SUBSTANCE-ADAPTIVE: Dense framework pages get detailed notes; anecdote pages get the lesson only; pure filler/transition pages get skipped silently.
6. Write 8–12 information-dense sentences. Each sentence should cover DIFFERENT content — no repetition.
7. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    } else if (genre === 'law_books') {
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a legal textbook. Summarize these pages densely enough that a reader who never sees the original can still know the actual rules, definitions, and exceptions stated.

CRITICAL RULES:
1. STATE every definition, rule, exception, legal concept, and test mentioned — directly as fact.
2. ACADEMIC TONE: Maintain a precise, objective, academic tone.
3. Write 8–12 information-dense sentences. Each sentence should cover DIFFERENT content — no repetition.
4. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    } else if (genre === 'law_statutes') {
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a statutory text or code. Summarize these pages densely enough that a reader who never sees the original can still know the actual rules.

CRITICAL RULES:
1. IDENTIFY SECTIONS: Explicitly identify each section, chapter, or article mentioned (e.g., "Article 12", "Section 3"). Use clear headings for each section.
2. STATE THE RULE: Place the actual rule — its substance, scope, conditions, exceptions — directly below its heading. Do not copy the text verbatim. Provide an accurate, comprehensive, all-encompassing statement of the rule or statute.
3. Write 8–12 information-dense sentences. Each sentence should cover DIFFERENT content — no repetition.
4. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    } else {
      // Default non-fiction
      prompt = `You are summarizing pages ${fromPage} to ${toPage} of a non-fiction book. Summarize these pages densely enough that a reader who never sees the original can still know what the book actually says — the facts, definitions, findings, arguments, and conclusions.

CRITICAL RULES:
1. STATE the actual content (facts, definitions, findings, arguments, conclusions, names, dates) directly as fact.
2. Cover ALL major topics, arguments, and developments found across these pages. Do NOT focus on just one topic — be COMPREHENSIVE.
3. Write 8–12 information-dense sentences. Each sentence should cover DIFFERENT content — no repetition.
4. LANGUAGE RULE (CRITICAL): You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}

Text:
${chunkText}`;
    }

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: prompt,
        stream: false
      })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    return { success: true, summary: (data.response || '(No summary returned)').trim() };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== RELEVANCE CHECK — FINAL ANSWER =====
// Takes the reader's question + ALL chunk summaries (concatenated), and
// answers: is this book relevant to what the reader wants to know?
// Returns a structured assessment: percentage + general overview + specific
// coverage + usefulness verdict.
async function handleRelevanceAnswer(msg) {
  let { url, question, chunkSummaries, ollamaUrl, model, genre, language } = msg;

  // The chunk summaries ARE the context now — the original page text is
  // deliberately NOT included. This keeps the call within context limits
  // even for very long books, and forces the model to reason from the
  // compressed representation rather than re-reading the raw text.
  const summaryContext = chunkSummaries
    .map((s, i) => `=== CHUNK ${i + 1} (pages ${s.from}-${s.to}) ===\n${s.summary}`)
    .join('\n\n');

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const prompt = `A reader is considering whether to read this book. They want to know:

"${question}"

Below is a compressed representation of the ENTIRE book — it was produced by summarizing every 20-page chunk in isolation, then concatenating those summaries. Treat this as your source of truth for what the book actually says. Do NOT speculate beyond what appears in these summaries.

${summaryContext}

Based on the summaries above, answer the reader's question. Your answer MUST follow this structure EXACTLY:

**RELEVANCE: X%**
(Where X is 0-100. 0% = the book does not touch the reader's question at all. 100% = the book is entirely about the reader's question. Be honest — do not inflate the number to be polite.)

**What the book is about (generally):**
In 2-3 sentences, state the actual subject matter, scope, and arc of the book. Name the concrete topics, events, or arguments it covers. Do NOT describe what the book "explores" — STATE what it is about.

**Will this book be useful for your aim?**
In 3-5 sentences, give a clear verdict: Yes / Partially / No. Explain WHY — what specifically the reader would gain (or not gain) from reading this book given their stated aim. If "Partially", name which parts of the book would be useful and which would not. If the book does not address the reader's question, say so directly here and explain what the book does cover instead.

CRITICAL RULES:
1. STATE the book's content directly as fact. Do NOT use meta-language like "The book explores...", "The author discusses...", "This chapter examines...". State what the book SAYS.
2. Be honest. If the book is not relevant, say so clearly and give a low percentage. The reader is using your answer to decide whether to spend hours reading this book — do not waste their time by inflating relevance.
3. Ground every claim in the summaries above. If the summaries do not mention something, do not claim the book covers it.
4. LANGUAGE RULE: You MUST respond EXCLUSIVELY in ${language}.

${ANTI_META_LANGUAGE}`;

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: prompt,
        stream: false
      })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    return { success: true, answer: (data.response || '(No answer returned)').trim() };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== TEXT TO SPEECH (multi-provider) =====
async function handleTTS(msg) {
  const { url, pageNum, text } = msg;

  if (!url || !pageNum) {
    return { success: false, error: 'Missing url or pageNum' };
  }

  // Initialize caches
  if (!pdfAudios[url]) pdfAudios[url] = {};

  const cacheKey = `${url}_${pageNum}`;

  // Check cache first (shared across providers — same text → same audio)
  if (pdfAudios[url][pageNum]) {
    return { success: true, wavData: pdfAudios[url][pageNum] };
  }

  // Prevent duplicate requests
  if (inFlightTts.has(cacheKey)) {
    if (msg.type === 'PREFETCH_TTS') {
      return { success: true, status: 'in-flight' };
    }
    try {
      await new Promise((resolve, reject) => {
        const interval = setInterval(() => {
          if (!inFlightTts.has(cacheKey)) {
            clearInterval(interval);
            resolve();
          }
        }, 100);
        setTimeout(() => {
          clearInterval(interval);
          reject(new Error('TTS request timeout'));
        }, 15000);
      });
      if (pdfAudios[url][pageNum]) {
        return { success: true, wavData: pdfAudios[url][pageNum] };
      }
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  inFlightTts.add(cacheKey);

  try {
    // Load Piper settings from storage (Piper is the only TTS provider now)
    const settings = await new Promise(resolve => {
      chrome.storage.local.get(
        ['piperUrl', 'language',
         'piperVoiceEn', 'piperVoiceAr', 'piperVoiceFr', 'piperVoiceIt', 'piperVoiceEs'],
        resolve
      );
    });

    // Always use Piper TTS (Gemini has been removed)
    const result = await generatePiperTTS(text, settings);

    inFlightTts.delete(cacheKey);

    if (result.success) {
      pdfAudios[url][pageNum] = result.wavData;
    }
    return result;
  } catch (err) {
    inFlightTts.delete(cacheKey);
    return { success: false, error: err.message };
  }
}

// ===== INLINE TTS (for popup "Aloud" button — no caching, no page key) =====
// Reuses generatePiperTTS() but skips the page-based cache. Used by the
// word/phrase popup's "🔊 Aloud" button to speak arbitrary selected text.
async function handleTTSInline(msg) {
  const { text, language } = msg;
  if (!text || !text.trim()) {
    return { success: false, error: 'No text to speak.' };
  }

  try {
    const settings = await new Promise(resolve => {
      chrome.storage.local.get(
        ['piperUrl', 'language',
         'piperVoiceEn', 'piperVoiceAr', 'piperVoiceFr', 'piperVoiceIt', 'piperVoiceEs'],
        resolve
      );
    });

    // The popup's language overrides the panel's saved language if provided.
    // This lets the popup speak in the language the reader selected in the
    // panel, even if it differs from the popup's default.
    if (language) settings.language = language;

    return await generatePiperTTS(text.trim(), settings);
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ===== PIPER TTS (local, free, unlimited — the only TTS provider) =====
async function handleCheckPiperVoices(piperUrl) {
  // Fetch the list of loaded voices from the running Piper server
  const base = (piperUrl || 'http://localhost:5000').replace(/\/+$/, '');
  try {
    const res = await fetch(`${base}/voices`, { method: 'GET' });
    if (!res.ok) {
      return { success: false, error: `Piper returned ${res.status}` };
    }
    const voices = await res.json();
    return { success: true, voices: voices };
  } catch (err) {
    const msg = err.message || '';
    if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || msg.includes('ERR_CONNECTION')) {
      return {
        success: false,
        error: `Cannot reach Piper at ${base}. Is the server running?`
      };
    }
    return { success: false, error: msg };
  }
}

// ===== GET RAW PAGE TEXT (for "Original" mode toggle) =====
// Returns the raw extracted text for the specified pages, joined with
// page markers. Used by the optional "Original" toggle in the main panel
// that shows the book's actual text instead of AI summaries.
async function handleGetPageText(msg) {
  let { url, pages } = msg;

  if (!pdfTexts[url]) {
    try { await handleParsePDF(url); } catch (_) { }
  }

  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  const pageNums = (pages && pages.length > 0)
    ? pages.filter(p => cached.pages[p]).sort((a, b) => +a - +b)
    : Object.keys(cached.pages).sort((a, b) => +a - +b);

  const text = pageNums.map(p => `--- Page ${p} ---\n${cached.pages[p]}`).join('\n\n');
  return { success: true, text };
}

// ===== RECAP GENERATION (summarize-the-summary) =====
// Takes an already-generated AI summary and condenses it into a single
// short paragraph (3-4 sentences). Used by the "Recap" toggle popup that
// appears on page navigation. This is a lightweight secondary call — the
// summary is already short, so the model just needs to compress it further.
async function handleRecapGenerate(msg) {
  let { summary, ollamaUrl, model, language } = msg;

  if (!summary || !summary.trim()) {
    return { success: false, error: 'No summary to recap.' };
  }

  try {
    const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
    let targetModel = model;

    if (!targetModel) {
      const tagsRes = await fetch(`${base}/api/tags`).catch(() => null);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    }

    if (!targetModel) {
      return { success: false, error: 'No model available.' };
    }

    const prompt = `Condense the following summary into a single short paragraph of 3-4 sentences. Capture only the essential points — the most important facts, findings, events, or takeaways. Drop all detail, examples, and elaboration. Write it as flowing prose, not bullets.

${ANTI_META_LANGUAGE}

Respond in ${language} only.

Summary to condense:
${summary}`;

    const res = await fetch(`${base}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: targetModel,
        prompt: prompt,
        stream: false
      })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return { success: false, error: `Ollama returned ${res.status}: ${errText}` };
    }

    const data = await res.json();
    return { success: true, recap: (data.response || '(No recap returned)').trim() };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function generatePiperTTS(text, settings) {
  const piperUrl = (settings.piperUrl || 'http://localhost:5000').replace(/\/+$/, '');
  const language = settings.language || 'English';

  // Pick the right voice model for the selected language.
  // User-saved voice always wins; otherwise fall back to per-language default.
  const voiceMap = {
    English: settings.piperVoiceEn || 'en_US-lessac-medium',
    Arabic:  settings.piperVoiceAr || 'ar_JO-kareem-medium',
    French:  settings.piperVoiceFr || 'fr_FR-siwis-medium',
    Italian: settings.piperVoiceIt || 'it_IT-riccardo-x_low',
    Spanish: settings.piperVoiceEs || 'es_ES-carlfm-x_low'
  };
  let voice = voiceMap[language] || voiceMap.English;

  // If the user-selected voice isn't loaded on the server, try to fall back
  // to ANY loaded English voice, then ANY loaded voice at all.
  // (We fetch the list to verify — saves a confusing 500 error.)
  try {
    const voicesRes = await fetch(`${piperUrl}/voices`, { method: 'GET' });
    if (voicesRes.ok) {
      const rawVoices = await voicesRes.json();
      // Normalize: old Piper servers return ["name1", "name2"], new ones return objects.
      const loadedVoices = rawVoices.map(v => {
        if (typeof v === 'string') {
          const prefix = v.split('-')[0];
          const parts = v.split('-');
          const quality = parts.length >= 3 ? parts[parts.length - 1] : '';
          return { name: v, language_code: prefix, language: prefix, quality };
        }
        return v;
      });
      const loadedNames = loadedVoices.map(v => v.name);
      if (!loadedNames.includes(voice)) {
        // Try to find any voice matching the language
        const fallbackByLang = loadedVoices.find(v =>
          (v.language || '').toLowerCase().includes(language.toLowerCase()) ||
          (v.language_code || '').toLowerCase().startsWith(language.substring(0, 2).toLowerCase())
        );
        if (fallbackByLang) {
          voice = fallbackByLang.name;
        } else if (loadedNames.length > 0) {
          // Last resort: just use the first loaded voice
          voice = loadedNames[0];
        }
      }
    }
  } catch (_) {
    // Server is unreachable — let the actual synthesis call report the error
  }

  // Piper's HTTP server endpoint:
  //   GET /predict?text=...&speaker=...&noise_scale=...&length_scale=...
  // Returns: audio/wav bytes directly
  //
  // We use GET with URL params because that's what Piper's reference HTTP server
  // supports out of the box. For long text we fall back to POST.
  const params = new URLSearchParams({
    text: text,
    speaker: voice,
    noise_scale: '0.667',
    length_scale: '1.0'  // we control playback speed via HTMLAudioElement.playbackRate instead
  });

  try {
    let res;
    if (text.length > 1800) {
      // Piper's GET endpoint may hit URL length limits for very long summaries.
      // Use POST to /predict with form-encoded body (also supported).
      res = await fetch(`${piperUrl}/predict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
      });
    } else {
      res = await fetch(`${piperUrl}/predict?${params.toString()}`, {
        method: 'GET'
      });
    }

    if (!res.ok) {
      const errText = await res.text().catch(() => 'Unknown error');
      return {
        success: false,
        error: `Piper server returned ${res.status}: ${errText.substring(0, 200)}`
      };
    }

    // Get raw WAV bytes
    const arrayBuffer = await res.arrayBuffer();
    if (arrayBuffer.byteLength < 1000) {
      return { success: false, error: 'Piper returned an empty or invalid audio response.' };
    }

    // Convert to base64 for caching + transport to content script
    const wavBase64 = arrayBufferToBase64(arrayBuffer);
    return { success: true, wavData: wavBase64 };
  } catch (err) {
    // Friendlier error for the common "server not running" case
    const msg = err.message || '';
    if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || msg.includes('ERR_CONNECTION')) {
      return {
        success: false,
        error: `Cannot reach Piper at ${piperUrl}. Is the server running? See piper-setup.md.`
      };
    }
    return { success: false, error: msg };
  }
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  let binary = '';
  // Chunk to avoid call stack issues on very large buffers
  const CHUNK = 0x8000;
  for (let i = 0; i < len; i += CHUNK) {
    const slice = bytes.subarray(i, Math.min(i + CHUNK, len));
    binary += String.fromCharCode.apply(null, slice);
  }
  return btoa(binary);
}

