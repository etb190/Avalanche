export async function handleHoverRangeSummary(url, startPage, endPage, ollamaUrl, model, genre, language, pdfTexts) {
  const cached = pdfTexts[url];
  if (!cached || !cached.pages) {
    return { success: false, error: 'Could not extract text from PDF.' };
  }

  // Ensure endPage doesn't exceed total pages
  endPage = Math.min(endPage, cached.pageCount);
  
  if (startPage > endPage) {
    return { success: false, error: 'Invalid range.' };
  }

  const base = (ollamaUrl || 'http://localhost:11434').replace(/\/+$/, '');
  let targetModel = model;

  if (!targetModel) {
    try {
      const tagsRes = await fetch(`${base}/api/tags`);
      if (tagsRes && tagsRes.ok) {
        const tagsData = await tagsRes.json();
        if (tagsData.models && tagsData.models.length > 0) {
          targetModel = tagsData.models[0].name;
        }
      }
    } catch (e) {
      console.warn('Failed to fetch ollama tags', e);
    }
  }

  if (!targetModel) {
    return { success: false, error: 'No model specified and no local models found.' };
  }

  const summaries = [];
  
  // Process in 20-page chunks sequentially to avoid overloading the local model
  for (let currentStart = startPage; currentStart <= endPage; currentStart += 20) {
    let currentEnd = Math.min(currentStart + 19, endPage);
    
    let chunkText = '';
    for (let i = currentStart; i <= currentEnd; i++) {
      if (cached.pages[i]) {
        chunkText += `--- PAGE ${i} ---\n${cached.pages[i]}\n\n`;
      }
    }
    
    if (chunkText.trim().length < 10) {
      summaries.push(`[No readable text found in pages ${currentStart}-${currentEnd}]`);
      continue;
    }

    const wordLimit = 20 * 60; // 60 words per page
    
    let prompt = `You are a master summarizer. Summarize the following pages of a book (pages ${currentStart} to ${currentEnd}) in under ${wordLimit} words. 
Capture all critical events, plot developments, and key concepts. 
Focus strictly on the content. Do NOT use meta-language like "The text discusses..." or "The author explores...".
Respond in ${language} only.

Text:
${chunkText}`;

    if (genre === 'philosophical_fiction') {
      prompt = `You are a literary philosopher analyzing a work of philosophical fiction. 
Summarize the following pages (${currentStart} to ${currentEnd}) in under ${wordLimit} words. 
Balance the narrative events and their deeper significance 50/50.
Do NOT use meta-language. Respond in ${language} only.

Text:
${chunkText}`;
    } else if (genre === 'law') {
      prompt = `You are a legal academic summarizing texts. Focus strictly on definitions, rules, exceptions, and key explanations for pages ${currentStart} to ${currentEnd}. Summarize in under ${wordLimit} words.
Do NOT use meta-language. Respond in ${language} only.

Text:
${chunkText}`;
    }

    try {
      const res = await fetch(`${base}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: targetModel,
          prompt: prompt,
          stream: false
        })
      });

      if (!res.ok) {
        throw new Error('Ollama returned ' + res.status);
      }

      const data = await res.json();
      summaries.push(`**Pages ${currentStart}-${currentEnd}**\n\n${data.response.trim()}`);
    } catch (err) {
      summaries.push(`**Pages ${currentStart}-${currentEnd}**\n\n[Error summarizing chunk: ${err.message}]`);
    }
  }

  const finalSummary = summaries.join('\n\n---\n\n');
  return { success: true, summary: finalSummary };
}
